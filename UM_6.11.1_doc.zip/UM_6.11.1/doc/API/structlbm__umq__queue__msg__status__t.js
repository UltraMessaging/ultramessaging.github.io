var structlbm__umq__queue__msg__status__t =
[
    [ "clientd", "structlbm__umq__queue__msg__status__t.html#a5166042e7fa0e0767db7764d09c72144", null ],
    [ "flags", "structlbm__umq__queue__msg__status__t.html#ae4c9d0e45bdc1ff0d7f1e96489f2b36c", null ],
    [ "msg", "structlbm__umq__queue__msg__status__t.html#a09d03849f08877f57077375a7a521141", null ],
    [ "msgid", "structlbm__umq__queue__msg__status__t.html#a3451ff364051dea1ee0861668835482a", null ],
    [ "status", "structlbm__umq__queue__msg__status__t.html#a78009df28c5d1c7d0a8491add231e28b", null ]
];