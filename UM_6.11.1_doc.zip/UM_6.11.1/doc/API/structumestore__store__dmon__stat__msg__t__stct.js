var structumestore__store__dmon__stat__msg__t__stct =
[
    [ "hdr", "structumestore__store__dmon__stat__msg__t__stct.html#a1889b49f30a9d00ceecf4531db2b5d0f", null ],
    [ "store_idx", "structumestore__store__dmon__stat__msg__t__stct.html#ab8cad320a96d71b39acb5bccb7e25587", null ],
    [ "ume_retx_req_drop_count", "structumestore__store__dmon__stat__msg__t__stct.html#a48daa393596d1ede504a5c378220f468", null ],
    [ "ume_retx_req_rcv_count", "structumestore__store__dmon__stat__msg__t__stct.html#aa5af5aa74379f3784c59503a52309dfd", null ],
    [ "ume_retx_req_serviced_count", "structumestore__store__dmon__stat__msg__t__stct.html#a9fb94f3660f9055189b1466fbe26d5b1", null ],
    [ "ume_retx_req_total_dropped", "structumestore__store__dmon__stat__msg__t__stct.html#a4841b5c524a027e72797bf204899a773", null ],
    [ "ume_retx_stat_interval", "structumestore__store__dmon__stat__msg__t__stct.html#a8413d51c9aa089626fb135e0a64dc60c", null ]
];