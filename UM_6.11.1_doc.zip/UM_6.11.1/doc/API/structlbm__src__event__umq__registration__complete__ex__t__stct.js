var structlbm__src__event__umq__registration__complete__ex__t__stct =
[
    [ "flags", "structlbm__src__event__umq__registration__complete__ex__t__stct.html#aba1b3d2ee6e121e346796c5fb7092eec", null ],
    [ "queue", "structlbm__src__event__umq__registration__complete__ex__t__stct.html#af49711a40ea474f6123f8f1e59918c7c", null ],
    [ "queue_id", "structlbm__src__event__umq__registration__complete__ex__t__stct.html#a977ae8a8c182d35cecfbc1d989174754", null ]
];