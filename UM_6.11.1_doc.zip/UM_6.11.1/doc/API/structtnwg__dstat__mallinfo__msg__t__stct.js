var structtnwg__dstat__mallinfo__msg__t__stct =
[
    [ "hdr", "structtnwg__dstat__mallinfo__msg__t__stct.html#a165397f1ac3aff0a7826737d196927df", null ],
    [ "record", "structtnwg__dstat__mallinfo__msg__t__stct.html#a0167df38261a7f2bda8a67a74ab3d25c", null ]
];