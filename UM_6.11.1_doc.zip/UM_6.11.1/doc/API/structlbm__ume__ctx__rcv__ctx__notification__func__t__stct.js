var structlbm__ume__ctx__rcv__ctx__notification__func__t__stct =
[
    [ "clientd", "structlbm__ume__ctx__rcv__ctx__notification__func__t__stct.html#a90ce4489c9930cc8ce10ed6afdef6de1", null ],
    [ "create_func", "structlbm__ume__ctx__rcv__ctx__notification__func__t__stct.html#a40391a36818930fdd2b955979c740672", null ],
    [ "delete_func", "structlbm__ume__ctx__rcv__ctx__notification__func__t__stct.html#aa82533b3b15499c9c399e58ec2f6cf90", null ]
];