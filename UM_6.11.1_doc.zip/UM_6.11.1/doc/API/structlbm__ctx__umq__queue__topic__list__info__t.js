var structlbm__ctx__umq__queue__topic__list__info__t =
[
    [ "num_topics", "structlbm__ctx__umq__queue__topic__list__info__t.html#a62e42bb711d825276b463f853dfd8c57", null ],
    [ "topics", "structlbm__ctx__umq__queue__topic__list__info__t.html#a5aeb471067822f8d42c74e071b3bf216", null ]
];