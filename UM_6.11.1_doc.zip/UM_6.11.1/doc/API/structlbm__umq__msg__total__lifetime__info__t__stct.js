var structlbm__umq__msg__total__lifetime__info__t__stct =
[
    [ "flags", "structlbm__umq__msg__total__lifetime__info__t__stct.html#acb83f850f2696534f012d3ea814b1e07", null ],
    [ "umq_msg_total_lifetime", "structlbm__umq__msg__total__lifetime__info__t__stct.html#a1773d754611aada145ee2077d008a473", null ]
];