var structlbm__rcv__umq__queue__msg__retrieve__info__t =
[
    [ "msgs", "structlbm__rcv__umq__queue__msg__retrieve__info__t.html#af15965482a9709298e1e95783dd46205", null ],
    [ "num_msgs", "structlbm__rcv__umq__queue__msg__retrieve__info__t.html#a5bd890f8d241f3289b0645ae3c7db45d", null ]
];