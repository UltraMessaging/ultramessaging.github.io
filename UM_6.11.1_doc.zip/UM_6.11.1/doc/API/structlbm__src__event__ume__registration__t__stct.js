var structlbm__src__event__ume__registration__t__stct =
[
    [ "registration_id", "structlbm__src__event__ume__registration__t__stct.html#a9264ff0c3bff1ff8a1d4502f0f1da4c7", null ]
];