var structlbm__src__transport__stats__tcp__t__stct =
[
    [ "bytes_buffered", "structlbm__src__transport__stats__tcp__t__stct.html#ab658e0534a60e6f8b0ea4ee07d6a7351", null ],
    [ "num_clients", "structlbm__src__transport__stats__tcp__t__stct.html#afdbea18ebdc5f2370f617ed561e1caef", null ]
];