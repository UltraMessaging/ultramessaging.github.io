var structlbm__timespec__t__stct =
[
    [ "tv_nsec", "structlbm__timespec__t__stct.html#a14bdb27390d949e00f6a0d2deacdcbf6", null ],
    [ "tv_sec", "structlbm__timespec__t__stct.html#ae65f0542cc2b1d50ea8b67669013b716", null ]
];