var structlbm__src__event__sequence__number__info__t__stct =
[
    [ "first_sequence_number", "structlbm__src__event__sequence__number__info__t__stct.html#a99f1af068bde67ecfc7bafcef99d11c9", null ],
    [ "flags", "structlbm__src__event__sequence__number__info__t__stct.html#af2e42a69e0c78a9173a927493e3189c0", null ],
    [ "last_sequence_number", "structlbm__src__event__sequence__number__info__t__stct.html#a1746ec03d7a7034da58b63bc3d3b6ef2", null ],
    [ "msg_clientd", "structlbm__src__event__sequence__number__info__t__stct.html#a83b9b4f89f90021d3dfdb9f08639076d", null ]
];