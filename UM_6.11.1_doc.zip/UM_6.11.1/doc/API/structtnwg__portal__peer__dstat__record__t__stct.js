var structtnwg__portal__peer__dstat__record__t__stct =
[
    [ "ingress_cost", "structtnwg__portal__peer__dstat__record__t__stct.html#a4999b6c4c2c72e6ec670745c77afc0f0", null ],
    [ "local_interest_pcre_patterns", "structtnwg__portal__peer__dstat__record__t__stct.html#a281a7aea4f2f9b3e5e3e397ce82d8c2c", null ],
    [ "local_interest_regex_patterns", "structtnwg__portal__peer__dstat__record__t__stct.html#a77407d859436952d8624b5f606e120f6", null ],
    [ "local_interest_topics", "structtnwg__portal__peer__dstat__record__t__stct.html#a8ac56b5a60f89c2b00c5887996fb4c32", null ],
    [ "proxy_receivers", "structtnwg__portal__peer__dstat__record__t__stct.html#aa502124c97dc933b02e50b2064b4ccf0", null ],
    [ "proxy_sources", "structtnwg__portal__peer__dstat__record__t__stct.html#af1f1ac78fa5b8869bdaf19434d54452c", null ],
    [ "receive_stats", "structtnwg__portal__peer__dstat__record__t__stct.html#a44ec828ac976d4b94a38a535788c0194", null ],
    [ "receiver_pcre_patterns", "structtnwg__portal__peer__dstat__record__t__stct.html#aec454c98f3de0153ac1b9ad6ab9e7f8a", null ],
    [ "receiver_regex_patterns", "structtnwg__portal__peer__dstat__record__t__stct.html#a42a0a0ba4bf33e45745f2c9a93db6794", null ],
    [ "receiver_topics", "structtnwg__portal__peer__dstat__record__t__stct.html#ac35a82f4e8f64a8c53b5501910ff8c10", null ],
    [ "remote_interest_pcre_patterns", "structtnwg__portal__peer__dstat__record__t__stct.html#a6115e023024f55fc6c0e86495787cee7", null ],
    [ "remote_interest_regex_patterns", "structtnwg__portal__peer__dstat__record__t__stct.html#ab9d67b31a39bb553e5fbe63ab0052fb6", null ],
    [ "remote_interest_topics", "structtnwg__portal__peer__dstat__record__t__stct.html#a7b248f219806cb7d61b0c4c872ae683b", null ],
    [ "send_stats", "structtnwg__portal__peer__dstat__record__t__stct.html#acc7893c56b609e69466cd68ed6030927", null ]
];