var structlbm__flight__size__inflight__t__stct =
[
    [ "bytes", "structlbm__flight__size__inflight__t__stct.html#a60d168689960d5440a928be4a713ca42", null ],
    [ "messages", "structlbm__flight__size__inflight__t__stct.html#a522e9da02b989479411419ffffd04909", null ]
];