var structlbm__ume__rcv__recovery__info__ex__func__info__t__stct =
[
    [ "flags", "structlbm__ume__rcv__recovery__info__ex__func__info__t__stct.html#a5d897da3c7cd155300d77254f2b45ade", null ],
    [ "high_sequence_number", "structlbm__ume__rcv__recovery__info__ex__func__info__t__stct.html#a6365dff87b32b8f4e6e7e985d01acb75", null ],
    [ "low_rxreq_max_sequence_number", "structlbm__ume__rcv__recovery__info__ex__func__info__t__stct.html#ab8e05918a9c715b8edbd1e834815eb10", null ],
    [ "low_sequence_number", "structlbm__ume__rcv__recovery__info__ex__func__info__t__stct.html#a730df0455e0c47ec41434c5f0664e0be", null ],
    [ "source", "structlbm__ume__rcv__recovery__info__ex__func__info__t__stct.html#a108647bced4b79cf953ef1ad32649bc6", null ],
    [ "source_clientd", "structlbm__ume__rcv__recovery__info__ex__func__info__t__stct.html#a4a3feac0d75b46b6b18f1cc218432109", null ],
    [ "src_session_id", "structlbm__ume__rcv__recovery__info__ex__func__info__t__stct.html#af37c4a6aca08c78fb7154c53c0fbc467", null ]
];