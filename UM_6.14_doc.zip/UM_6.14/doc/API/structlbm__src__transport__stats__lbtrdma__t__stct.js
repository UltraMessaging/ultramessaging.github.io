var structlbm__src__transport__stats__lbtrdma__t__stct =
[
    [ "bytes_sent", "structlbm__src__transport__stats__lbtrdma__t__stct.html#a151a79638d74099e9bcf76eb637f12a8", null ],
    [ "msgs_sent", "structlbm__src__transport__stats__lbtrdma__t__stct.html#a93801d893f682792c4d6743bfc4b9359", null ],
    [ "num_clients", "structlbm__src__transport__stats__lbtrdma__t__stct.html#ade6e902d7414f2c28c65bbbbc6954289", null ]
];