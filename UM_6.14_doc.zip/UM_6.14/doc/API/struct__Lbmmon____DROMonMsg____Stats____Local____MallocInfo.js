var struct__Lbmmon____DROMonMsg____Stats____Local____MallocInfo =
[
    [ "arena", "struct__Lbmmon____DROMonMsg____Stats____Local____MallocInfo.html#adb1bc310e7737485216f0885d5d92c20", null ],
    [ "base", "struct__Lbmmon____DROMonMsg____Stats____Local____MallocInfo.html#ac18c1544ef5fdd889df7d5659b728d24", null ],
    [ "fordblks", "struct__Lbmmon____DROMonMsg____Stats____Local____MallocInfo.html#ad0dc8a7276a27bb5831a2bd47ee425de", null ],
    [ "hblkhd", "struct__Lbmmon____DROMonMsg____Stats____Local____MallocInfo.html#ad6e92c8983635a872a616ad1b070b6bb", null ],
    [ "hblks", "struct__Lbmmon____DROMonMsg____Stats____Local____MallocInfo.html#a4fc32b947c65bbc162d4962babce828c", null ],
    [ "ordblks", "struct__Lbmmon____DROMonMsg____Stats____Local____MallocInfo.html#a3cd137701dba126eacc3973f1d62536b", null ],
    [ "uordblks", "struct__Lbmmon____DROMonMsg____Stats____Local____MallocInfo.html#a61a5cf6404bea8e1ffe414ec103683db", null ]
];