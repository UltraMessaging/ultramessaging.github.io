var struct__Lbmmon____DROMonMsg____Stats =
[
    [ "base", "struct__Lbmmon____DROMonMsg____Stats.html#af31acbc1571260283dd066090a0c1577", null ],
    [ "local", "struct__Lbmmon____DROMonMsg____Stats.html#a5a81a81df3515d9b4595575d9e7db099", null ],
    [ "n_other_gateways", "struct__Lbmmon____DROMonMsg____Stats.html#a3011fabfd503186f869b640186f73ed2", null ],
    [ "n_portals", "struct__Lbmmon____DROMonMsg____Stats.html#ac254f23717a25ca8e924d9f30eea1366", null ],
    [ "other_gateways", "struct__Lbmmon____DROMonMsg____Stats.html#a5275839f5c3dfe82e553ef061cf15d13", null ],
    [ "portals", "struct__Lbmmon____DROMonMsg____Stats.html#a1b2dce4b343451f9c8bf43145cb3c90f", null ]
];