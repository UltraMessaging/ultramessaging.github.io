var struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____RcvStat =
[
    [ "base", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____RcvStat.html#a6ab952436a4b95930f682aa362c218dd", null ],
    [ "flags", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____RcvStat.html#a8d3dfaf1dd4a50b80c95da68891dd633", null ],
    [ "high_ack_sqn", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____RcvStat.html#a13ac7dae87a99021a2a8ebf9d333e6b8", null ],
    [ "last_activity_timestamp_sec", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____RcvStat.html#a5adf3800021f982f026e17336c34223c", null ],
    [ "rcv_regid", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____RcvStat.html#aaa50548cad08a111fcbd2b015ed81849", null ],
    [ "rcv_session_id", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____RcvStat.html#a7a94979c0fd4a11d98030fce1c134423", null ]
];