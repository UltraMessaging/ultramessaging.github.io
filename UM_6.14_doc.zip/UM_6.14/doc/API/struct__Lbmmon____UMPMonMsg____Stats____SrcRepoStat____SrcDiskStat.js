var struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____SrcDiskStat =
[
    [ "base", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____SrcDiskStat.html#a845736f8bcfb09b135102cca0187be50", null ],
    [ "max_offset", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____SrcDiskStat.html#a59a8a5b581030a66dab1da02d2534142", null ],
    [ "num_ios_pending", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____SrcDiskStat.html#ac0a8ecebeb392368c1b7583d5430a857", null ],
    [ "num_read_ios_pending", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____SrcDiskStat.html#af5644d18ac870ecb59ceb1a7c6dfc95e", null ],
    [ "offset", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____SrcDiskStat.html#ab5fe40c33c8d3d7b9f0dd9731391cadc", null ],
    [ "start_offset", "struct__Lbmmon____UMPMonMsg____Stats____SrcRepoStat____SrcDiskStat.html#a76e75ce1dd649ca9eb317bc4e7fc9d8f", null ]
];