var structlbm__ume__store__group__entry__t__stct =
[
    [ "group_size", "structlbm__ume__store__group__entry__t__stct.html#ad0fe672ed2c7478b8336e361b99ef748", null ],
    [ "index", "structlbm__ume__store__group__entry__t__stct.html#a994a567876b17683b2cf97eb4873de43", null ]
];