var structlbm__msg__ume__registration__ex__t__stct =
[
    [ "flags", "structlbm__msg__ume__registration__ex__t__stct.html#a2fd3cf7fdfdb852283cd8ba1cc0d1390", null ],
    [ "rcv_registration_id", "structlbm__msg__ume__registration__ex__t__stct.html#a3dbf592d420b0886e88c9e91e105d6e2", null ],
    [ "sequence_number", "structlbm__msg__ume__registration__ex__t__stct.html#ad929f9de34db02929bb4fd36c844c683", null ],
    [ "src_registration_id", "structlbm__msg__ume__registration__ex__t__stct.html#af2d83e279399169fe982c75ba97e3221", null ],
    [ "src_session_id", "structlbm__msg__ume__registration__ex__t__stct.html#a77ff5705b199b17de6255d218d662c7a", null ],
    [ "store", "structlbm__msg__ume__registration__ex__t__stct.html#ad1f15dfb96628720e538804b08f0aae0", null ],
    [ "store_index", "structlbm__msg__ume__registration__ex__t__stct.html#a46fc18fb82b632a259917e3c65790568", null ]
];