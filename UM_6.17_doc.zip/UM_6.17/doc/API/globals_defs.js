var globals_defs =
[
    [ "l", "globals_defs.html", null ],
    [ "m", "globals_defs_m.html", null ],
    [ "p", "globals_defs_p.html", null ],
    [ "s", "globals_defs_s.html", null ],
    [ "t", "globals_defs_t.html", null ],
    [ "u", "globals_defs_u.html", null ]
];