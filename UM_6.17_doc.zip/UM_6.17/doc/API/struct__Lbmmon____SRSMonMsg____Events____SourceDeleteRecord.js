var struct__Lbmmon____SRSMonMsg____Events____SourceDeleteRecord =
[
    [ "base", "struct__Lbmmon____SRSMonMsg____Events____SourceDeleteRecord.html#a27d1d6a450d6ea5c4b53ddb51a725ccb", null ],
    [ "source_info", "struct__Lbmmon____SRSMonMsg____Events____SourceDeleteRecord.html#a5027114c92821fe2c9d75b3193bc35de", null ]
];