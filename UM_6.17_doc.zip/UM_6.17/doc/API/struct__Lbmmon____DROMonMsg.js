var struct__Lbmmon____DROMonMsg =
[
    [ "attributes", "struct__Lbmmon____DROMonMsg.html#a04551eae5393eb849ce93577fec8153e", null ],
    [ "base", "struct__Lbmmon____DROMonMsg.html#a980594e8f08d2ae8b6ab7af5faacbfd5", null ],
    [ "configs", "struct__Lbmmon____DROMonMsg.html#a6425c14664f6cb6f91d51106572ffdd1", null ],
    [ "stats", "struct__Lbmmon____DROMonMsg.html#afa5aedb490045ffdd3c8ed5414cf7835", null ]
];