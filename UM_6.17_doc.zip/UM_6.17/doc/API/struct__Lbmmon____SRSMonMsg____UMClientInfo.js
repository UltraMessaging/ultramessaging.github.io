var struct__Lbmmon____SRSMonMsg____UMClientInfo =
[
    [ "base", "struct__Lbmmon____SRSMonMsg____UMClientInfo.html#a4e641a0eaa224ec3c61cc5508b9ca8a8", null ],
    [ "ip", "struct__Lbmmon____SRSMonMsg____UMClientInfo.html#affb9cd1b0ea5826547ef48d5dd857325", null ],
    [ "port", "struct__Lbmmon____SRSMonMsg____UMClientInfo.html#a4563b8224eb3cf3b2c584676b8f3a4e4", null ],
    [ "session_id", "struct__Lbmmon____SRSMonMsg____UMClientInfo.html#a156363c74d35a03662e9b8a74e25ff6f", null ]
];