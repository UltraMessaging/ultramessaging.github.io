var struct__Lbmmon____SRSMonMsg____Events____ReceiverDeleteRecord =
[
    [ "base", "struct__Lbmmon____SRSMonMsg____Events____ReceiverDeleteRecord.html#a0d24517f5816f709512f28aecc1fdc68", null ],
    [ "receiver_info", "struct__Lbmmon____SRSMonMsg____Events____ReceiverDeleteRecord.html#ad9485b13f3d58ab153b54a97d161a425", null ]
];