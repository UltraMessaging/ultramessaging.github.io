var struct__Lbmmon____SRSMonMsg____Events____WildcardReceiverDeleteRecord =
[
    [ "base", "struct__Lbmmon____SRSMonMsg____Events____WildcardReceiverDeleteRecord.html#a738e75aee0bac5b7df5ae1ab41e0370d", null ],
    [ "wildcard_receiver_info", "struct__Lbmmon____SRSMonMsg____Events____WildcardReceiverDeleteRecord.html#a281019c34938219c1e5424f4a25c49ba", null ]
];