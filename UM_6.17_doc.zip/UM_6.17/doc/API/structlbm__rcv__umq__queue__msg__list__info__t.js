var structlbm__rcv__umq__queue__msg__list__info__t =
[
    [ "msgs", "structlbm__rcv__umq__queue__msg__list__info__t.html#a4d27dfc2fbbf5214b712bb2409d574b5", null ],
    [ "num_msgs", "structlbm__rcv__umq__queue__msg__list__info__t.html#a87ffb63b5fef7924d11287e76480b4d6", null ]
];