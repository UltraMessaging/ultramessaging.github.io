var struct__Lbmmon____SRSMonMsg____Events____SourceLeaveRecord =
[
    [ "base", "struct__Lbmmon____SRSMonMsg____Events____SourceLeaveRecord.html#aedfb548ef5fa68f8b2763cad88fd67c4", null ],
    [ "source_info", "struct__Lbmmon____SRSMonMsg____Events____SourceLeaveRecord.html#a8297d3505f7214d7485088c3820a5915", null ]
];