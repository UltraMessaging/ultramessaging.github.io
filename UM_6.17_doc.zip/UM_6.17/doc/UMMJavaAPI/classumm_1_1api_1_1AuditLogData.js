var classumm_1_1api_1_1AuditLogData =
[
    [ "AuditLogData", "classumm_1_1api_1_1AuditLogData.html#a504b5191e018ad29290812aa72ec5fb2", null ],
    [ "getDate", "classumm_1_1api_1_1AuditLogData.html#a7aadf0d67e5cbe466909495c37e51a6b", null ],
    [ "getLog", "classumm_1_1api_1_1AuditLogData.html#ad50b500b75bfe692e0e0059424d6d83f", null ],
    [ "getUser", "classumm_1_1api_1_1AuditLogData.html#aa253a3bd7a9f07a23939ccd915723b42", null ],
    [ "setDate", "classumm_1_1api_1_1AuditLogData.html#aa31e731640e855fa9fa59a4c9f72b031", null ],
    [ "setLog", "classumm_1_1api_1_1AuditLogData.html#a2b1248cdbe0ba87b5049752061d20525", null ],
    [ "setUser", "classumm_1_1api_1_1AuditLogData.html#aeaa95dc8f46d17eafc7754db53287f21", null ]
];