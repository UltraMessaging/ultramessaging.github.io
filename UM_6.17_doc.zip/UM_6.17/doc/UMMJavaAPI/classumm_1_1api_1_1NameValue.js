var classumm_1_1api_1_1NameValue =
[
    [ "NameValue", "classumm_1_1api_1_1NameValue.html#a41478018ac26223b5b8d7c8f87e4bf17", null ],
    [ "NameValue", "classumm_1_1api_1_1NameValue.html#aedd0a5d344f329acb79082079044703c", null ],
    [ "NameValue", "classumm_1_1api_1_1NameValue.html#aa013abeb36fc6e0b954fab3eb8268dca", null ],
    [ "equals", "classumm_1_1api_1_1NameValue.html#a2d777010fe33c3fcf5474dd06cde12d1", null ],
    [ "getName", "classumm_1_1api_1_1NameValue.html#a99cd2bfffe49d7c21ac252b2b2e034d2", null ],
    [ "getToolTip", "classumm_1_1api_1_1NameValue.html#ac4faaef68c7ba6c0a54609c7d9089ce0", null ],
    [ "getValue", "classumm_1_1api_1_1NameValue.html#ad3828be0e2a950513211e4fcc671a627", null ],
    [ "setName", "classumm_1_1api_1_1NameValue.html#aa2f598e6e7cb184e3b43dce48b32b639", null ],
    [ "setToolTip", "classumm_1_1api_1_1NameValue.html#a7e4b318a3303370d7d20433766b88f39", null ],
    [ "setValue", "classumm_1_1api_1_1NameValue.html#a69e44e423bb1d129f50ba911ac450516", null ],
    [ "toString", "classumm_1_1api_1_1NameValue.html#a38438de29b58b112eab2c386a48175e5", null ]
];