var NAVTREE =
[
  [ "UMDS Release Notes", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "UMDS Version 6.12", "umdsversion6_12.html", [
      [ "Enhancements for UMDS 6.12", "umdsversion6_12.html#enhancementsforumds6_12", null ],
      [ "Fixed Limitations for UMDS 6.12", "umdsversion6_12.html#fixedlimitationsforumds6_12", null ]
    ] ],
    [ "Known Limitations for UMDS", "knownlimitationsforumds.html", null ],
    [ "UMDS Version 6.0", "umdsversion6_0.html", [
      [ "Enhancements for UMDS 6.0", "umdsversion6_0.html#enhancementsforumds6_0", null ],
      [ "Fixed Limitations for UMDS 6.0", "umdsversion6_0.html#fixedlimitationsforumds6_0", null ]
    ] ],
    [ "UMSD Version 6.0.200", "umdsversion6_0_200.html", [
      [ "Enhancements for 6.0.200", "umdsversion6_0_200.html#enhancementsforumds6_0_200", null ],
      [ "Fixed Limitations for 6.0.200", "umdsversion6_0_200.html#fixedlimitationsforumds6_0_200", null ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';