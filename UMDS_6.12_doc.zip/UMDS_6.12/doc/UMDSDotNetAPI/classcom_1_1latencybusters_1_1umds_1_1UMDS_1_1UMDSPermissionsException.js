var classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException =
[
    [ "UMDSPermissionsException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException.html#a3468071e678101f3b81aaeb4154a1e70", null ],
    [ "UMDSPermissionsException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException.html#ab02339e702ea61ee87323f6f7b6d668b", null ],
    [ "dump_last_stack", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException.html#a6422e071f2d199872e46d1e032dfd5b1", null ],
    [ "dump_stacks", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException.html#a1938afca7584133cb75265c0b51cd2f9", null ]
];