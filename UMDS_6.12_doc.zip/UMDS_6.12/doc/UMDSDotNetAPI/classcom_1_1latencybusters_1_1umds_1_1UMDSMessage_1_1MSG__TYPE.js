var classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE =
[
    [ "CONFIGURATION_ERROR", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#ac55d0075028a2c6a2ae213626f735b82", null ],
    [ "CONNECT", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a197073dfe170158bd9f75a392d44d120", null ],
    [ "DATA", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a72c6949ce245ad699e452955d13ee7e1", null ],
    [ "DISCONNECT", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a265bbe3d7aefad0ad43cb830fe91eada", null ],
    [ "LOGIN_COMPLETE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#af3468005585150a3e3b4d3d81d443552", null ],
    [ "LOGIN_DENIED", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a9d33317a96e86b3e3a6c47f587488fb9", null ],
    [ "LOGOUT_COMPLETE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a9ab4c1ccea5c5ebf411351ab5538be83", null ],
    [ "LOSS", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#aaddddf57259bde0d618bdc8b6ed5efad", null ],
    [ "RECEIVER_CREATE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#ab43725e2ec354a5ca4f079184758c086", null ],
    [ "RECEIVER_DELETE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#af5996b446f8b229e3d0dbede1f1add20", null ],
    [ "REQUEST", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#ad6cc1a77b449a2fb914bdd7854b1171b", null ],
    [ "REQUEST_CANCELED", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a00e2a4a888a4f01b5f290d8e796508bd", null ],
    [ "RESPONSE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a1c48fff4b6899c1ba8d0b4c8d7cb17f0", null ],
    [ "SERVER_DENIED", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a0ca62d52d1e4672ce3fb02c2e383374a", null ],
    [ "SERVER_STOPPED", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#ade8a1e24a56a3d725607dd0d1864e8ee", null ],
    [ "SOURCE_CREATE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#acb2f7cc41356bc7dca8c7b7897da3475", null ],
    [ "SOURCE_DELETE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a17bdc6e4f51a53efa1a2021fbf90159c", null ],
    [ "STABLE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a19bac434383cff46dc270494d5df9cd7", null ]
];