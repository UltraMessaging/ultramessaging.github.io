var classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE =
[
    [ "AUTHENTICATION_FAILURE", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#a57b2688742e944aa8a66aa90ea5c0bb5", null ],
    [ "CAPABILITY_MISMATCH", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#a00ff3a4637ff5d0179ab4f953f9ad62d", null ],
    [ "MISSING_CALLBACK", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#a64ff7ee521e4bb2497e67508af0f129d", null ],
    [ "NO_ERROR", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#a9231f447abafa67081ce6f11279533c0", null ],
    [ "SERVER_OPERATION_FAILED", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#a8b6d16179b47ab990327c5782355b0e7", null ],
    [ "UNKNOWN_PROPERTY", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#a25c390266e5d33cd020c45620c4c3866", null ]
];