var classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException =
[
    [ "UMDSPermissionsException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException.html#ab26353c90ce873f368b6f8b10bd0addc", null ],
    [ "UMDSPermissionsException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException.html#a193a94ce76f630a4c9f12b68b64aa588", null ],
    [ "dump_last_stack", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException.html#a0534b8402d8ddabdf265dd1bd8ab65a2", null ],
    [ "dump_stacks", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException.html#a27924232c7fd632452a2c7be120e4080", null ]
];