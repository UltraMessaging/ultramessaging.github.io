var hierarchy =
[
    [ "com.latencybusters.umds.UMDS.ERRCODE", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html", null ],
    [ "Exception", null, [
      [ "com.latencybusters.umds.UMDS.UMDSException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSException.html", [
        [ "com.latencybusters.umds.UMDS.UMDSAuthenticationException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSAuthenticationException.html", null ],
        [ "com.latencybusters.umds.UMDS.UMDSBadStateException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSBadStateException.html", null ],
        [ "com.latencybusters.umds.UMDS.UMDSDisconnectException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSDisconnectException.html", null ],
        [ "com.latencybusters.umds.UMDS.UMDSNoDataException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSNoDataException.html", null ],
        [ "com.latencybusters.umds.UMDS.UMDSPermissionsException", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1UMDSPermissionsException.html", null ]
      ] ]
    ] ],
    [ "com.latencybusters.umds.UMDS.LOG_LEVEL", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL.html", null ],
    [ "com.latencybusters.umds.UMDSMessage.MSG_STATUS", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__STATUS.html", null ],
    [ "com.latencybusters.umds.UMDSMessage.MSG_TYPE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html", null ],
    [ "com.latencybusters.umds.UMDSMessageFormatter.MsgType", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessageFormatter_1_1MsgType.html", null ],
    [ "com.latencybusters.umds.UMDS", "classcom_1_1latencybusters_1_1umds_1_1UMDS.html", null ],
    [ "com.latencybusters.umds.UMDSMessage", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage.html", null ],
    [ "com.latencybusters.umds.UMDSMessageOptions", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessageOptions.html", null ],
    [ "com.latencybusters.umds.UMDSReceiver", "classcom_1_1latencybusters_1_1umds_1_1UMDSReceiver.html", [
      [ "com.latencybusters.umds.UMDSWildcardReceiver", "classcom_1_1latencybusters_1_1umds_1_1UMDSWildcardReceiver.html", null ]
    ] ],
    [ "com.latencybusters.umds.UMDSServerConnection", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html", null ],
    [ "com.latencybusters.umds.UMDSSource", "classcom_1_1latencybusters_1_1umds_1_1UMDSSource.html", null ]
];