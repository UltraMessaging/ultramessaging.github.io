var annotated_dup =
[
    [ "com", null, [
      [ "latencybusters", null, [
        [ "umds", null, [
          [ "UMDS", "classcom_1_1latencybusters_1_1umds_1_1UMDS.html", "classcom_1_1latencybusters_1_1umds_1_1UMDS" ],
          [ "UMDSMessage", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage" ],
          [ "UMDSMessageOptions", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessageOptions.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessageOptions" ],
          [ "UMDSReceiver", "classcom_1_1latencybusters_1_1umds_1_1UMDSReceiver.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSReceiver" ],
          [ "UMDSServerConnection", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection" ],
          [ "UMDSSource", "classcom_1_1latencybusters_1_1umds_1_1UMDSSource.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSSource" ],
          [ "UMDSWildcardReceiver", "classcom_1_1latencybusters_1_1umds_1_1UMDSWildcardReceiver.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSWildcardReceiver" ]
        ] ]
      ] ]
    ] ]
];