var NAVTREE =
[
  [ "UMDS Quick Start", "index.html", [
    [ "Introduction", "index.html#firstsect", null ],
    [ "UMDS Quick Overview", "index.html#umdsquickoverview", [
      [ "UMDS Server Installation", "index.html#umdsserverinstallation", null ],
      [ "UMDS Client Installation", "index.html#umdsclientinstallation", null ]
    ] ],
    [ "Configuring the UMDS Server", "index.html#configuringtheumdsserver", null ],
    [ "Starting the UMDS Server", "index.html#startingtheumdsserver", null ],
    [ "Running UMDS Example Applications", "index.html#runningumdsexampleapplications", [
      [ "Windows Java Example", "index.html#windowsjavaexample", null ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';