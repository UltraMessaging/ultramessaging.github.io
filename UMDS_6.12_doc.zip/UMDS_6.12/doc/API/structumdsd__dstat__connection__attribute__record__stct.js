var structumdsd__dstat__connection__attribute__record__stct =
[
    [ "attribute_name", "structumdsd__dstat__connection__attribute__record__stct.html#aae08b9037a63c9a33eaa34e7dfac3868", null ],
    [ "val", "structumdsd__dstat__connection__attribute__record__stct.html#aac39f7542887d2a724f15ee554826030", null ]
];