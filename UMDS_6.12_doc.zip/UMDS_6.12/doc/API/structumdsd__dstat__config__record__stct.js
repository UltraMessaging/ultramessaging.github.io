var structumdsd__dstat__config__record__stct =
[
    [ "data", "structumdsd__dstat__config__record__stct.html#a0ac153076d58ca6c588a979ce4ac4dee", null ]
];