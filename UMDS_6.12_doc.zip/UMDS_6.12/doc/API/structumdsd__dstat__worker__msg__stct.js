var structumdsd__dstat__worker__msg__stct =
[
    [ "hdr", "structumdsd__dstat__worker__msg__stct.html#aad57101997b6809e83294d391db80de0", null ],
    [ "record", "structumdsd__dstat__worker__msg__stct.html#aa47f454f73c07fac7472a3f64c40c25b", null ]
];