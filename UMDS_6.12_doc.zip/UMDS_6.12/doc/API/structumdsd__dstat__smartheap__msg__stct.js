var structumdsd__dstat__smartheap__msg__stct =
[
    [ "hdr", "structumdsd__dstat__smartheap__msg__stct.html#a309eb368ba13312107a065ebb3ff62b8", null ],
    [ "record", "structumdsd__dstat__smartheap__msg__stct.html#a551d77e36b255eefbe9394a77ce372c3", null ]
];