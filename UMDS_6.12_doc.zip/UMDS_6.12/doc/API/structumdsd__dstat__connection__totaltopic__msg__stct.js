var structumdsd__dstat__connection__totaltopic__msg__stct =
[
    [ "hdr", "structumdsd__dstat__connection__totaltopic__msg__stct.html#aee9fd33bbf98728527e0a899f875b15b", null ],
    [ "record", "structumdsd__dstat__connection__totaltopic__msg__stct.html#a0feaa57537de760a105cab1b745319f1", null ]
];