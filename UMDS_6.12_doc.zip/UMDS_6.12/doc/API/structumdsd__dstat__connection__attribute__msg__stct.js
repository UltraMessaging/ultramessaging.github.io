var structumdsd__dstat__connection__attribute__msg__stct =
[
    [ "attr", "structumdsd__dstat__connection__attribute__msg__stct.html#af402b3f115de04ab34f3ce38432d270b", null ],
    [ "hdr", "structumdsd__dstat__connection__attribute__msg__stct.html#ae6ab9f76a00b44d28875417f4f8320b2", null ]
];