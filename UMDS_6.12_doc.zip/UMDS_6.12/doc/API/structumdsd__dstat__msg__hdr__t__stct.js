var structumdsd__dstat__msg__hdr__t__stct =
[
    [ "connId", "structumdsd__dstat__msg__hdr__t__stct.html#ab88b415a95b68a833ae0b71ae2420930", null ],
    [ "length", "structumdsd__dstat__msg__hdr__t__stct.html#a851dbe95f043c1910fdb7e6335c0de8b", null ],
    [ "magic", "structumdsd__dstat__msg__hdr__t__stct.html#a567d5d9e380a8c7380d08737c1af23ca", null ],
    [ "tv_sec", "structumdsd__dstat__msg__hdr__t__stct.html#a60747d97c398468f66bd96f017421c99", null ],
    [ "tv_usec", "structumdsd__dstat__msg__hdr__t__stct.html#a9527be4f6be9d91e3372c8dfe623ff7c", null ],
    [ "type", "structumdsd__dstat__msg__hdr__t__stct.html#af2f8d7475aefdf03b96db6778ef8a63c", null ],
    [ "version", "structumdsd__dstat__msg__hdr__t__stct.html#ac9b12f6de30473e06855ec0f300c7001", null ],
    [ "workerId", "structumdsd__dstat__msg__hdr__t__stct.html#a1a6c94b04040dae44c9e195129d8926a", null ]
];