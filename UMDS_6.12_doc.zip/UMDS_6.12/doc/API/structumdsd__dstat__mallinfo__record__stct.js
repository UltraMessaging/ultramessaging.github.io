var structumdsd__dstat__mallinfo__record__stct =
[
    [ "arena", "structumdsd__dstat__mallinfo__record__stct.html#ac02044e598aca9e91d853549f395a6a3", null ],
    [ "fordblks", "structumdsd__dstat__mallinfo__record__stct.html#a571672172564f8a3cff493897ba36707", null ],
    [ "hblkhd", "structumdsd__dstat__mallinfo__record__stct.html#a43b7d13ae5b7199dd52b49ccd0a91129", null ],
    [ "hblks", "structumdsd__dstat__mallinfo__record__stct.html#a796d309a37dee4f13c7eb65f9e42c9d8", null ],
    [ "ordblks", "structumdsd__dstat__mallinfo__record__stct.html#a81fbbe7b8f6d8e836004269c62947398", null ],
    [ "uordblks", "structumdsd__dstat__mallinfo__record__stct.html#a2b54c15fdfe3684ae852b15b82c14489", null ]
];