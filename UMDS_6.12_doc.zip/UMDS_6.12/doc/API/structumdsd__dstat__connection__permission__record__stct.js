var structumdsd__dstat__connection__permission__record__stct =
[
    [ "permission_name", "structumdsd__dstat__connection__permission__record__stct.html#a00587a8ce0d34d749626198d7c46f21e", null ],
    [ "val", "structumdsd__dstat__connection__permission__record__stct.html#a2b04c3219c5d356d11b29ec32cd4dcd4", null ]
];