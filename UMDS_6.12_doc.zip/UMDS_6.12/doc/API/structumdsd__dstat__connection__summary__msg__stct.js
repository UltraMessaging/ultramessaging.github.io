var structumdsd__dstat__connection__summary__msg__stct =
[
    [ "hdr", "structumdsd__dstat__connection__summary__msg__stct.html#a7281fb571b80212c6c19b1664ba037c2", null ],
    [ "record", "structumdsd__dstat__connection__summary__msg__stct.html#a1c1a969ae1bea0785c404409f4e5324f", null ]
];