var structumdsd__dstat__connection__receiver__record__stct =
[
    [ "topic", "structumdsd__dstat__connection__receiver__record__stct.html#ab03036cd3a5d45241b69848c0e43c61b", null ],
    [ "topicQ_id", "structumdsd__dstat__connection__receiver__record__stct.html#a686664ba259ee80b25834a8436beeb4d", null ]
];