var structumdsd__dstat__worker__record__stct =
[
    [ "num_connections", "structumdsd__dstat__worker__record__stct.html#a0cfe06dd15a5bfbca2203e25aa48750c", null ],
    [ "workerId", "structumdsd__dstat__worker__record__stct.html#af597e5137864af64251d95d1a753f652", null ]
];