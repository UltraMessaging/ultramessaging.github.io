var structumdsd__dstat__smartheap__record__stct =
[
    [ "maj_ver", "structumdsd__dstat__smartheap__record__stct.html#a271b51a8a709f5270c308be0cff60bf5", null ],
    [ "min_ver", "structumdsd__dstat__smartheap__record__stct.html#a14abfcada4b423493fa91c855c3af0b3", null ],
    [ "pagesize", "structumdsd__dstat__smartheap__record__stct.html#aeaea00bdfb5aa3242ccfe0e0434662c4", null ],
    [ "poolcount", "structumdsd__dstat__smartheap__record__stct.html#a272d08b54566be6bbdc9d11cb42212bd", null ],
    [ "poolsize", "structumdsd__dstat__smartheap__record__stct.html#acf14d1b200ad266daed704aa26b3b536", null ],
    [ "smallblocksize", "structumdsd__dstat__smartheap__record__stct.html#aebc150f1aeb4333b5f1e4b13d77cad19", null ],
    [ "upd_ver", "structumdsd__dstat__smartheap__record__stct.html#a11411612ead251b1091b791376f36e94", null ]
];