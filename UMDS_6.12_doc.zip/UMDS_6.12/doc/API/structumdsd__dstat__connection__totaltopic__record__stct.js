var structumdsd__dstat__connection__totaltopic__record__stct =
[
    [ "tot_control_bytes_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a707e415febf4f2a009e72b133915defb", null ],
    [ "tot_control_msgs_cur_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#ae41aadc39b0798c9ddcb37ba6c44381c", null ],
    [ "tot_control_msgs_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a8159fd22dcae408edf85e986d88880f8", null ],
    [ "tot_data_bytes_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a457408fba8a5ab7a3e641f7810bb5239", null ],
    [ "tot_data_msgs_cur_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#af9ee94bca4f13229df275e7bd5aeafdd", null ],
    [ "tot_data_msgs_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a90c7d8de75690bc562517a24084f81fa", null ],
    [ "tot_loss_msgs_cur_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a57e883f180d355f49150d7309e9cfb09", null ],
    [ "tot_loss_msgs_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a0226de307c48f23fe0c26853c79f50f3", null ],
    [ "tot_req_bytes_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#ab74d7e7647fcb15e6273a9fb1905bd17", null ],
    [ "tot_req_msgs_cur_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a14672af2f864e7378563777399145c4b", null ],
    [ "tot_req_msgs_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a5e436a9d0e4dcf13a1fd2d61313ea8b0", null ],
    [ "tot_resp_bytes_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#aed8d2b35b20e7325128e694eda697d63", null ],
    [ "tot_resp_msgs_cur_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a7f454082785cfbfa3a14d4067c41bce8", null ],
    [ "tot_resp_msgs_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#aeb0efe21570179a91b3c8af497a8025a", null ],
    [ "total_bytes_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a4413f7ac24c177724195e1e9914fc5f6", null ],
    [ "total_msgs_cur_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a6459a943203b297a01ed65503dfd2417", null ],
    [ "total_msgs_ever_enq", "structumdsd__dstat__connection__totaltopic__record__stct.html#a4781a03c0d41967c39595e9072be089f", null ],
    [ "total_msgs_lost", "structumdsd__dstat__connection__totaltopic__record__stct.html#a410fb77732a4688102ab0f820c0d5f31", null ],
    [ "total_user_msgs_tossed_for_age", "structumdsd__dstat__connection__totaltopic__record__stct.html#a7b3cd5a2c43a3570cd7a9628852f8c3e", null ],
    [ "total_user_msgs_tossed_for_size", "structumdsd__dstat__connection__totaltopic__record__stct.html#af25c57a189b8d44f4becbd4aa1548a05", null ]
];