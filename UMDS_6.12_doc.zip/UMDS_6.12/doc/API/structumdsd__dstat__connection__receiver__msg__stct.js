var structumdsd__dstat__connection__receiver__msg__stct =
[
    [ "hdr", "structumdsd__dstat__connection__receiver__msg__stct.html#a842bb6dfe054bfee41d49c1b690df016", null ],
    [ "record", "structumdsd__dstat__connection__receiver__msg__stct.html#a4cd03a432f402f07be29fcdae22a142f", null ]
];