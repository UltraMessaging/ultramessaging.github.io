var classcom_1_1latencybusters_1_1lbm_1_1LBMFlightSizeInflightInfo =
[
    [ "getBytes", "classcom_1_1latencybusters_1_1lbm_1_1LBMFlightSizeInflightInfo.html#aba2c96205db9618ff51b3bc27f5bd098", null ],
    [ "getMessages", "classcom_1_1latencybusters_1_1lbm_1_1LBMFlightSizeInflightInfo.html#a61a250259a72f22af9a0781401c7e6d5", null ],
    [ "setBytes", "classcom_1_1latencybusters_1_1lbm_1_1LBMFlightSizeInflightInfo.html#a312443f5e2dda374a789c4a732d49e70", null ],
    [ "setMessages", "classcom_1_1latencybusters_1_1lbm_1_1LBMFlightSizeInflightInfo.html#ad9512dc4d7364c665c643abf9364c2f7", null ]
];