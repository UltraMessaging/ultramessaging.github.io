var interfacecom_1_1latencybusters_1_1lbm_1_1LBMZeroTransportsCallback =
[
    [ "onZeroTransports", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMZeroTransportsCallback.html#ad363fa893eb6a85c3680431c71d340c2", null ]
];