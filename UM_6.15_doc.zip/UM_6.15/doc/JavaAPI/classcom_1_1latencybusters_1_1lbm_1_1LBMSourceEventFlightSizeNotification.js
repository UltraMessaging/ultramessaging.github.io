var classcom_1_1latencybusters_1_1lbm_1_1LBMSourceEventFlightSizeNotification =
[
    [ "LBMSourceEventFlightSizeNotification", "classcom_1_1latencybusters_1_1lbm_1_1LBMSourceEventFlightSizeNotification.html#a5b43b8888c4178054c4027e7c48b9b2c", null ],
    [ "state", "classcom_1_1latencybusters_1_1lbm_1_1LBMSourceEventFlightSizeNotification.html#a89b60e3e13c204d1e7751901816a215f", null ],
    [ "type", "classcom_1_1latencybusters_1_1lbm_1_1LBMSourceEventFlightSizeNotification.html#aad62c4e263f7cdfd9fa1aa4e6379ab7e", null ]
];