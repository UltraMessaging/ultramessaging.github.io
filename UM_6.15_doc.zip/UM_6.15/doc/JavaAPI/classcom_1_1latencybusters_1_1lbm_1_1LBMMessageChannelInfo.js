var classcom_1_1latencybusters_1_1lbm_1_1LBMMessageChannelInfo =
[
    [ "channelFlags", "classcom_1_1latencybusters_1_1lbm_1_1LBMMessageChannelInfo.html#ab5356d38e1d9f2622020101c5295bd5d", null ],
    [ "channelNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMMessageChannelInfo.html#a879cb93490c5959849788bd06b70bfde", null ]
];