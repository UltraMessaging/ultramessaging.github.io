var interfacecom_1_1latencybusters_1_1lbm_1_1LBMWildcardReceiverCreateCallback =
[
    [ "onReceiverCreate", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMWildcardReceiverCreateCallback.html#ac3b8cff7838653329b5f9c609097f4e3", null ]
];