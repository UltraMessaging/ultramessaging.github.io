var classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorEInvalException =
[
    [ "LBMMonitorEInvalException", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorEInvalException.html#ade3621fca5cd819fa4510fd7863d3906", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorEInvalException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];