var classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorELBMFailException =
[
    [ "LBMMonitorELBMFailException", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorELBMFailException.html#ac18401bbd3eadc5710aba3fe142b6474", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorELBMFailException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];