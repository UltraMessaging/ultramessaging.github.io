var classcom_1_1latencybusters_1_1lbm_1_1UMENoRegException =
[
    [ "UMENoRegException", "classcom_1_1latencybusters_1_1lbm_1_1UMENoRegException.html#adb100eacb4a06af4da6c043bfb0fb515", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1UMENoRegException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];