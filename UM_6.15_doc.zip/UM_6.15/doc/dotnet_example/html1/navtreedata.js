var NAVTREE =
[
  [ ".NET Examples", "index.html", [
    [ "Introduction", "index.html#firstsect", [
      [ ".NET Examples Introduction", "index.html#csexamplesintroduction", null ],
      [ "Configuring .NET Examples", "index.html#configuringdotnetexamples", null ],
      [ "Unhandled C# Events", "index.html#unhandledcsevents", null ],
      [ "C# Examples", "index.html#csexamples", [
        [ "Example lbmExampleUtil.cs", "index.html#examplelbmExampleUtil_cs", null ],
        [ "Example lbmhfxrcv.cs", "index.html#examplelbmhfxrcv_cs", null ],
        [ "Example lbmimsg.cs", "index.html#examplelbmimsg_cs", null ],
        [ "Example lbmlatping.cs", "index.html#examplelbmlatping_cs", null ],
        [ "Example lbmlatpong.cs", "index.html#examplelbmlatpong_cs", null ],
        [ "Example lbmmon.cs", "index.html#examplelbmmon_cs", null ],
        [ "Example lbmmrcv.cs", "index.html#examplelbmmrcv_cs", null ],
        [ "Example lbmmsrc.cs", "index.html#examplelbmmsrc_cs", null ],
        [ "Example lbmpong.cs", "index.html#examplelbmpong_cs", null ],
        [ "Example lbmrcv.cs", "index.html#examplelbmrcv_cs", null ],
        [ "Example lbmrcvxsp.cs", "index.html#examplelbmrcvxsp_cs", null ],
        [ "Example lbmreq.cs", "index.html#examplelbmreq_cs", null ],
        [ "Example lbmresp.cs", "index.html#examplelbmresp_cs", null ],
        [ "Example lbmsrc.cs", "index.html#examplelbmsrc_cs", null ],
        [ "Example lbmStatistics.cs", "index.html#examplelbmStatistics_cs", null ],
        [ "Example lbmtrreq.cs", "index.html#examplelbmtrreq_cs", null ],
        [ "Example lbmwrcv.cs", "index.html#examplelbmwrcv_cs", null ],
        [ "Example MinRcv.cs", "index.html#exampleMinRcv_cs", null ],
        [ "Example MinSrc.cs", "index.html#exampleMinSrc_cs", null ],
        [ "Example umercv.cs", "index.html#exampleumercv_cs", null ],
        [ "Example umesrc.cs", "index.html#exampleumesrc_cs", null ],
        [ "Example umqrcv.cs", "index.html#exampleumqrcv_cs", null ],
        [ "Example umqsrc.cs", "index.html#exampleumqsrc_cs", null ],
        [ "Example VerifiableMessage.cs", "index.html#exampleVerifiableMessage_cs", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';