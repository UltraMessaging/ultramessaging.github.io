var classcom_1_1latencybusters_1_1lbm_1_1UMQRegistrationCompleteInfo =
[
    [ "UMQRegistrationCompleteInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMQRegistrationCompleteInfo.html#a44dd6c1f7b31aabe68c74479df38f170", null ],
    [ "assignmentId", "classcom_1_1latencybusters_1_1lbm_1_1UMQRegistrationCompleteInfo.html#abe8d2dbcc85b5988ecf52985b75001c8", null ],
    [ "flags", "classcom_1_1latencybusters_1_1lbm_1_1UMQRegistrationCompleteInfo.html#aa240073b40f4198272a411d9d0c2cf4c", null ],
    [ "queueId", "classcom_1_1latencybusters_1_1lbm_1_1UMQRegistrationCompleteInfo.html#a705b18cf452a13f6a716ed55185e8f39", null ],
    [ "queueName", "classcom_1_1latencybusters_1_1lbm_1_1UMQRegistrationCompleteInfo.html#a37a531aa7cde65ed22debdf3c6238aea", null ]
];