var classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorELBMFailException =
[
    [ "LBMMonitorELBMFailException", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorELBMFailException.html#af249907e278472f6003261d8a492bf73", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorELBMFailException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];