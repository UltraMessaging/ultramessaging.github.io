var classcom_1_1latencybusters_1_1lbm_1_1LBMMessageObjectFactory =
[
    [ "create", "classcom_1_1latencybusters_1_1lbm_1_1LBMMessageObjectFactory.html#a325b995249ce7f499609f8638970263c", null ]
];