var classcom_1_1latencybusters_1_1lbm_1_1LBMReceiverStatisticsObjectFactory =
[
    [ "create", "classcom_1_1latencybusters_1_1lbm_1_1LBMReceiverStatisticsObjectFactory.html#ab62589b828bd6f2ad613b207f266af7e", null ]
];