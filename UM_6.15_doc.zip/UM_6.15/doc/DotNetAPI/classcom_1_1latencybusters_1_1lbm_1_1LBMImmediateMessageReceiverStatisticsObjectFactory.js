var classcom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageReceiverStatisticsObjectFactory =
[
    [ "create", "classcom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageReceiverStatisticsObjectFactory.html#a79078e380274eba13d24f61871fc7cdc", null ]
];