var classcom_1_1latencybusters_1_1lbm_1_1LBMEventQueueStatisticsObjectFactory =
[
    [ "create", "classcom_1_1latencybusters_1_1lbm_1_1LBMEventQueueStatisticsObjectFactory.html#acbdda7eb41e941c636d03c8e481571bd", null ]
];