var NAVTREE =
[
  [ "UM .NET API", "index.html", [
    [ "Introduction", "index.html", [
      [ "UM .NET API", "index.html#umnetapi", [
        [ "Application Callbacks in .NET", "index.html#applicationcallbacksinnet", null ],
        [ "Using UM .NET on Windows", "index.html#usingumnetonwindows", null ],
        [ "Using UM .NET on Linux", "index.html#usingumnetonlinux", null ]
      ] ]
    ] ],
    [ "Packages", null, [
      [ "Packages", "namespaces.html", "namespaces" ],
      [ "Package Functions", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Properties", "functions_prop.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"classcom_1_1latencybusters_1_1lbm_1_1LBM.html#adda9e1ac033156d2ac9d943bd600b138",
"classcom_1_1latencybusters_1_1lbm_1_1LBMEventQueue.html#a96b8ad0d97d96be5fa734e7675b4c785",
"classcom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageReceiverStatistics.html#acb962215aaeb20d2d8ccbf9048d6943e",
"classcom_1_1latencybusters_1_1lbm_1_1LBMNewTransportInfo.html#a995d6c0bfecc8915f1a4761e6f7e9b93",
"classcom_1_1latencybusters_1_1lbm_1_1LBMResolverEventAdvertisement.html#ad5f4955f425c8f0e613890ebb031a7d9",
"classcom_1_1latencybusters_1_1lbm_1_1LBMWildcardReceiver.html#ae6ca629ec35010775f230236f6ced5d2",
"classcom_1_1latencybusters_1_1lbm_1_1UMQSourceEventULBMessageInfo.html",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayDecimal.html#abfdab70130ee20f479e666955befaaee",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayInt16.html#adfb487730b85b2585e2297383dc3fee0",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayInt8.html#ae79802145cd49ef0324918e25fd00984",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayUint16.html#a0386a17cf3f54337dfebef61b46cac8f",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayUint8.html#a0cf932eb36099d8991ec2247c965b75b",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldBlob.html#a1d57f99dc7b116414372376df345e24f",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldDouble.html#a8dbe1c12c86b80d8476e72a61197e4a9",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldInt64.html",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldString.html#a47e759185c748e0c1114da82aa56696a",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldUint32.html#aa9552f87313230db05488b6f990c5cd4",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFields.html#a5385943298807b324d25eab6b67d447d",
"classcom_1_1latencybusters_1_1pdm_1_1PDMDefinition.html#a3d7fcaa5f9340bead5b858ca48e6eeca",
"classcom_1_1latencybusters_1_1pdm_1_1PDMMessage.html#a68f50bfd0fdf292d5d6c490f20cf3235"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';