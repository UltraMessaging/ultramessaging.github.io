var structumestore__smart__heap__dmon__stat__msg__t__stct =
[
    [ "hdr", "structumestore__smart__heap__dmon__stat__msg__t__stct.html#a737ffeb2ed63047687c4d1c2d57acb19", null ],
    [ "mem_major_version", "structumestore__smart__heap__dmon__stat__msg__t__stct.html#a9dd788b317c5788aabcedd027759d71c", null ],
    [ "mem_minor_version", "structumestore__smart__heap__dmon__stat__msg__t__stct.html#ad54e38d11d6ad85ae0cffd3f7b100a20", null ],
    [ "mem_update_version", "structumestore__smart__heap__dmon__stat__msg__t__stct.html#a3fa4ad9bff20110507ef19c05a29c309", null ],
    [ "pageSize", "structumestore__smart__heap__dmon__stat__msg__t__stct.html#a94e3c2c157d0fed277ef8252e657b08b", null ],
    [ "poolcount", "structumestore__smart__heap__dmon__stat__msg__t__stct.html#a5be5c1fad7f6e424dad789077b6f5e69", null ],
    [ "poolsize", "structumestore__smart__heap__dmon__stat__msg__t__stct.html#a718428df16bf5d02ef9acf5b7be2e951", null ],
    [ "smallBlockSize", "structumestore__smart__heap__dmon__stat__msg__t__stct.html#ac4ee991aebcccb087743e46d0a6c8268", null ],
    [ "umestored_version_buffer", "structumestore__smart__heap__dmon__stat__msg__t__stct.html#a0b238725ca7b9a442e2a37ad3c03a8fc", null ]
];