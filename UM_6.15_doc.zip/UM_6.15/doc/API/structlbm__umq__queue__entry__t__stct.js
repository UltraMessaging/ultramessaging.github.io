var structlbm__umq__queue__entry__t__stct =
[
    [ "name", "structlbm__umq__queue__entry__t__stct.html#a41de68406a5a42ad5c27423012fa390e", null ],
    [ "regid", "structlbm__umq__queue__entry__t__stct.html#a879628dafd2209a08a5746284a8ca50d", null ]
];