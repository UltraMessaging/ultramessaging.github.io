var structlbm__umq__queue__topic__status__t =
[
    [ "flags", "structlbm__umq__queue__topic__status__t.html#a466349d80605494f15fde91fcbbff4f3", null ],
    [ "status", "structlbm__umq__queue__topic__status__t.html#a2f9a06265c1cfa05963a046a525373cc", null ],
    [ "topic", "structlbm__umq__queue__topic__status__t.html#afdb96b6fcf50b08b3c3246a910516890", null ]
];