var structtnwg__dstat__portalstats__msg__t__stct =
[
    [ "msghdr", "structtnwg__dstat__portalstats__msg__t__stct.html#ab6a1548883d5e3ea8b3e2158a45cce10", null ],
    [ "rechdr", "structtnwg__dstat__portalstats__msg__t__stct.html#a9f1e4b48cd4261d4f60fef342097a9ac", null ],
    [ "record", "structtnwg__dstat__portalstats__msg__t__stct.html#a48224a7bcafab7356df65e0aad891589", null ]
];