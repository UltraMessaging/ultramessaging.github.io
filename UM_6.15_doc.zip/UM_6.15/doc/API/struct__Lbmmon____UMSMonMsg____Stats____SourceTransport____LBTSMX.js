var struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTSMX =
[
    [ "base", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTSMX.html#a78fcef066947c3be69241d82f5679d36", null ],
    [ "bytes_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTSMX.html#a9b354f1f85352c5f3df5b9382a63c9e5", null ],
    [ "msgs_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTSMX.html#a2a1e3e3ba54d65c002f610087d2ef5d4", null ],
    [ "num_clients", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTSMX.html#a15277ed3f0789369d5afb7b32bf7a7e3", null ]
];