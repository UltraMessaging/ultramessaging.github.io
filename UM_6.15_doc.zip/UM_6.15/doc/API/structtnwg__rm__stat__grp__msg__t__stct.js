var structtnwg__rm__stat__grp__msg__t__stct =
[
    [ "local", "structtnwg__rm__stat__grp__msg__t__stct.html#aff881597d5e59ce48bb9b65b911cc720", null ],
    [ "msghdr", "structtnwg__rm__stat__grp__msg__t__stct.html#a4f4a2cd1bfcdaa01289eaa873c612982", null ],
    [ "msgtype", "structtnwg__rm__stat__grp__msg__t__stct.html#aff0077d5d839d68ea8ec0758fbdfe346", null ],
    [ "neighbor", "structtnwg__rm__stat__grp__msg__t__stct.html#af96657b16e0b762bb71f2eeb0980f181", null ],
    [ "othergw", "structtnwg__rm__stat__grp__msg__t__stct.html#a22b7fdf1b65fbeb7544a50c42b0c137a", null ],
    [ "portal", "structtnwg__rm__stat__grp__msg__t__stct.html#a0c37f5aa5ce60bf70449cf37d784974a", null ]
];