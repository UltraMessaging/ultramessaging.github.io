var struct__Lbmmon____UMPMonMsg____Stats____SmartHeapStat =
[
    [ "base", "struct__Lbmmon____UMPMonMsg____Stats____SmartHeapStat.html#ad294e85eb8e820319d784f278f2ad34d", null ],
    [ "pagesize", "struct__Lbmmon____UMPMonMsg____Stats____SmartHeapStat.html#a9dfc1a7476fcf081a4d8ef6a8f4112f5", null ],
    [ "poolcount", "struct__Lbmmon____UMPMonMsg____Stats____SmartHeapStat.html#adfd9f149e0720ad6f86bc6d118abc91c", null ],
    [ "poolsize", "struct__Lbmmon____UMPMonMsg____Stats____SmartHeapStat.html#a71fd9d9d4f9301af7bed58b31e3d0c3e", null ],
    [ "smallblocksize", "struct__Lbmmon____UMPMonMsg____Stats____SmartHeapStat.html#aba9cfedc7021c9ef319c965971ce5415", null ]
];