var structtnwg__mallinfo__stat__grp__record__t__stct =
[
    [ "arena", "structtnwg__mallinfo__stat__grp__record__t__stct.html#ae27b83935e96ee0a9cb478777a71eb6b", null ],
    [ "fordblks", "structtnwg__mallinfo__stat__grp__record__t__stct.html#a3595faff436c295eacd58cdc5adf1edb", null ],
    [ "hblkhd", "structtnwg__mallinfo__stat__grp__record__t__stct.html#a97e746358ca8388ad93bf0434f29d2d6", null ],
    [ "hblks", "structtnwg__mallinfo__stat__grp__record__t__stct.html#a6805bca9c2c5ca99a3a58cdb71840770", null ],
    [ "ordblks", "structtnwg__mallinfo__stat__grp__record__t__stct.html#a00a26de8d649f46c5358565311b3a63e", null ],
    [ "uordblks", "structtnwg__mallinfo__stat__grp__record__t__stct.html#a908b149b73c765d478bbbd922207b07e", null ]
];