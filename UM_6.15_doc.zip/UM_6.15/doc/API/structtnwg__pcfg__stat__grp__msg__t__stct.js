var structtnwg__pcfg__stat__grp__msg__t__stct =
[
    [ "data", "structtnwg__pcfg__stat__grp__msg__t__stct.html#a7887eff4d4e78540e53ea5a5a2521193", null ],
    [ "msghdr", "structtnwg__pcfg__stat__grp__msg__t__stct.html#ac43bcf94cb8b213ae63b242009035266", null ],
    [ "rechdr", "structtnwg__pcfg__stat__grp__msg__t__stct.html#a278f4ace28e25468a5b5cff658847b7d", null ]
];