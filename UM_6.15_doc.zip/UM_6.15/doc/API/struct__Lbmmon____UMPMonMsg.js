var struct__Lbmmon____UMPMonMsg =
[
    [ "attributes", "struct__Lbmmon____UMPMonMsg.html#ac4412466f970acd345dbd60c6efe3f99", null ],
    [ "base", "struct__Lbmmon____UMPMonMsg.html#a6e9c2803525d5e679db0b875293981b1", null ],
    [ "configs", "struct__Lbmmon____UMPMonMsg.html#a1d9ec418ad2f2142d62c76b825105c66", null ],
    [ "events", "struct__Lbmmon____UMPMonMsg.html#aa7a98591bc2f976f79a8b5cd29be17e7", null ],
    [ "stats", "struct__Lbmmon____UMPMonMsg.html#af45c55ffed541afc23cee1c9385e130a", null ]
];