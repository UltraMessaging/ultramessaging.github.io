var structtnwg__pcfg__stat__grp__rec__hdr__t__stct =
[
    [ "attr_type", "structtnwg__pcfg__stat__grp__rec__hdr__t__stct.html#aef2751409318f3acca8cce614c27e806", null ],
    [ "num_options", "structtnwg__pcfg__stat__grp__rec__hdr__t__stct.html#a1ad28e1dc4828d23a088eb55267e6336", null ],
    [ "padding", "structtnwg__pcfg__stat__grp__rec__hdr__t__stct.html#a565fc8996b51d7e07b7dc3ac6030df9a", null ],
    [ "portal_name", "structtnwg__pcfg__stat__grp__rec__hdr__t__stct.html#a0ccbccdbca21ef3a69271d612ffe0500", null ],
    [ "portal_num", "structtnwg__pcfg__stat__grp__rec__hdr__t__stct.html#aef74e26ee8aaed8601fdcd74d53db2d3", null ],
    [ "portal_type", "structtnwg__pcfg__stat__grp__rec__hdr__t__stct.html#ad5a1f169c80d4822b20254d0fd80813d", null ]
];