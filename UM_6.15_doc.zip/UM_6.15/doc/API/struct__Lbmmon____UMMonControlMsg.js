var struct__Lbmmon____UMMonControlMsg =
[
    [ "application_id", "struct__Lbmmon____UMMonControlMsg.html#a50e2cf49d40dbf64fcc0d6f221dabef3", null ],
    [ "base", "struct__Lbmmon____UMMonControlMsg.html#a958d9db7c713fa5ecd09cb773b232333", null ],
    [ "command", "struct__Lbmmon____UMMonControlMsg.html#a58f9373f5d40049366d06dd0487283a1", null ],
    [ "data", "struct__Lbmmon____UMMonControlMsg.html#ac04fc16526948e838213535f1ab1874b", null ],
    [ "node_type", "struct__Lbmmon____UMMonControlMsg.html#adb8357d15537143795075a16e68ec350", null ]
];