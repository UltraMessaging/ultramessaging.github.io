var structlbm__msg__umq__index__assigned__ex__t__stct =
[
    [ "flags", "structlbm__msg__umq__index__assigned__ex__t__stct.html#a15ffd2cf4ed915a6f0f65c81680dd109", null ],
    [ "index_info", "structlbm__msg__umq__index__assigned__ex__t__stct.html#a47340e558e9e4e990afb0211ee71ee52", null ],
    [ "queue", "structlbm__msg__umq__index__assigned__ex__t__stct.html#a2de1a6aee6f456e51b5c9ab5caa43c2c", null ],
    [ "queue_id", "structlbm__msg__umq__index__assigned__ex__t__stct.html#abd963b6cc576031be3967c6e2eb97a1f", null ]
];