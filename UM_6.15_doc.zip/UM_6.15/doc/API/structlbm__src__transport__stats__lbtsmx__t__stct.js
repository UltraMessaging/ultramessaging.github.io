var structlbm__src__transport__stats__lbtsmx__t__stct =
[
    [ "bytes_sent", "structlbm__src__transport__stats__lbtsmx__t__stct.html#a94b73c843dee38fa088cef85d86defb5", null ],
    [ "msgs_sent", "structlbm__src__transport__stats__lbtsmx__t__stct.html#aa5a75358d3fa9f713bbf231dd8b9bc3d", null ],
    [ "num_clients", "structlbm__src__transport__stats__lbtsmx__t__stct.html#a23f7ba1e7a44b9223ef29f8bdfe0c570", null ]
];