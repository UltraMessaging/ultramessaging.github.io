var structlbm__datagram__acceleration__func__t__stct =
[
    [ "bind", "structlbm__datagram__acceleration__func__t__stct.html#a108d99dc9c7e8c764d61adabe74d2adc", null ],
    [ "close", "structlbm__datagram__acceleration__func__t__stct.html#a5f5bb65c5a0c1850e1e21bd5d890d4e4", null ],
    [ "getaddr", "structlbm__datagram__acceleration__func__t__stct.html#a1f73888b73d28efe2ac919b8382c40c2", null ],
    [ "init", "structlbm__datagram__acceleration__func__t__stct.html#a9845bc09d1c301566c239955fb958139", null ],
    [ "mcast_join", "structlbm__datagram__acceleration__func__t__stct.html#ac825b1e2bbd83c04d760c673c46a431b", null ],
    [ "mcast_leave", "structlbm__datagram__acceleration__func__t__stct.html#aff07f3b7ddb9c1dfb543fa646f3b3100", null ],
    [ "open", "structlbm__datagram__acceleration__func__t__stct.html#a6b36b151a00506ebea9d01d598136aae", null ],
    [ "recvfrom", "structlbm__datagram__acceleration__func__t__stct.html#a21cd8a6444189f3758135dd2b44de41e", null ],
    [ "send", "structlbm__datagram__acceleration__func__t__stct.html#aaebf012eeb3ca971602c65a9e939e8ad", null ],
    [ "send_connect", "structlbm__datagram__acceleration__func__t__stct.html#a1b9a83e474f341f0e3d4e86c460dcc3f", null ],
    [ "send_disconnect", "structlbm__datagram__acceleration__func__t__stct.html#a0aa3e4d5bd2caa9ff2a09c8ea3fecb5c", null ],
    [ "sendto", "structlbm__datagram__acceleration__func__t__stct.html#ad54a21f87708100bcfb2290bf3c1d832", null ],
    [ "unbind", "structlbm__datagram__acceleration__func__t__stct.html#af6662815bdfd38031bcfe9c63ac00ed6", null ]
];