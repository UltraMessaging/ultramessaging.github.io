var structtnwg__rm__stat__grp__portal__info__t__stct =
[
    [ "index", "structtnwg__rm__stat__grp__portal__info__t__stct.html#a6e224be2c5ede849dae433586532e8e2", null ],
    [ "ingress_cost", "structtnwg__rm__stat__grp__portal__info__t__stct.html#af3f3786ba34a18ea66c6aba8b91d4c88", null ],
    [ "node_or_adjacent_id", "structtnwg__rm__stat__grp__portal__info__t__stct.html#a81f3284d8c0b89047613d20c98c5afb2", null ],
    [ "portal_name", "structtnwg__rm__stat__grp__portal__info__t__stct.html#a0e578cd7e6f4d34b37889a9e71a1aa60", null ],
    [ "proxy_rec_recalc_duration_sec", "structtnwg__rm__stat__grp__portal__info__t__stct.html#aea7172b0d2dc72daa7db78d6e5af8f85", null ],
    [ "proxy_rec_recalc_duration_usec", "structtnwg__rm__stat__grp__portal__info__t__stct.html#adc2eca01fc4c404a131ac77cb3f5fa6c", null ],
    [ "recalc_duration_sec", "structtnwg__rm__stat__grp__portal__info__t__stct.html#ac36531c88773fcd05c6a7e522ed79af1", null ],
    [ "recalc_duration_usec", "structtnwg__rm__stat__grp__portal__info__t__stct.html#a51c81d05a9c4991d614f2d898f890b3e", null ],
    [ "type", "structtnwg__rm__stat__grp__portal__info__t__stct.html#a488fb3cbf1b7a9ede9be32f9d8297269", null ]
];