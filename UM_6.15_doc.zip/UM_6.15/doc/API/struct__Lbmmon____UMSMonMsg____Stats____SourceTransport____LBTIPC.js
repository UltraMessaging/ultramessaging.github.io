var struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTIPC =
[
    [ "base", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTIPC.html#a244d8ea5c1757914a18a833d839ee127", null ],
    [ "bytes_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTIPC.html#a6859738e85b471964886d73bdbdd570b", null ],
    [ "msgs_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTIPC.html#a0a3c921d0bd7927fd74313d32d4f8030", null ],
    [ "num_clients", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTIPC.html#a5dfb2a43ed3ab489950b28a1cb64a215", null ]
];