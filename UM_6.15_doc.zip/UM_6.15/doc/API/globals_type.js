var globals_type =
[
    [ "l", "globals_type.html", null ],
    [ "t", "globals_type_t.html", null ],
    [ "u", "globals_type_u.html", null ]
];