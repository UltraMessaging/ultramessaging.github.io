var struct__Lbmmon____DROMonMsg____Stats____Local =
[
    [ "base", "struct__Lbmmon____DROMonMsg____Stats____Local.html#aa28fa6352c832b1de2274503ea6d87a8", null ],
    [ "gateway_count", "struct__Lbmmon____DROMonMsg____Stats____Local.html#a48f69f2d54595e9a701c9c549ab6159d", null ],
    [ "gateway_id", "struct__Lbmmon____DROMonMsg____Stats____Local.html#afaad5bbacbe1500b12d0f97663f29fcf", null ],
    [ "gateway_name", "struct__Lbmmon____DROMonMsg____Stats____Local.html#a26f9862c5f6fd973a662f18a5044d028", null ],
    [ "graph_version", "struct__Lbmmon____DROMonMsg____Stats____Local.html#a71e561de0612c1c7913b873ab902f34a", null ],
    [ "malloc_info", "struct__Lbmmon____DROMonMsg____Stats____Local.html#a68fc8d5e2d92ac8d055801549e4dead4", null ],
    [ "recalc_duration_sec", "struct__Lbmmon____DROMonMsg____Stats____Local.html#a001f85623176fcac37bfe424604beb5c", null ],
    [ "recalc_duration_usec", "struct__Lbmmon____DROMonMsg____Stats____Local.html#a4f727de397d40a60a7c3441ed97adb5d", null ],
    [ "topology_signature", "struct__Lbmmon____DROMonMsg____Stats____Local.html#a17c09c5da21def7193c08e635f46db01", null ],
    [ "trd_count", "struct__Lbmmon____DROMonMsg____Stats____Local.html#a471e35862efea3f1e163c78a5d63c082", null ],
    [ "version", "struct__Lbmmon____DROMonMsg____Stats____Local.html#abc631bc0ad2c3391aea91e499885ede0", null ]
];