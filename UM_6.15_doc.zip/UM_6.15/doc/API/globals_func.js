var globals_func =
[
    [ "l", "globals_func.html", null ],
    [ "u", "globals_func_u.html", null ]
];