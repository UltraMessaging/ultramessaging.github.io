var struct__Lbmmon____DROMonMsg____Stats____Portal =
[
    [ "base", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#ae5ef0bc2933edc99722536fb0009a550", null ],
    [ "cost", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a492d9ccdc2bcd44fe9025ad8d1ce3128", null ],
    [ "endpoint", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a7b81555e6f0c1435a69f79583fdfb866", null ],
    [ "peer", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a3291080c4b7c88955c014b870acac1fd", null ],
    [ "portal_index", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a3e73fed8e5c8b1a0b493b382ec93fe71", null ],
    [ "portal_name", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a61d25707faf5229f459271aab90e24ad", null ],
    [ "portal_type_case", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a57f35f900dcc8264cba89608a63f62e8", null ],
    [ "proxy_rec_recalc_duration_sec", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#ae9fdcccef924b7089be1e0611064c560", null ],
    [ "proxy_rec_recalc_duration_usec", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a2654a2293fea2eb21151274ba23033bd", null ],
    [ "proxy_receivers", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a400c6e4432e343e04a9c8cc410917ef4", null ],
    [ "proxy_sources", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a81a82b7d1a7fa769d4b36a3851217054", null ],
    [ "recalc_duration_sec", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a807c2fc222a67c81f612dda79b8e221d", null ],
    [ "recalc_duration_usec", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a888621fcd8dddf9018d78140f9d6aeb6", null ],
    [ "receiver_pcre_patterns", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#a50969435f7a7b79f5f5db6d1f7ce4249", null ],
    [ "receiver_regex_patterns", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#aba00424e546a82f8d1c51e47ee38c414", null ],
    [ "receiver_topics", "struct__Lbmmon____DROMonMsg____Stats____Portal.html#afbf750a5d986b19e78aa9267b1342405", null ]
];