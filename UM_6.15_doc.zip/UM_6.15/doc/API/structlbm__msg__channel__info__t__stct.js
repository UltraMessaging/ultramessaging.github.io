var structlbm__msg__channel__info__t__stct =
[
    [ "channel_number", "structlbm__msg__channel__info__t__stct.html#a2a32594313d217bab31f141cb0bf4185", null ],
    [ "flags", "structlbm__msg__channel__info__t__stct.html#acc5d1dcbc452e8d029e1430886c5589c", null ]
];