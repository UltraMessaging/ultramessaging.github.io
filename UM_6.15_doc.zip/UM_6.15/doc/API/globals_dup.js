var globals_dup =
[
    [ "l", "globals.html", null ],
    [ "m", "globals_m.html", null ],
    [ "p", "globals_p.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ],
    [ "u", "globals_u.html", null ]
];