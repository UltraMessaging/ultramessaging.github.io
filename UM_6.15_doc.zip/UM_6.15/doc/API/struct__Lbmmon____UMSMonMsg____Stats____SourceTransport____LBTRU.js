var struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU =
[
    [ "base", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#a2c1421cc8602aca22217ef40b6a5dcde", null ],
    [ "bytes_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#a150d7c9d88136f2954d55c6fc80b3b3c", null ],
    [ "msgs_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#a55e7efac1d8a9ae526fcf2f70362ee6b", null ],
    [ "nak_pckts_rcved", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#af7fda3e788de01f6ac907233ae0db2b4", null ],
    [ "naks_ignored", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#a195e9bc723312e2c72296eaa3f512495", null ],
    [ "naks_rcved", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#abc35f2f835cd44fd0901fd811bd98169", null ],
    [ "naks_rx_delay_ignored", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#aa6477c1790354cc871b8bbb9e46e53c6", null ],
    [ "naks_shed", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#a363e91c04bc82e7bbddbef7e55bcbec5", null ],
    [ "num_clients", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#a4d95ec76e5e9c2ebfe4c13819180e15f", null ],
    [ "rx_bytes_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#a241fd778cd63c2d17a43330a3216c63f", null ],
    [ "rxs_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRU.html#a011b45367bcaaf6d2a3996df8870d8de", null ]
];