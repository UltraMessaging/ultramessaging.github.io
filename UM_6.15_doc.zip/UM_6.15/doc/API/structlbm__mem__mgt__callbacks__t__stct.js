var structlbm__mem__mgt__callbacks__t__stct =
[
    [ "clientd", "structlbm__mem__mgt__callbacks__t__stct.html#a3eab8d3f6b2f41f1f08f0808395f56bf", null ],
    [ "free_cb_func", "structlbm__mem__mgt__callbacks__t__stct.html#a7fe65ae067bfe5a2c1fe29caa63a6ce4", null ],
    [ "malloc_cb_func", "structlbm__mem__mgt__callbacks__t__stct.html#ae1423025ecf4832815478876b976dd1c", null ],
    [ "realloc_cb_func", "structlbm__mem__mgt__callbacks__t__stct.html#acf35501d75012bd7aa6ffa73cf118e1c", null ]
];