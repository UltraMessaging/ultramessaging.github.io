var structlbm__src__event__umq__stability__ack__info__ex__t__stct =
[
    [ "first_sequence_number", "structlbm__src__event__umq__stability__ack__info__ex__t__stct.html#a3e9e9900646f2f4a3e21b444abf53a57", null ],
    [ "flags", "structlbm__src__event__umq__stability__ack__info__ex__t__stct.html#a6b1e7f4793deaa662958d25d58862966", null ],
    [ "last_sequence_number", "structlbm__src__event__umq__stability__ack__info__ex__t__stct.html#a6ab2e0b62c8f3f51a5a345d510cf27de", null ],
    [ "msg_clientd", "structlbm__src__event__umq__stability__ack__info__ex__t__stct.html#adb35ff21f08829cd982595a9ab467cbc", null ],
    [ "msg_id", "structlbm__src__event__umq__stability__ack__info__ex__t__stct.html#acb1f92111954d8d5b89d27dbb3f89686", null ],
    [ "queue", "structlbm__src__event__umq__stability__ack__info__ex__t__stct.html#a2c648f4ecda7739df15500bb05feee2d", null ],
    [ "queue_id", "structlbm__src__event__umq__stability__ack__info__ex__t__stct.html#a88a5094d48958e90354d23aba45b422d", null ],
    [ "queue_instance", "structlbm__src__event__umq__stability__ack__info__ex__t__stct.html#a54f10c24a78bef73f9c562f53b6b00b9", null ],
    [ "queue_instance_index", "structlbm__src__event__umq__stability__ack__info__ex__t__stct.html#a201941eefb329458612786bff13c827a", null ]
];