var struct__Lbmmon____DROMonMsg____Configs____Gateway =
[
    [ "base", "struct__Lbmmon____DROMonMsg____Configs____Gateway.html#a90219d45fa609a3f9576b91079598527", null ],
    [ "config_data", "struct__Lbmmon____DROMonMsg____Configs____Gateway.html#a06802c692402c6b533c0260518c967ca", null ]
];