var struct__Lbmmon____DROMonMsg____Configs____Portal =
[
    [ "base", "struct__Lbmmon____DROMonMsg____Configs____Portal.html#a0a28865a00cbd72ff83428905045fcfb", null ],
    [ "portal_index", "struct__Lbmmon____DROMonMsg____Configs____Portal.html#a741842633413f80b483dab9d0177c40d", null ],
    [ "portal_name", "struct__Lbmmon____DROMonMsg____Configs____Portal.html#a8a64938462496c1920a39b9516d107a6", null ],
    [ "portal_type", "struct__Lbmmon____DROMonMsg____Configs____Portal.html#aa6762ca220ddeed05b628e5947ba62ab", null ]
];