var structlbm__wildcard__rcv__compare__func__t__stct =
[
    [ "clientd", "structlbm__wildcard__rcv__compare__func__t__stct.html#ab27bf93acd36531a3744c856d79992a7", null ],
    [ "compfunc", "structlbm__wildcard__rcv__compare__func__t__stct.html#a8dc44dfcc5add315aeb7e9cf4ffdde06", null ]
];