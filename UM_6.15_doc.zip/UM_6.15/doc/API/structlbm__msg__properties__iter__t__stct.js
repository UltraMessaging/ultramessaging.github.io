var structlbm__msg__properties__iter__t__stct =
[
    [ "data", "structlbm__msg__properties__iter__t__stct.html#ab69a16304cbd0e23b3da0bb7c5312b97", null ],
    [ "name", "structlbm__msg__properties__iter__t__stct.html#ab65ef874c567498e4b7c574d25fb6b64", null ],
    [ "size", "structlbm__msg__properties__iter__t__stct.html#a1b2694a6da27811f95b72f79831c07dc", null ],
    [ "type", "structlbm__msg__properties__iter__t__stct.html#a0b96a99d0c7a3ffe64a8607f9497abb8", null ]
];