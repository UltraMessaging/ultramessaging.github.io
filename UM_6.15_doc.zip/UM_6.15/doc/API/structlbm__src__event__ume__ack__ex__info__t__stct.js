var structlbm__src__event__ume__ack__ex__info__t__stct =
[
    [ "flags", "structlbm__src__event__ume__ack__ex__info__t__stct.html#a207c8b76a154b24274700279bba95600", null ],
    [ "msg_clientd", "structlbm__src__event__ume__ack__ex__info__t__stct.html#a11394d5ea9ee6a873ecf60170732c186", null ],
    [ "rcv_registration_id", "structlbm__src__event__ume__ack__ex__info__t__stct.html#ab19378eb60d2b6e20bb5187bbb64fcd3", null ],
    [ "sequence_number", "structlbm__src__event__ume__ack__ex__info__t__stct.html#a8b7e4d03232bb81a0629497ac7b8c2fe", null ],
    [ "store", "structlbm__src__event__ume__ack__ex__info__t__stct.html#a7b71e8d27bf6476e90a27d871bf77a3f", null ],
    [ "store_index", "structlbm__src__event__ume__ack__ex__info__t__stct.html#a0fd1ee65ec5045f559538d6d41fbb578", null ]
];