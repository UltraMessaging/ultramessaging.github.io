var struct__Lbmmon____DROMonMsg____Stats____OtherGateway____OtherPortal =
[
    [ "adjacent_domain_id", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway____OtherPortal.html#ad52b4812a890048acc6c32d0be9e13cc", null ],
    [ "adjacent_gateway_id", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway____OtherPortal.html#a6e82caead12d57751c4f9de6ba7fa96f", null ],
    [ "base", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway____OtherPortal.html#a5719cb068d5849dc7be3a172629c9c2d", null ],
    [ "cost", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway____OtherPortal.html#a108b521ed42537d629cc2e820af18da1", null ],
    [ "portal_type_case", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway____OtherPortal.html#ad4d79ccd67cb090a583e0ae34b0ef9d2", null ]
];