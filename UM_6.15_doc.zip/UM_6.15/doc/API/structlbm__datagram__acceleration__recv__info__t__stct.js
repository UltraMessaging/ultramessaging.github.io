var structlbm__datagram__acceleration__recv__info__t__stct =
[
    [ "buffer", "structlbm__datagram__acceleration__recv__info__t__stct.html#ab89e47e4377f055587ce44b3a54c1af0", null ],
    [ "clientd", "structlbm__datagram__acceleration__recv__info__t__stct.html#a74f0670bfbe8e06ed04680fe56998a37", null ],
    [ "handle", "structlbm__datagram__acceleration__recv__info__t__stct.html#ab4f368781d7afd892e859869723314ff", null ],
    [ "length", "structlbm__datagram__acceleration__recv__info__t__stct.html#af97bdd3bcc237dee4d419db764e2bb48", null ],
    [ "timestamp", "structlbm__datagram__acceleration__recv__info__t__stct.html#a4e300d97711e2c7018862fc60d498be9", null ]
];