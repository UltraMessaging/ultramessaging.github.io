var structumestore__disk__dmon__stat__msg__t__stct =
[
    [ "dmon_topic_idx", "structumestore__disk__dmon__stat__msg__t__stct.html#acff875017d0a25aa1ead7c46fa5cb00b", null ],
    [ "hdr", "structumestore__disk__dmon__stat__msg__t__stct.html#ab8b5d63310bfca65b2c23bb009bd35be", null ],
    [ "max_offset", "structumestore__disk__dmon__stat__msg__t__stct.html#a38643d4ae87ebd229a75453995c958b4", null ],
    [ "num_ios_pending", "structumestore__disk__dmon__stat__msg__t__stct.html#a7693e9fb904bb0fd861428a0820d45b7", null ],
    [ "num_read_ios_pending", "structumestore__disk__dmon__stat__msg__t__stct.html#a6cc9e2a107dc18dee16e9c171e0ab2a8", null ],
    [ "offset", "structumestore__disk__dmon__stat__msg__t__stct.html#a3803d957a5d0b940a8e8cc92ea76ed8e", null ],
    [ "regid", "structumestore__disk__dmon__stat__msg__t__stct.html#a7518c3eb6ffdbe9f7a577e87f75c907c", null ],
    [ "start_offset", "structumestore__disk__dmon__stat__msg__t__stct.html#a676bd64f9fad650c8095e73629eb8001", null ],
    [ "store_idx", "structumestore__disk__dmon__stat__msg__t__stct.html#ae4d44bd05c7a9f5a853f1e023012335a", null ]
];