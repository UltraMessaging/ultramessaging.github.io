var structlbm__msg__fragment__info__t__stct =
[
    [ "offset", "structlbm__msg__fragment__info__t__stct.html#abf36fd1581acc3f5eb593737962ba906", null ],
    [ "start_sequence_number", "structlbm__msg__fragment__info__t__stct.html#a19d4422ca1aa8d04e72068c5b414aed4", null ],
    [ "total_message_length", "structlbm__msg__fragment__info__t__stct.html#abbaf41ee121bb915b8ebdee51f277052", null ]
];