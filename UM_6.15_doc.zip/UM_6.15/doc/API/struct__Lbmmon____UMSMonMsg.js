var struct__Lbmmon____UMSMonMsg =
[
    [ "attributes", "struct__Lbmmon____UMSMonMsg.html#adb4c32e84a28fd9fca243c9ddfb4e2f1", null ],
    [ "base", "struct__Lbmmon____UMSMonMsg.html#a4fc66a2ce6b184cfdb691626f694ca71", null ],
    [ "events", "struct__Lbmmon____UMSMonMsg.html#afab17ead7a98d49df56e69ab9cd0c0cc", null ],
    [ "stats", "struct__Lbmmon____UMSMonMsg.html#a1c51cfb8a4f104056056cdf030db0e5d", null ]
];