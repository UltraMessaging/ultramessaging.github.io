var structlbm__process__events__info__t__stct =
[
    [ "flags", "structlbm__process__events__info__t__stct.html#a116d754d9c09199b75d24606b706ca10", null ],
    [ "time_val", "structlbm__process__events__info__t__stct.html#a211b8ce8a0d9d92052b6f2fc14f4b8fb", null ]
];