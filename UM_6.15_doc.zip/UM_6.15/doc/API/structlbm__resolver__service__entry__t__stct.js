var structlbm__resolver__service__entry__t__stct =
[
    [ "iface", "structlbm__resolver__service__entry__t__stct.html#aaeb3a586caf18aa99f2ce5e79dfa0cb8", null ],
    [ "service_ip", "structlbm__resolver__service__entry__t__stct.html#adb40deb20fedde6836908564ee0a7103", null ],
    [ "service_port", "structlbm__resolver__service__entry__t__stct.html#a614a7e871f1c77ff4cd00d20a191d347", null ],
    [ "source_port", "structlbm__resolver__service__entry__t__stct.html#a3f36995a95ffabe738dc3870b8561c55", null ]
];