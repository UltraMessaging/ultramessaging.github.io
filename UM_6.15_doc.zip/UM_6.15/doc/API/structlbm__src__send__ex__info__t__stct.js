var structlbm__src__send__ex__info__t__stct =
[
    [ "apphdr_chain", "structlbm__src__send__ex__info__t__stct.html#ab5d177886b035d3cbbb730c522bee207", null ],
    [ "async_opfunc", "structlbm__src__send__ex__info__t__stct.html#a5eda719e0b45a8efa9c6daceb25866e1", null ],
    [ "channel_info", "structlbm__src__send__ex__info__t__stct.html#a8ba8e77209c1ef52c17d28823671e28b", null ],
    [ "flags", "structlbm__src__send__ex__info__t__stct.html#aa450a079510ebdc97b19625d10bd18ea", null ],
    [ "hf_sqn", "structlbm__src__send__ex__info__t__stct.html#ab665a0b6bf87ff02164f77a5e8524ce3", null ],
    [ "properties", "structlbm__src__send__ex__info__t__stct.html#a69ae228b9501f0466bfec8da2a479cbf", null ],
    [ "ume_msg_clientd", "structlbm__src__send__ex__info__t__stct.html#afeb9643e8ca421be3c85d2c1c32fe556", null ],
    [ "umq_index", "structlbm__src__send__ex__info__t__stct.html#a8798bd96032aecbdd3ccbb2c2b8070e0", null ],
    [ "umq_total_lifetime", "structlbm__src__send__ex__info__t__stct.html#a5335e2eb3550544263d7be7f690837d9", null ]
];