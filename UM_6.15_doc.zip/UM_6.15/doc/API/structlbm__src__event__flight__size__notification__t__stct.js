var structlbm__src__event__flight__size__notification__t__stct =
[
    [ "state", "structlbm__src__event__flight__size__notification__t__stct.html#a4805e12cbac941f189ea511d48d02445", null ],
    [ "type", "structlbm__src__event__flight__size__notification__t__stct.html#a5353fdbec2f49e6c4942f039b0fb9058", null ]
];