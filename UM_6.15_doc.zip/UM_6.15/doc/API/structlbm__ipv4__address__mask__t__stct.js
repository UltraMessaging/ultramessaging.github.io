var structlbm__ipv4__address__mask__t__stct =
[
    [ "addr", "structlbm__ipv4__address__mask__t__stct.html#adfbed23d500ed1a5e64d316432d8bc36", null ],
    [ "bits", "structlbm__ipv4__address__mask__t__stct.html#abafa925c5d7b57d5210991010d7b7e4e", null ]
];