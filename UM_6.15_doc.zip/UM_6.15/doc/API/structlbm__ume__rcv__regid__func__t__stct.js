var structlbm__ume__rcv__regid__func__t__stct =
[
    [ "clientd", "structlbm__ume__rcv__regid__func__t__stct.html#a68892422a329b4e25c28cedcc76309a4", null ],
    [ "func", "structlbm__ume__rcv__regid__func__t__stct.html#a0670371b3643cb13596f40e598c1d0c4", null ]
];