var structtnwg__rm__stat__grp__othergw__info__t__stct =
[
    [ "gateway_id", "structtnwg__rm__stat__grp__othergw__info__t__stct.html#af76526dd7ad0029a74f12fa31183a621", null ],
    [ "gateway_name", "structtnwg__rm__stat__grp__othergw__info__t__stct.html#a54275d3523a94853efe7b1133067d437", null ],
    [ "last_activity_sec", "structtnwg__rm__stat__grp__othergw__info__t__stct.html#a0982d0776f28dff3d648ec4d50173f5c", null ],
    [ "last_activity_usec", "structtnwg__rm__stat__grp__othergw__info__t__stct.html#a75f650b5769b21dc749ceea098c38e2e", null ],
    [ "num_neighbors", "structtnwg__rm__stat__grp__othergw__info__t__stct.html#a21c81331cd7f22c70da1549d83e9c6a6", null ],
    [ "topology", "structtnwg__rm__stat__grp__othergw__info__t__stct.html#afd5857a93166c7985d8d7edd081908ba", null ],
    [ "version", "structtnwg__rm__stat__grp__othergw__info__t__stct.html#a090494b46845b81588778cd7f66cb53f", null ]
];