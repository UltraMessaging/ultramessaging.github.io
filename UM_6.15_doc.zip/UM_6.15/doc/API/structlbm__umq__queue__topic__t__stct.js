var structlbm__umq__queue__topic__t__stct =
[
    [ "appsets", "structlbm__umq__queue__topic__t__stct.html#ad45096727ebb2352defa6c5d5432d474", null ],
    [ "num_appsets", "structlbm__umq__queue__topic__t__stct.html#a7b25b7646278462ce65652f01439545a", null ],
    [ "reserved", "structlbm__umq__queue__topic__t__stct.html#af25a1dc2129a88aea0a8ae4fa9ece6a3", null ],
    [ "topic_name", "structlbm__umq__queue__topic__t__stct.html#a2ba4dcc100b8e6496b77e1f321bacd2c", null ]
];