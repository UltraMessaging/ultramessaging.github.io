var struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM =
[
    [ "base", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#a5cff82efa30d34eaf045904634a628c0", null ],
    [ "bytes_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#ad1b8c463c8ddf31adcb2dcd1e158d9c3", null ],
    [ "msgs_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#a4185f385f18b2622622a35237d6f0167", null ],
    [ "nak_pckts_rcved", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#a519f1e663294b551eece85646d4ae5da", null ],
    [ "naks_ignored", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#a9d84f2b86c4ffa128b919845aa35d292", null ],
    [ "naks_rcved", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#abd5b6c3cb55c001ebb587a9d1beb70ed", null ],
    [ "naks_rx_delay_ignored", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#addfd1f43feeec40445b2f646e1c47bfc", null ],
    [ "naks_shed", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#a11de87bce5d3df924834dd9fe95d28cf", null ],
    [ "rctlr_data_msgs", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#aa0453d95a9941d8faa0d74228e9d0d79", null ],
    [ "rctlr_rx_msgs", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#a8ca03753bbaf7017161f27ce1c30f89c", null ],
    [ "rx_bytes_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#a3c6647f67c60f226dd707bc1b596f992", null ],
    [ "rxs_sent", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#aba3ff17214fb205c3a24419763784b97", null ],
    [ "txw_bytes", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#a415322ae9ab8980de80db119dc5594dc", null ],
    [ "txw_msgs", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____LBTRM.html#a2c829b1f2c66aa2f47b34fe636294e39", null ]
];