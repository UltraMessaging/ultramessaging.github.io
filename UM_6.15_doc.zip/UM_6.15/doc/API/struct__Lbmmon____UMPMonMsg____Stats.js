var struct__Lbmmon____UMPMonMsg____Stats =
[
    [ "base", "struct__Lbmmon____UMPMonMsg____Stats.html#a88639686bb824b1682587658ed0198c7", null ],
    [ "n_src_repo_stats", "struct__Lbmmon____UMPMonMsg____Stats.html#a703f96d217171e615f31e9eb386e6efb", null ],
    [ "smart_heap_stat", "struct__Lbmmon____UMPMonMsg____Stats.html#a81c326314b4ec20e9a5ff986393dd7a6", null ],
    [ "src_count", "struct__Lbmmon____UMPMonMsg____Stats.html#a97356bbd201dcdb82ed20e8fc5f988c6", null ],
    [ "src_repo_stats", "struct__Lbmmon____UMPMonMsg____Stats.html#a5e397c718cd6111cb2aaaeac5d77f15f", null ],
    [ "store_idx", "struct__Lbmmon____UMPMonMsg____Stats.html#abc7f0f9b06e751e260c58db5f167c275", null ],
    [ "ume_retx_req_drop_count", "struct__Lbmmon____UMPMonMsg____Stats.html#acea1b0630d0b40967d56a00756632b01", null ],
    [ "ume_retx_req_rcv_count", "struct__Lbmmon____UMPMonMsg____Stats.html#a37afc9104a8faa27832d9a055d97520a", null ],
    [ "ume_retx_req_serviced_count", "struct__Lbmmon____UMPMonMsg____Stats.html#ae84db178b9707313a76f7a9a964666d5", null ],
    [ "ume_retx_req_total_dropped", "struct__Lbmmon____UMPMonMsg____Stats.html#a8ce9c212e32d78141f13ec60db3c50b1", null ],
    [ "ume_retx_stat_interval", "struct__Lbmmon____UMPMonMsg____Stats.html#a5d9f816d86f0ea4e228a3d14c0f5bbff", null ]
];