var structlbm__resolver__event__advertisement__t__stct =
[
    [ "flags", "structlbm__resolver__event__advertisement__t__stct.html#afb32683c70cd1fef1bfe988f1e94ee8b", null ],
    [ "otid", "structlbm__resolver__event__advertisement__t__stct.html#a5e11f31fc2f0f59615ff1e26435480ed", null ],
    [ "source_domain_id", "structlbm__resolver__event__advertisement__t__stct.html#a207bcc6942b4bec9f62b796f32d4a8e8", null ],
    [ "source_type", "structlbm__resolver__event__advertisement__t__stct.html#adf55430803002072dd17e8e6ba06a49e", null ],
    [ "topic_index", "structlbm__resolver__event__advertisement__t__stct.html#a986af19903ff2be1a047244236ab4013", null ],
    [ "topic_string", "structlbm__resolver__event__advertisement__t__stct.html#aa977b3ba9f855b668252780d581828a9", null ],
    [ "transport_string", "structlbm__resolver__event__advertisement__t__stct.html#ab98bebf2274fb7efa8356a1165f4db17", null ]
];