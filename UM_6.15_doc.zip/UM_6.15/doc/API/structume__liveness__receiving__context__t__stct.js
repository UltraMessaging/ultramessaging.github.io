var structume__liveness__receiving__context__t__stct =
[
    [ "flag", "structume__liveness__receiving__context__t__stct.html#abf4c95cd1b3722f48f4cc3d469a4ed40", null ],
    [ "regid", "structume__liveness__receiving__context__t__stct.html#a5eadf10c013f6369494db4556147f8f1", null ],
    [ "session_id", "structume__liveness__receiving__context__t__stct.html#adf2eadc890aba156953055a2c8a6aef9", null ]
];