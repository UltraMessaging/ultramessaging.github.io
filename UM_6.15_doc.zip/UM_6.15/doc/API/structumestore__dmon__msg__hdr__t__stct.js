var structumestore__dmon__msg__hdr__t__stct =
[
    [ "length", "structumestore__dmon__msg__hdr__t__stct.html#a606d498b28a82ef7e8ae96705e116894", null ],
    [ "magic", "structumestore__dmon__msg__hdr__t__stct.html#acae55eca47540f4aca0fafbf1941b4f3", null ],
    [ "tv_sec", "structumestore__dmon__msg__hdr__t__stct.html#a898ec7f5e5f49e6f6cdde493f6a959f7", null ],
    [ "tv_usec", "structumestore__dmon__msg__hdr__t__stct.html#abfea2e880c325fd755254131baaff856", null ],
    [ "type", "structumestore__dmon__msg__hdr__t__stct.html#a0542d765553a7a86bc6ef7c74c4e5385", null ],
    [ "version", "structumestore__dmon__msg__hdr__t__stct.html#a7e7f6e5330a6646429cf983f98f29a18", null ]
];