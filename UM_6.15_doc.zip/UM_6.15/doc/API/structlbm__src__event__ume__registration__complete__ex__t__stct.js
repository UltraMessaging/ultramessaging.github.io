var structlbm__src__event__ume__registration__complete__ex__t__stct =
[
    [ "flags", "structlbm__src__event__ume__registration__complete__ex__t__stct.html#aee2b59249259b8ff8d301392e1e9e725", null ],
    [ "sequence_number", "structlbm__src__event__ume__registration__complete__ex__t__stct.html#aba830cd0f91f4dbdf5d3cbcef96d397c", null ]
];