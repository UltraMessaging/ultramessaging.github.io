var structlbm__wildcard__rcv__delete__func__t__stct =
[
    [ "clientd", "structlbm__wildcard__rcv__delete__func__t__stct.html#af9364f98bd9f2ee83e290b781aae7c17", null ],
    [ "deletefunc", "structlbm__wildcard__rcv__delete__func__t__stct.html#aa7806bbc4d1637334187856d0ca924ad", null ]
];