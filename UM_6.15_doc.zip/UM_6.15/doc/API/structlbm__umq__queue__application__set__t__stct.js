var structlbm__umq__queue__application__set__t__stct =
[
    [ "application_set_index", "structlbm__umq__queue__application__set__t__stct.html#a63b8156e5b15017cab2647846ee76691", null ],
    [ "appset_name", "structlbm__umq__queue__application__set__t__stct.html#a9087ec2b740e07c2aaaea1c8eda21fa8", null ],
    [ "ids", "structlbm__umq__queue__application__set__t__stct.html#a0eb9590c1d616fec26bc1a67d860af6d", null ],
    [ "num_ids", "structlbm__umq__queue__application__set__t__stct.html#ac68af85e9544a3d46d2fede45932ae51", null ],
    [ "reserved", "structlbm__umq__queue__application__set__t__stct.html#afd6817fd1ed55eb341a4add47d032d7c", null ]
];