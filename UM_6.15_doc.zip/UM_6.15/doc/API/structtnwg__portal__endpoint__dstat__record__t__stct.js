var structtnwg__portal__endpoint__dstat__record__t__stct =
[
    [ "domain_id", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a4c0f949fec35550eecb9d6ed45ffeb91", null ],
    [ "ingress_cost", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a2b92d9ac524fb686140bf45309d076ed", null ],
    [ "local_interest_pcre_patterns", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a44c9fa2be0acf8665282d752d95ff132", null ],
    [ "local_interest_regex_patterns", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a78ed001f0ad8fccd3e4d06263c247b38", null ],
    [ "local_interest_topics", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a93621278e1fe555cfd402b1c7c9d66e7", null ],
    [ "padding", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a76a368845f108eb7bf9ecb5a2b9b0368", null ],
    [ "proxy_receivers", "structtnwg__portal__endpoint__dstat__record__t__stct.html#aad6fb664c1a082698a599808385dae77", null ],
    [ "proxy_sources", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a03ea05c68e0105782c96b0d891e53944", null ],
    [ "receive_stats", "structtnwg__portal__endpoint__dstat__record__t__stct.html#abbcfde3ec087603f411fccf0ad4d973e", null ],
    [ "receiver_pcre_patterns", "structtnwg__portal__endpoint__dstat__record__t__stct.html#afe5bc354a7a3b06363acef1b846ec404", null ],
    [ "receiver_regex_patterns", "structtnwg__portal__endpoint__dstat__record__t__stct.html#aa241448232846bc2059333336d51e289", null ],
    [ "receiver_topics", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a763e8918f5fefb06bf8e4588abb1d81b", null ],
    [ "remote_interest_pcre_patterns", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a15aae0798fea7d1deedfe403a5d8a76b", null ],
    [ "remote_interest_regex_patterns", "structtnwg__portal__endpoint__dstat__record__t__stct.html#aebfd315bf5fe2453b607e58b1cb308aa", null ],
    [ "remote_interest_topics", "structtnwg__portal__endpoint__dstat__record__t__stct.html#a07cc0f70d377bef3e847f0b66dde4af3", null ],
    [ "send_stats", "structtnwg__portal__endpoint__dstat__record__t__stct.html#ac4df2116bdc47907f6059f79fc81655d", null ]
];