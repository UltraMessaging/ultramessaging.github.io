var structtnwg__dstat__gatewaycfg__msg__t__stct =
[
    [ "data", "structtnwg__dstat__gatewaycfg__msg__t__stct.html#a4f72360cd45b5191a11b608e7a3ce052", null ],
    [ "msghdr", "structtnwg__dstat__gatewaycfg__msg__t__stct.html#ab6327b0e63ca9b74d74a5afdce7b3a7f", null ]
];