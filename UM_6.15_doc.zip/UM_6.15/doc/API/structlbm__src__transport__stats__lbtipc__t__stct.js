var structlbm__src__transport__stats__lbtipc__t__stct =
[
    [ "bytes_sent", "structlbm__src__transport__stats__lbtipc__t__stct.html#a640ee5a27d5d2659c1e74ffb3d39b00e", null ],
    [ "msgs_sent", "structlbm__src__transport__stats__lbtipc__t__stct.html#aa71c033adada3522adc4ee6fdcee7502", null ],
    [ "num_clients", "structlbm__src__transport__stats__lbtipc__t__stct.html#a4cab35a71697d41cd9884878ece220ae", null ]
];