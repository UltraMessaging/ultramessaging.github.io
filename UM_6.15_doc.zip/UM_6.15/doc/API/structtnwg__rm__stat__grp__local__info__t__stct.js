var structtnwg__rm__stat__grp__local__info__t__stct =
[
    [ "gateway_count", "structtnwg__rm__stat__grp__local__info__t__stct.html#aa6d736570111de32e815b42b7b8b2a18", null ],
    [ "gateway_id", "structtnwg__rm__stat__grp__local__info__t__stct.html#a77a92cd07c42d3a6861d42c79e720d7d", null ],
    [ "gateway_name", "structtnwg__rm__stat__grp__local__info__t__stct.html#a5a9b69849ef600252cb6437ca5ad8722", null ],
    [ "graph_version", "structtnwg__rm__stat__grp__local__info__t__stct.html#a82d091a497ef57aa460c03d9cad0a9df", null ],
    [ "recalc_duration_sec", "structtnwg__rm__stat__grp__local__info__t__stct.html#ad28192c529605f892aadf8643abecefc", null ],
    [ "recalc_duration_usec", "structtnwg__rm__stat__grp__local__info__t__stct.html#a91e0b6779d7c77b82247fd0406d586a2", null ],
    [ "self_version", "structtnwg__rm__stat__grp__local__info__t__stct.html#a92cbc8b24253754bc3bbdfd055c4dca1", null ],
    [ "topology_signature", "structtnwg__rm__stat__grp__local__info__t__stct.html#ab8a7bb454c0ebf8f5d932ca92a7ac8b7", null ],
    [ "trd_count", "structtnwg__rm__stat__grp__local__info__t__stct.html#aeef41e1c95dfcfcb43317afd9461bcb7", null ]
];