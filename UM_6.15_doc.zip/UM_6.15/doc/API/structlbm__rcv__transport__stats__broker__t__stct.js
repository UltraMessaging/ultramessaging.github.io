var structlbm__rcv__transport__stats__broker__t__stct =
[
    [ "bytes_rcved", "structlbm__rcv__transport__stats__broker__t__stct.html#a8b24b2cf283cc51b0e4c663fd9005d46", null ],
    [ "msgs_rcved", "structlbm__rcv__transport__stats__broker__t__stct.html#ae93b7d7565dc68783ee6d13b9b0c2619", null ]
];