var structumestore__repo__dmon__config__msg__t__stct =
[
    [ "age_threshold", "structumestore__repo__dmon__config__msg__t__stct.html#a883cf0e70b3b99844e2368a229e5f0bd", null ],
    [ "allow_ack_on_reception", "structumestore__repo__dmon__config__msg__t__stct.html#a46b249c6226447afad6d01d2dcde8974", null ],
    [ "disk_aio_buffer_len", "structumestore__repo__dmon__config__msg__t__stct.html#a2e8ce78938aea93d06da591645774574", null ],
    [ "disk_max_read_aiocbs", "structumestore__repo__dmon__config__msg__t__stct.html#a8574c8ed5ca74262443c2652e96707dc", null ],
    [ "disk_max_write_aiocbs", "structumestore__repo__dmon__config__msg__t__stct.html#aa1aa7590ff955fc3559fe3ec17129fbb", null ],
    [ "disk_sz_limit", "structumestore__repo__dmon__config__msg__t__stct.html#adb3c421023777daf30f5edb344be3900", null ],
    [ "dmon_topic_idx", "structumestore__repo__dmon__config__msg__t__stct.html#affd53554cc79021127c156c972ba36a4", null ],
    [ "hdr", "structumestore__repo__dmon__config__msg__t__stct.html#acf785a5d21975e772b71d6b9de5c8275", null ],
    [ "regid", "structumestore__repo__dmon__config__msg__t__stct.html#ac0da140a7880e0e6a41f085b1c9bc71c", null ],
    [ "sid", "structumestore__repo__dmon__config__msg__t__stct.html#a085305d6222f495bdaee5de8978cbbe2", null ],
    [ "src_flightsz_bytes", "structumestore__repo__dmon__config__msg__t__stct.html#ad651c855aa658187f8bf72196a366583", null ],
    [ "store_idx", "structumestore__repo__dmon__config__msg__t__stct.html#a158aeaaae72752677f71be98ea57c2e1", null ],
    [ "sz_limit", "structumestore__repo__dmon__config__msg__t__stct.html#afe50de96f5a72f3296469076674961f8", null ],
    [ "sz_threshold", "structumestore__repo__dmon__config__msg__t__stct.html#a8bced1a9b3dae1702c90b26ab5a4370e", null ],
    [ "type", "structumestore__repo__dmon__config__msg__t__stct.html#a8a191f2386854efbd28befd2a5c0d904", null ],
    [ "write_delay", "structumestore__repo__dmon__config__msg__t__stct.html#a934cf2fcd377c39f5f6b457266b672be", null ]
];