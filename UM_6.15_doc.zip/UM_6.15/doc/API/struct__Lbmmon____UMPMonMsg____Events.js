var struct__Lbmmon____UMPMonMsg____Events =
[
    [ "base", "struct__Lbmmon____UMPMonMsg____Events.html#af243bcf7de315cb1de98543c4f68ef1b", null ],
    [ "events", "struct__Lbmmon____UMPMonMsg____Events.html#afa12817a17ea6f1b457e20fca4539ce6", null ],
    [ "n_events", "struct__Lbmmon____UMPMonMsg____Events.html#aa3afa44ecbed4e23e55ffa728831e9f6", null ]
];