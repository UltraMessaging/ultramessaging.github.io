var structlbm__resolver__event__func__t__stct =
[
    [ "clientd", "structlbm__resolver__event__func__t__stct.html#ab275cb06f63899f7f5698597cc037311", null ],
    [ "event_cb_func", "structlbm__resolver__event__func__t__stct.html#a5971b098f6ef36b08059b0199b68640c", null ]
];