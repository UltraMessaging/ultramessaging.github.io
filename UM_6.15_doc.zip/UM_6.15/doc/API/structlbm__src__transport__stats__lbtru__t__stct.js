var structlbm__src__transport__stats__lbtru__t__stct =
[
    [ "bytes_sent", "structlbm__src__transport__stats__lbtru__t__stct.html#a9851cc6a90ccb8e318b022818ea57c58", null ],
    [ "msgs_sent", "structlbm__src__transport__stats__lbtru__t__stct.html#a33977a0a14846929f481fa61b10a45fe", null ],
    [ "nak_pckts_rcved", "structlbm__src__transport__stats__lbtru__t__stct.html#ae567bd7f28c540faecf2864e8829af8a", null ],
    [ "naks_ignored", "structlbm__src__transport__stats__lbtru__t__stct.html#a3f2a675528727a6d758cc41a8d8f5201", null ],
    [ "naks_rcved", "structlbm__src__transport__stats__lbtru__t__stct.html#a9833ac2f8d6a9e6708a6848b641a6a4c", null ],
    [ "naks_rx_delay_ignored", "structlbm__src__transport__stats__lbtru__t__stct.html#a1c46665e5d1c207ff52d5bdc5777a8c6", null ],
    [ "naks_shed", "structlbm__src__transport__stats__lbtru__t__stct.html#a8b27273ad2887a0d7d11a91d6cd28258", null ],
    [ "num_clients", "structlbm__src__transport__stats__lbtru__t__stct.html#af77f17b77c54450902654a0482dcd8f9", null ],
    [ "rx_bytes_sent", "structlbm__src__transport__stats__lbtru__t__stct.html#ae40c00c037145b33a904f232cb633740", null ],
    [ "rxs_sent", "structlbm__src__transport__stats__lbtru__t__stct.html#a118a840dd8a4c9a65f4a947784e19080", null ]
];