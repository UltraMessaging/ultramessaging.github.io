
	Ultra Messaging(R) Dynamic Routing Option Documentation
     --------------------------------------------------------------

     --------------------------------------------------------------

        Welcome to the UM Dynamic Routing Option Version 6.0
	documentation package.

	The documentation package is available as a zip or tar file,
        which you must unpack and install.

