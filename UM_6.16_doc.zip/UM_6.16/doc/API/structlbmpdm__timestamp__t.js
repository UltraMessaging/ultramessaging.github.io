var structlbmpdm__timestamp__t =
[
    [ "tv_secs", "structlbmpdm__timestamp__t.html#a8f974e0483ed4e159a57206afb0a0c4a", null ],
    [ "tv_usecs", "structlbmpdm__timestamp__t.html#aaaffbac796ff0367c702950f24f3b81d", null ]
];