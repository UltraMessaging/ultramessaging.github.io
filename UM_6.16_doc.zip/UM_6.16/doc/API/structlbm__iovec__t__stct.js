var structlbm__iovec__t__stct =
[
    [ "iov_base", "structlbm__iovec__t__stct.html#aca0888a070a2966bbae4250bc450017d", null ],
    [ "iov_len", "structlbm__iovec__t__stct.html#a2736e4d643130a23db7f2910572e4ca7", null ]
];