var structlbm__ssrc__send__ex__info__t__stct =
[
    [ "channel", "structlbm__ssrc__send__ex__info__t__stct.html#af3318fcf60e612912d16cd401e8aa39e", null ],
    [ "flags", "structlbm__ssrc__send__ex__info__t__stct.html#a20b6feb8a3737d2ad4330c64552ba18c", null ],
    [ "mprop_int_cnt", "structlbm__ssrc__send__ex__info__t__stct.html#a26e6f73e26bd532ad9ea5c6ceb18c943", null ],
    [ "mprop_int_keys", "structlbm__ssrc__send__ex__info__t__stct.html#ad8ba521d9bfb2125401f7106b34055ad", null ],
    [ "mprop_int_vals", "structlbm__ssrc__send__ex__info__t__stct.html#ac81546a02860998dd8d751a01edb3b42", null ],
    [ "ume_msg_clientd", "structlbm__ssrc__send__ex__info__t__stct.html#a9d42d1deee5fda52b22c3bdcbd0b3cce", null ],
    [ "usr_supplied_buffer", "structlbm__ssrc__send__ex__info__t__stct.html#adcb94e05adb46da7cb8cce93a656b7d4", null ]
];