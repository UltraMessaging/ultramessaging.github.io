var struct__Lbmmon____DROMonMsg____Stats____Portal____Peer =
[
    [ "adjacent_gateway_id", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer.html#a3b592095ee3b06bd7ead6fb68f3cfc0f", null ],
    [ "base", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer.html#aa8adcfa721afccc992029e42b17b508a", null ],
    [ "interest_pcre_patterns", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer.html#ad9d40738eb3ae1e32f82e55a423d4aa3", null ],
    [ "interest_regex_patterns", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer.html#a8dc2168e5fc8fe75c2902cd2145983a9", null ],
    [ "interest_topics", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer.html#ad44d2fd22d83ae19415950ac16dc8b48", null ],
    [ "receive", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer.html#a2c6c74b1e6f72b5a5e18ef0b5e4e6284", null ],
    [ "send", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer.html#a73ce0aa1ea5b32b8f0e25aed616cbcd0", null ],
    [ "udp_receive", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer.html#a684eb700897bb785180451ce4ec4b43d", null ],
    [ "udp_send", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer.html#a3774adb126e1adbac8d1fc5d3da3846b", null ]
];