var unionlbm__hf__sequence__number__t__stct =
[
    [ "u32", "unionlbm__hf__sequence__number__t__stct.html#a8f0f3267a2348a54da8b942b168155ad", null ],
    [ "u64", "unionlbm__hf__sequence__number__t__stct.html#a4fb49f81d3087a55415094138424ef69", null ]
];