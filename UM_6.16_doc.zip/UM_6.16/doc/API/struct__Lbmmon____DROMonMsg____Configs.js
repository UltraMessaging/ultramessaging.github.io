var struct__Lbmmon____DROMonMsg____Configs =
[
    [ "base", "struct__Lbmmon____DROMonMsg____Configs.html#a5a2da83dbc77e859cf2345d16bdb4d14", null ],
    [ "gateway", "struct__Lbmmon____DROMonMsg____Configs.html#a5ef5bf671a4e87a06220ac5dbd71515e", null ],
    [ "n_portals", "struct__Lbmmon____DROMonMsg____Configs.html#a4786669c61f1a0b4a47bc728d6537f70", null ],
    [ "portals", "struct__Lbmmon____DROMonMsg____Configs.html#a870df0f21eac0a5266f5c082b212cf15", null ]
];