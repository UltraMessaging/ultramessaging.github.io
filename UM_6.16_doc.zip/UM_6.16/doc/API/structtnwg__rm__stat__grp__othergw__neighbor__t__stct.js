var structtnwg__rm__stat__grp__othergw__neighbor__t__stct =
[
    [ "domain_or_gateway", "structtnwg__rm__stat__grp__othergw__neighbor__t__stct.html#a7ac3bb2d54ca228fdff107c7dbec1834", null ],
    [ "ingress_cost", "structtnwg__rm__stat__grp__othergw__neighbor__t__stct.html#a881f7a52e114e61910fe94fe5d9aa559", null ],
    [ "node_id", "structtnwg__rm__stat__grp__othergw__neighbor__t__stct.html#a8520f0c77059b81293ffce20cddadb47", null ]
];