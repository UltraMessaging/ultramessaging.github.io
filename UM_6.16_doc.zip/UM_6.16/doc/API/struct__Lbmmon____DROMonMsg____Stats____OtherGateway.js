var struct__Lbmmon____DROMonMsg____Stats____OtherGateway =
[
    [ "base", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway.html#ab8002e4fb3b461b0bfe657b8e3399695", null ],
    [ "gateway_id", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway.html#a3ed2f2a3e45cc1a8c5da821b924c3195", null ],
    [ "gateway_name", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway.html#a233a1bd4d13460c8d5e871a0b11e3dca", null ],
    [ "last_activity_sec", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway.html#a88f43cd89b1b1b9d5af6c14baef5e104", null ],
    [ "last_activity_usec", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway.html#a3d555fbfec41cf9de9720ce0505a6734", null ],
    [ "n_other_portals", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway.html#aa13edc7c99d80ca8ac027f4fc5cda8e3", null ],
    [ "other_portals", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway.html#a1ea8db15c235a9c1865d6caa5117c771", null ],
    [ "topology_signature", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway.html#add02e35059f48cad3ad8c9463b6b249e", null ],
    [ "version", "struct__Lbmmon____DROMonMsg____Stats____OtherGateway.html#aebebcfac552c5a7689f330acb3a84425", null ]
];