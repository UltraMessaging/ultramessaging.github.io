var structtnwg__portalstats__dstat__record__t__stct =
[
    [ "endpt", "structtnwg__portalstats__dstat__record__t__stct.html#a793abaa078b89b5b77348f9e3fff1d42", null ],
    [ "peer", "structtnwg__portalstats__dstat__record__t__stct.html#ad2f6f30fab1deb11484305cb2b6ec099", null ],
    [ "ptype", "structtnwg__portalstats__dstat__record__t__stct.html#a43b47e09d671362dffed514090f18a76", null ]
];