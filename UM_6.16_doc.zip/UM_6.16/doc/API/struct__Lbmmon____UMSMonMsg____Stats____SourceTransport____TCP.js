var struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____TCP =
[
    [ "base", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____TCP.html#a38791cec548065a6d564892708f8b4f9", null ],
    [ "bytes_buffered", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____TCP.html#a678885ce68c0995e0719080b8a4412ae", null ],
    [ "num_clients", "struct__Lbmmon____UMSMonMsg____Stats____SourceTransport____TCP.html#a5dbce8cd4be880bdf07c525f67e40e48", null ]
];