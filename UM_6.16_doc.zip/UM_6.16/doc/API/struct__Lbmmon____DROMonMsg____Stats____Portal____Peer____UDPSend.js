var struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend =
[
    [ "base", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#aab88e039ac7a02842d53552caed7414d", null ],
    [ "bytes_sent", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#acf50435f3cec2723fcdc408470d5871a", null ],
    [ "msgs_sent", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#a9633622a1833bdbb677085a6c8d86415", null ],
    [ "nak_pckts_rcved", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#a36da2dbc1c6728ad91fb9dcd7c0863da", null ],
    [ "naks_ignored", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#ad0c63afc52660270140f0f6c2551a921", null ],
    [ "naks_rcved", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#a21bf2c9b7ef6e16fee91160a55304c14", null ],
    [ "naks_rx_delay_ignored", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#a7554a63655135e5a26f34c569d1bef48", null ],
    [ "naks_shed", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#a9252412ccccd93369cfdeb63ffb55211", null ],
    [ "rx_bytes_sent", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#af36f516074f810162051afc0f8075ba9", null ],
    [ "rxs_sent", "struct__Lbmmon____DROMonMsg____Stats____Portal____Peer____UDPSend.html#a7b8cdc4b7f7182359cc220fcddaceacf", null ]
];