var classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignmentEligibilityStopCompleteInfo =
[
    [ "UMQIndexAssignmentEligibilityStopCompleteInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignmentEligibilityStopCompleteInfo.html#afd24e8641e6bf29e8434b8a1c0a1b06f", null ],
    [ "flags", "classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignmentEligibilityStopCompleteInfo.html#aa240073b40f4198272a411d9d0c2cf4c", null ],
    [ "queueId", "classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignmentEligibilityStopCompleteInfo.html#a705b18cf452a13f6a716ed55185e8f39", null ],
    [ "queueName", "classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignmentEligibilityStopCompleteInfo.html#a37a531aa7cde65ed22debdf3c6238aea", null ]
];