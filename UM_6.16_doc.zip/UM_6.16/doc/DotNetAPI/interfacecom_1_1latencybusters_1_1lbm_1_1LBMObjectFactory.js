var interfacecom_1_1latencybusters_1_1lbm_1_1LBMObjectFactory =
[
    [ "create", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMObjectFactory.html#a82a9b7e8b5e140f4ccafe035bac7ad8a", null ]
];