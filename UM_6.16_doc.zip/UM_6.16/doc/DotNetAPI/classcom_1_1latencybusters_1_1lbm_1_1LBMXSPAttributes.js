var classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes =
[
    [ "LBMXSPAttributes", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#a5fff4c1992eda5cb9aaddf9adc743ec4", null ],
    [ "Dispose", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#ab1a9f5c3ab5a93ebf5f02fec8d381771", null ],
    [ "dispose", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#af664c4758d522af564f6d88b71a3934a", null ],
    [ "getValue", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#a57e47f783b9cb968d4401b70e398b84a", null ],
    [ "setValue", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#a5e7a3cf04ae62df7ac319d985422ddb6", null ],
    [ "setZeroTransportsCallback", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#a243fe6203af9f1c0d77d05b13ff947cf", null ],
    [ "setZeroTransportsCallback", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#ac03721681097449b83be2d709597c43a", null ]
];