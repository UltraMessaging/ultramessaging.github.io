var classcom_1_1latencybusters_1_1lbm_1_1LBMEInvalException =
[
    [ "LBMEInvalException", "classcom_1_1latencybusters_1_1lbm_1_1LBMEInvalException.html#a641ffefb416b8df9ded23f71dca5a19c", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMEInvalException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];