var classcom_1_1latencybusters_1_1lbm_1_1LBMTimespec =
[
    [ "LBMTimespec", "classcom_1_1latencybusters_1_1lbm_1_1LBMTimespec.html#a1834d95d5ba028bbb467445b70caea3a", null ],
    [ "LBMTimespec", "classcom_1_1latencybusters_1_1lbm_1_1LBMTimespec.html#a8d1b8eeef061657af99565f459663ae4", null ],
    [ "tv_nsec", "classcom_1_1latencybusters_1_1lbm_1_1LBMTimespec.html#a765fc297a40317699212779e72831d15", null ],
    [ "tv_sec", "classcom_1_1latencybusters_1_1lbm_1_1LBMTimespec.html#ae781780e9ede783e4b0540e5b908387d", null ]
];