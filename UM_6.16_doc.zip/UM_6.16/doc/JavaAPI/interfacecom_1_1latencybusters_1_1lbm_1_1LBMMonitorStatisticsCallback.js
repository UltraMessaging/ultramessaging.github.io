var interfacecom_1_1latencybusters_1_1lbm_1_1LBMMonitorStatisticsCallback =
[
    [ "onReceive", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMMonitorStatisticsCallback.html#af98aaa48d457999902cbbdccdc83c132", null ],
    [ "onReceive", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMMonitorStatisticsCallback.html#a8729332c7a0ccc03fff0ebd38bbfe4c3", null ]
];