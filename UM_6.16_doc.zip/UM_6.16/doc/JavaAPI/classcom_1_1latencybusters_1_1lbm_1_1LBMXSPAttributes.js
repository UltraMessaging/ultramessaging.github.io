var classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes =
[
    [ "LBMXSPAttributes", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#aedf5f54029b97eb9917b45e61d61259d", null ],
    [ "dispose", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#af664c4758d522af564f6d88b71a3934a", null ],
    [ "finalize", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#a66f07e2877d49146342ea9d31cea7118", null ],
    [ "getValue", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#abea23eac4875897cd665ba502fd37d11", null ],
    [ "setValue", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#a281c7a7f2a17d07fb66749a4c6b2a054", null ],
    [ "setZeroTransportsCallback", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#ac03721681097449b83be2d709597c43a", null ],
    [ "setZeroTransportsCallback", "classcom_1_1latencybusters_1_1lbm_1_1LBMXSPAttributes.html#aac818e8c2e2b2882e0df136784f1054d", null ]
];