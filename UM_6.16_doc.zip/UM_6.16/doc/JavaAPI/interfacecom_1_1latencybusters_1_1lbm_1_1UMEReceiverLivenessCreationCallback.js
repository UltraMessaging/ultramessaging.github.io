var interfacecom_1_1latencybusters_1_1lbm_1_1UMEReceiverLivenessCreationCallback =
[
    [ "onNewReceiver", "interfacecom_1_1latencybusters_1_1lbm_1_1UMEReceiverLivenessCreationCallback.html#a9ed902ba27fec569ed4b1df6e592d3c7", null ]
];