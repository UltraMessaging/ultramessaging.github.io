var classcom_1_1latencybusters_1_1lbm_1_1UMEReceiverLivenessCallbackInfo =
[
    [ "UMEReceiverLivenessCallbackInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMEReceiverLivenessCallbackInfo.html#a77385bd15f5a709905e3a57789c8ce16", null ],
    [ "UMEReceiverLivenessCallbackInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMEReceiverLivenessCallbackInfo.html#aa0840fe548a04acaa03899dd67d1f133", null ],
    [ "flags", "classcom_1_1latencybusters_1_1lbm_1_1UMEReceiverLivenessCallbackInfo.html#a553e887055d3ddd01d91a1db590d6d5f", null ],
    [ "sessionId", "classcom_1_1latencybusters_1_1lbm_1_1UMEReceiverLivenessCallbackInfo.html#a6fabda1b179a5f839ce0e6e6b825dc64", null ],
    [ "userRcvRegId", "classcom_1_1latencybusters_1_1lbm_1_1UMEReceiverLivenessCallbackInfo.html#ad8c1176a794a9e96eb2b0e06564d3228", null ]
];