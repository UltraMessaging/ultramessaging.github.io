var classcom_1_1latencybusters_1_1lbm_1_1LBMEOSException =
[
    [ "LBMEOSException", "classcom_1_1latencybusters_1_1lbm_1_1LBMEOSException.html#a461e723ea0581528e01bad563530f6ec", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMEOSException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];