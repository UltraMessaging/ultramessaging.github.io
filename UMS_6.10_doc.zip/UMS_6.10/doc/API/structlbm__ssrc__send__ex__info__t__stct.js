var structlbm__ssrc__send__ex__info__t__stct =
[
    [ "buf_clientd", "structlbm__ssrc__send__ex__info__t__stct.html#ace2c8e1b90f60c6c7abcbfdc9bcab4dc", null ],
    [ "flags", "structlbm__ssrc__send__ex__info__t__stct.html#a20b6feb8a3737d2ad4330c64552ba18c", null ]
];