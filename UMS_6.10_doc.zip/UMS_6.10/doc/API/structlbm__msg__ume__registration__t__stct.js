var structlbm__msg__ume__registration__t__stct =
[
    [ "rcv_registration_id", "structlbm__msg__ume__registration__t__stct.html#a237395b6b2c007fca581b7080d86ef95", null ],
    [ "src_registration_id", "structlbm__msg__ume__registration__t__stct.html#a54d2370fce56d3e3233dc957a497eaa1", null ]
];