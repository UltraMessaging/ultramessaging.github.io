var structlbm__src__notify__func__t__stct =
[
    [ "clientd", "structlbm__src__notify__func__t__stct.html#a2e904f27567082bdb7e54e04b8694907", null ],
    [ "notifyfunc", "structlbm__src__notify__func__t__stct.html#acc91123de8347094880ca9423a15cb85", null ]
];