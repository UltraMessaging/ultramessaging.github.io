var structlbm__rcv__batch__notify__func__t__stct =
[
    [ "clientd", "structlbm__rcv__batch__notify__func__t__stct.html#ae4905df4b5c72a3871657abfc347eb19", null ],
    [ "end_notify", "structlbm__rcv__batch__notify__func__t__stct.html#acd7974dfa589bd339a3dd3cd6fce3caf", null ],
    [ "start_notify", "structlbm__rcv__batch__notify__func__t__stct.html#a6f5ea73924e7160ff2f23166dda440d5", null ]
];