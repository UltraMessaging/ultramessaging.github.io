var structlbm__delete__cb__info__t__stct =
[
    [ "cbproc", "structlbm__delete__cb__info__t__stct.html#a80257a96cd14a93b41e644dce3fb8b27", null ],
    [ "clientd", "structlbm__delete__cb__info__t__stct.html#a4bf8b8542ec7194803a7a2c7444ad635", null ]
];