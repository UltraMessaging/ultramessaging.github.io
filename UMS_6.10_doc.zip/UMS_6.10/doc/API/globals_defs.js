var globals_defs =
[
    [ "l", "globals_defs.html", null ],
    [ "p", "globals_defs_p.html", null ]
];