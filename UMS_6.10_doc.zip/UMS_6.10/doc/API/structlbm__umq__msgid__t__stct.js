var structlbm__umq__msgid__t__stct =
[
    [ "regid", "structlbm__umq__msgid__t__stct.html#aead8acc1f6385cf70c3b58919a307b1d", null ],
    [ "stamp", "structlbm__umq__msgid__t__stct.html#aa0618a15d44eea76a95ee9f309f152ed", null ]
];