var structlbm__ume__store__name__entry__t__stct =
[
    [ "group_index", "structlbm__ume__store__name__entry__t__stct.html#a9d489a26c8051d9fce870699ecb60684", null ],
    [ "name", "structlbm__ume__store__name__entry__t__stct.html#a77bc618437717af0877cc8c2e676d882", null ],
    [ "registration_id", "structlbm__ume__store__name__entry__t__stct.html#aa4aa06af3ae8eb1bdfe332f872de4bd5", null ]
];