var structlbm__context__event__umq__registration__ex__t__stct =
[
    [ "flags", "structlbm__context__event__umq__registration__ex__t__stct.html#a3d5b2656409424e73738e5d9d5da8d7b", null ],
    [ "queue", "structlbm__context__event__umq__registration__ex__t__stct.html#aedb2ceecb52b3f9c0cf3c4c9ccc56a91", null ],
    [ "queue_id", "structlbm__context__event__umq__registration__ex__t__stct.html#adb67a94fa1bac144fa3498bf2febee44", null ],
    [ "queue_instance", "structlbm__context__event__umq__registration__ex__t__stct.html#abb69bdf41181ae57829e9576c0e41731", null ],
    [ "queue_instance_index", "structlbm__context__event__umq__registration__ex__t__stct.html#ad26d2aaf707d0cdf4bff941fd755de7e", null ],
    [ "registration_id", "structlbm__context__event__umq__registration__ex__t__stct.html#a2cc66037aa8b46b83b2a3e831c54a39f", null ]
];