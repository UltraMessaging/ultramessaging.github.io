var structlbm__src__transport__stats__broker__t__stct =
[
    [ "bytes_sent", "structlbm__src__transport__stats__broker__t__stct.html#a0cdd755fc7a6e719c998af3378aa1a53", null ],
    [ "msgs_sent", "structlbm__src__transport__stats__broker__t__stct.html#a0d87e31562d0161580fc77041bb13618", null ]
];