var structlbm__config__option__stct__t =
[
    [ "oname", "structlbm__config__option__stct__t.html#a5c2c75c8becdf47d95dfc525dd1706d5", null ],
    [ "type", "structlbm__config__option__stct__t.html#a67be765508bf14e42f182e078ac91107", null ],
    [ "val", "structlbm__config__option__stct__t.html#ab9210b2cf014662e6c23c80b643d4ca1", null ]
];