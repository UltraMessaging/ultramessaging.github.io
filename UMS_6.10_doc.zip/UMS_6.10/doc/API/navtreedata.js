var NAVTREE =
[
  [ "UM C API", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "LBMMON Example source code", "lbmmon_examples.html", "lbmmon_examples" ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Typedefs", "globals_type.html", "globals_type" ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"group__get__elem__idx.html#ga5478bee2c3b6a6cfcd1fa594eaf7a160",
"group__set__array__iter.html#ga94cca380b68464ad38c0e9412e4514b9",
"group__set__name.html#gac1b20eae556b27718746ba54211e5242",
"lbm_8h.html#a3adf720d87af9645648ea6f61d9beca1",
"lbm_8h.html#a7ae240edef081d4f199f336be08f2f8c",
"lbm_8h.html#ab8fc2e2fb0287dfa80713fb8fb6c23df",
"lbm_8h.html#af4b83e6b46d14665863e7f9891ec135c",
"lbmpdm_8h.html#a70ce762beb0e73d35606e85f11cbe0dd",
"structlbm__context__src__event__func__t__stct.html",
"structlbm__rcv__transport__stats__lbtrdma__t__stct.html#a088e28674e4bb82acbb457b9af05ddb0",
"structlbm__src__transport__stats__t__stct.html#a8ecbc253a05324609c3bcd6bb1b9cc53"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';