var NAVTREE =
[
  [ "UM .NET API", "index.html", [
    [ "Introduction", "index.html", [
      [ "UM .NET API", "index.html#umnetapi", [
        [ "Using UM .NET on Windows", "index.html#usingumnetonwindows", null ],
        [ "Using UM .NET on Linux", "index.html#usingumnetonlinux", null ]
      ] ]
    ] ],
    [ "Packages", null, [
      [ "Packages", "namespaces.html", "namespaces" ],
      [ "Package Functions", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Properties", "functions_prop.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"classcom_1_1latencybusters_1_1lbm_1_1LBM.html#adda9e1ac033156d2ac9d943bd600b138",
"classcom_1_1latencybusters_1_1lbm_1_1LBMEventQueue.html#ad347f34b2e39c989c08d14c52e177311",
"classcom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageReceiverStatistics.html#ad3efe6b12b12c5d980515e97ea82b8bf",
"classcom_1_1latencybusters_1_1lbm_1_1LBMObjectRecycler.html#a1fea9ddab778dacac8e32b7f39f8a4f9",
"classcom_1_1latencybusters_1_1lbm_1_1LBMSource.html#a3afd1b714f0922e27db7f9cf8ed244fc",
"classcom_1_1latencybusters_1_1lbm_1_1LBMWildcardReceiverAttributes.html#ab0faf277d522a2f55a495c4ee56f4164",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMAddingFieldException.html",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayDouble.html#a0878bbf18e623186cb13ac4b22bbaf92",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayInt32.html#a1f6b1c9737c7e9d8a660e95175c2c917",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayMessage.html#a3b81db0363e0990f6be20124fe45dd2d",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayUint16.html#a57c5c0362b44c6c0d6ff6dc411c1de17",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayUint8.html#a5385943298807b324d25eab6b67d447d",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldBlob.html#a8124b74668c374a75bdfceed824e0663",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldDouble.html#ae1eebb9d2ed919301ba70edff6e9bdbc",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldInt64.html#a570025e8a64759fd31ba0c9892e9c624",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldString.html#a945e60424909c76a16e324fd8369903e",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldUint32.html#af8de14f9c4290ce3c9acdefcbd3372b7",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldsAttribute.html#ac9d11718e89268beca4f591e65ac38e0",
"classcom_1_1latencybusters_1_1pdm_1_1PDMDefinitionCache.html#a016b034c863a969ee7c9aa1406fa0c70",
"classcom_1_1latencybusters_1_1pdm_1_1PDMMessage.html#aa1ea3521acc44f1ba1e17e0170408ab1"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';