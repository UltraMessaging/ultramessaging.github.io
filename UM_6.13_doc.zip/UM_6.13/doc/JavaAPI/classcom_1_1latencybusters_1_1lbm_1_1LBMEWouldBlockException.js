var classcom_1_1latencybusters_1_1lbm_1_1LBMEWouldBlockException =
[
    [ "LBMEWouldBlockException", "classcom_1_1latencybusters_1_1lbm_1_1LBMEWouldBlockException.html#ab77bd8c2f2bcb45312d21f8cf9db4a7a", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMEWouldBlockException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];