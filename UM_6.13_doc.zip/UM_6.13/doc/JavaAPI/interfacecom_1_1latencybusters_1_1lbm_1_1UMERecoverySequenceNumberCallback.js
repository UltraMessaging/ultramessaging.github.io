var interfacecom_1_1latencybusters_1_1lbm_1_1UMERecoverySequenceNumberCallback =
[
    [ "setRecoverySequenceNumberInfo", "interfacecom_1_1latencybusters_1_1lbm_1_1UMERecoverySequenceNumberCallback.html#a25eef42d918e8efa6b75622fe9899399", null ]
];