var globals_dup =
[
    [ "l", "globals.html", null ],
    [ "p", "globals_p.html", null ],
    [ "u", "globals_u.html", null ]
];