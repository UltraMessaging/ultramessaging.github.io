var structlbm__src__event__umq__ulb__message__info__ex__t__stct =
[
    [ "application_set_index", "structlbm__src__event__umq__ulb__message__info__ex__t__stct.html#a50e32485887c4f917aceb405713a6cca", null ],
    [ "assignment_id", "structlbm__src__event__umq__ulb__message__info__ex__t__stct.html#a2525cb1251c17cd7c6f69e901e36564e", null ],
    [ "first_sequence_number", "structlbm__src__event__umq__ulb__message__info__ex__t__stct.html#a6e053606d7d4874450786e44640f0783", null ],
    [ "flags", "structlbm__src__event__umq__ulb__message__info__ex__t__stct.html#aaae281f78a6a5bb7e08f2137eac8c8cd", null ],
    [ "last_sequence_number", "structlbm__src__event__umq__ulb__message__info__ex__t__stct.html#aa224dbc51bad02def4a420c811b90ba9", null ],
    [ "msg_clientd", "structlbm__src__event__umq__ulb__message__info__ex__t__stct.html#a0df096cc5cfbb63026cd8d4fec516c3c", null ],
    [ "msg_id", "structlbm__src__event__umq__ulb__message__info__ex__t__stct.html#a51a9caf55a4736c5b918393cf39623b6", null ],
    [ "receiver", "structlbm__src__event__umq__ulb__message__info__ex__t__stct.html#af8bca65babd05493db5d8d98ae20d950", null ],
    [ "registration_id", "structlbm__src__event__umq__ulb__message__info__ex__t__stct.html#af4627fcb2f48ea163f121f02d97226a7", null ]
];