var structlbm__resolver__event__info__t__stct =
[
    [ "capability_flags", "structlbm__resolver__event__info__t__stct.html#a8d1270c24b68c6cff46e9d32cdc2a0dc", null ],
    [ "domain_id", "structlbm__resolver__event__info__t__stct.html#a2e96a3ef8fbad0f31fe548188156cf42", null ],
    [ "info_flags", "structlbm__resolver__event__info__t__stct.html#a075f406f30fbb6796a279fd98e905a24", null ],
    [ "source_id", "structlbm__resolver__event__info__t__stct.html#a8806d81d4a456464ddd79d6d639582eb", null ],
    [ "source_type", "structlbm__resolver__event__info__t__stct.html#a272fcdfe4d6b6cc589c5eb1c5e41f7c3", null ],
    [ "version", "structlbm__resolver__event__info__t__stct.html#adbfd9bf3ece135c568ed2620c4bc8820", null ]
];