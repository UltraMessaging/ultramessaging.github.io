var structlbm__ume__rcv__regid__ex__func__t__stct =
[
    [ "clientd", "structlbm__ume__rcv__regid__ex__func__t__stct.html#abd065f18f360e6bee5ebe9c6cbc6be8d", null ],
    [ "func", "structlbm__ume__rcv__regid__ex__func__t__stct.html#aa182b9c694a4d71b8a30487dd8eed8ea", null ]
];