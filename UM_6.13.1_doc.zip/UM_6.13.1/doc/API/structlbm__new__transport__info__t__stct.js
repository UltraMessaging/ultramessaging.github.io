var structlbm__new__transport__info__t__stct =
[
    [ "flags", "structlbm__new__transport__info__t__stct.html#a797e07d11ad21a53ba584794bff77420", null ],
    [ "source", "structlbm__new__transport__info__t__stct.html#a4612eb5493ada66f3765ebbddef47fc2", null ],
    [ "src_info", "structlbm__new__transport__info__t__stct.html#a518bcf8b6bf6b251d8804c285851b4cc", null ]
];