var structtnwg__dstat__record__hdr__t__stct =
[
    [ "index", "structtnwg__dstat__record__hdr__t__stct.html#a17ab959a5b825e9c3a14edd29565fa56", null ],
    [ "padding", "structtnwg__dstat__record__hdr__t__stct.html#afbeb8d4d921504cd2213e0ab2869c065", null ],
    [ "portal_name", "structtnwg__dstat__record__hdr__t__stct.html#a259dca70e2e2d30e16f6959ac899fd78", null ],
    [ "portal_type", "structtnwg__dstat__record__hdr__t__stct.html#a9018e934cd493a8286a905013edbceca", null ],
    [ "record_length", "structtnwg__dstat__record__hdr__t__stct.html#aad8cebe5ffa23060b7e705307f034ff9", null ]
];