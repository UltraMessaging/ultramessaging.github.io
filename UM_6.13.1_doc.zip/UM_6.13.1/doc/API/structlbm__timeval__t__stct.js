var structlbm__timeval__t__stct =
[
    [ "tv_sec", "structlbm__timeval__t__stct.html#ae87a40176e7f4e33a684af756678ecf8", null ],
    [ "tv_usec", "structlbm__timeval__t__stct.html#abd6c66bcb6ffa6fb41f243fedaf775ef", null ]
];