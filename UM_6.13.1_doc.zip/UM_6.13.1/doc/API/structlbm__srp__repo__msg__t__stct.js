var structlbm__srp__repo__msg__t__stct =
[
    [ "buff", "structlbm__srp__repo__msg__t__stct.html#a75128f2f2a454a6e216bd31f6d97bd00", null ],
    [ "disk_len", "structlbm__srp__repo__msg__t__stct.html#a524f665e6e0f66bb5c81c587f4e7959c", null ],
    [ "disk_offset", "structlbm__srp__repo__msg__t__stct.html#a05871e81adf664cef0fe5913c19b8c2d", null ],
    [ "flags", "structlbm__srp__repo__msg__t__stct.html#adc9a979f4e58eb3d3ac5a4f06ef120f3", null ],
    [ "frag_first_sqn", "structlbm__srp__repo__msg__t__stct.html#af7c9fa5db939f4ef38150eb623c3f543", null ],
    [ "frag_flags", "structlbm__srp__repo__msg__t__stct.html#a7667269a81d8b42e281e3911613d9e09", null ],
    [ "frag_hdr_len", "structlbm__srp__repo__msg__t__stct.html#a9322ae341d1560b1d55018a74f114556", null ],
    [ "frag_len", "structlbm__srp__repo__msg__t__stct.html#a1031bd0e94dac87e0884e2532bb2e66e", null ],
    [ "frag_next_hdr", "structlbm__srp__repo__msg__t__stct.html#ab3416273a8695c97eaccee060f4cab8c", null ],
    [ "frag_offset", "structlbm__srp__repo__msg__t__stct.html#aa6601cb8a1d8c53e72d3de737f12e611", null ],
    [ "fragment", "structlbm__srp__repo__msg__t__stct.html#a44d42e6b48daf3169b0e4e1ded55f50d", null ],
    [ "lbmc_msg_offset", "structlbm__srp__repo__msg__t__stct.html#a38e14d97486ffabd0119da49ad306e4a", null ],
    [ "lbmc_msglen", "structlbm__srp__repo__msg__t__stct.html#af977cc58eba852c6732ff0e135a4f48b", null ],
    [ "lbmc_next_hdr", "structlbm__srp__repo__msg__t__stct.html#afb5503173ad53c896d588f896a57ef85", null ],
    [ "lbmc_sqn", "structlbm__srp__repo__msg__t__stct.html#a5dc4ea6279e3bf3dfebc855f3020dcda", null ],
    [ "lbmc_tidx", "structlbm__srp__repo__msg__t__stct.html#a0d3365d42e5ddf0c3c12c41f801ce0f5", null ],
    [ "lbmc_ver_type", "structlbm__srp__repo__msg__t__stct.html#a3aae04ea231118f3716732655583eaf4", null ],
    [ "sqn", "structlbm__srp__repo__msg__t__stct.html#aea1fbe41e41220a0cd62e7643ea3ffe7", null ],
    [ "tsp", "structlbm__srp__repo__msg__t__stct.html#af21c925a926b50328baadbd5dfd41534", null ]
];