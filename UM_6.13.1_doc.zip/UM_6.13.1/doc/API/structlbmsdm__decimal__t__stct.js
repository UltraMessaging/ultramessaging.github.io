var structlbmsdm__decimal__t__stct =
[
    [ "exp", "structlbmsdm__decimal__t__stct.html#a927a44459e9c070f500ea835ed7d6d81", null ],
    [ "mant", "structlbmsdm__decimal__t__stct.html#aefa3edba0feabe8ce58310c930f50204", null ]
];