var structlbm__umq__index__info__t__stct =
[
    [ "flags", "structlbm__umq__index__info__t__stct.html#a8d6d7aea3ee6e087cfe41388ef4340ab", null ],
    [ "index", "structlbm__umq__index__info__t__stct.html#a1794cb901b21ab22b6be9ac739e2f470", null ],
    [ "index_len", "structlbm__umq__index__info__t__stct.html#a293ca8c75d33e163cd49f73b0a576b9f", null ],
    [ "reserved", "structlbm__umq__index__info__t__stct.html#ae99ef821aaa8aa7d15ee9dfb9c635796", null ]
];