var structlbm__ucast__resolver__entry__t__stct =
[
    [ "destination_port", "structlbm__ucast__resolver__entry__t__stct.html#a38258f7095df75e682d20e38fc08d36e", null ],
    [ "iface", "structlbm__ucast__resolver__entry__t__stct.html#aff2c1ece2469595319c6505369385741", null ],
    [ "resolver_ip", "structlbm__ucast__resolver__entry__t__stct.html#ac3cc5ea2061364232ed1bb5ac9b5a31e", null ],
    [ "source_port", "structlbm__ucast__resolver__entry__t__stct.html#ab6f96574e5782389967fafd2d12d50f4", null ]
];