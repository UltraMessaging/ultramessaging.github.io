var structlbm__msg__umq__registration__complete__ex__t__stct =
[
    [ "assignment_id", "structlbm__msg__umq__registration__complete__ex__t__stct.html#a7517c35b5ffef57f3f6b079bcabe68f7", null ],
    [ "flags", "structlbm__msg__umq__registration__complete__ex__t__stct.html#adafa026ceb01baddff84d1495526aa39", null ],
    [ "queue", "structlbm__msg__umq__registration__complete__ex__t__stct.html#af00d2047c9817868bc2946255cb8c44c", null ],
    [ "queue_id", "structlbm__msg__umq__registration__complete__ex__t__stct.html#ac707c47d20c03fbe42e5f3a975165848", null ]
];