var structlbm__rcv__src__notification__func__t__stct =
[
    [ "clientd", "structlbm__rcv__src__notification__func__t__stct.html#a0dd01701648ecca057c07cee3abd43a9", null ],
    [ "create_func", "structlbm__rcv__src__notification__func__t__stct.html#a21e8f6ccfe58569a8f25118576ba6e51", null ],
    [ "delete_func", "structlbm__rcv__src__notification__func__t__stct.html#aa4153d1fbbe0ffca2259c4f2fdf38584", null ]
];