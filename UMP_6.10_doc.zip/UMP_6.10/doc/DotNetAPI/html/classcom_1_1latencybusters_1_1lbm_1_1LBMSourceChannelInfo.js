var classcom_1_1latencybusters_1_1lbm_1_1LBMSourceChannelInfo =
[
    [ "LBMSourceChannelInfo", "classcom_1_1latencybusters_1_1lbm_1_1LBMSourceChannelInfo.html#ae0f0a2819b15df0dc2828014f629d788", null ],
    [ "close", "classcom_1_1latencybusters_1_1lbm_1_1LBMSourceChannelInfo.html#a958f7f9e62aaf7504a2613f559c09196", null ]
];