var classcom_1_1latencybusters_1_1lbm_1_1LBMException =
[
    [ "LBMException", "classcom_1_1latencybusters_1_1lbm_1_1LBMException.html#a511fc50049c8f603d09d965399966cfa", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];