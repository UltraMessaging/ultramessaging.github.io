var classcom_1_1latencybusters_1_1lbm_1_1LBMSourceEventFlightSizeNotification =
[
    [ "LBMSourceEventFlightSizeNotification", "classcom_1_1latencybusters_1_1lbm_1_1LBMSourceEventFlightSizeNotification.html#a5b43b8888c4178054c4027e7c48b9b2c", null ],
    [ "state", "classcom_1_1latencybusters_1_1lbm_1_1LBMSourceEventFlightSizeNotification.html#a3593a62f43ede748c45207c97c286d29", null ],
    [ "type", "classcom_1_1latencybusters_1_1lbm_1_1LBMSourceEventFlightSizeNotification.html#a78cf3d6f633da53e3f5c9b5db3d14ba7", null ]
];