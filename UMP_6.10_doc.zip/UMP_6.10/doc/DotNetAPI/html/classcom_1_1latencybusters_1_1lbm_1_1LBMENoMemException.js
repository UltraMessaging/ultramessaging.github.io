var classcom_1_1latencybusters_1_1lbm_1_1LBMENoMemException =
[
    [ "LBMENoMemException", "classcom_1_1latencybusters_1_1lbm_1_1LBMENoMemException.html#adeb29687417f49242944dffc427b942f", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMENoMemException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];