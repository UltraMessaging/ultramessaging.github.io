var classcom_1_1latencybusters_1_1lbm_1_1UMQQueueInstanceInfo =
[
    [ "UMQQueueInstanceInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMQQueueInstanceInfo.html#a26348ba70666753c786e23e5d186239f", null ],
    [ "flags", "classcom_1_1latencybusters_1_1lbm_1_1UMQQueueInstanceInfo.html#aa240073b40f4198272a411d9d0c2cf4c", null ],
    [ "queueId", "classcom_1_1latencybusters_1_1lbm_1_1UMQQueueInstanceInfo.html#a705b18cf452a13f6a716ed55185e8f39", null ],
    [ "queueInstanceIndex", "classcom_1_1latencybusters_1_1lbm_1_1UMQQueueInstanceInfo.html#ae7d641756c94f950ad32d8f7aa0a8c03", null ],
    [ "queueInstanceName", "classcom_1_1latencybusters_1_1lbm_1_1UMQQueueInstanceInfo.html#ad9d49f40a5432084649d025b25ada603", null ],
    [ "queueName", "classcom_1_1latencybusters_1_1lbm_1_1UMQQueueInstanceInfo.html#a37a531aa7cde65ed22debdf3c6238aea", null ]
];