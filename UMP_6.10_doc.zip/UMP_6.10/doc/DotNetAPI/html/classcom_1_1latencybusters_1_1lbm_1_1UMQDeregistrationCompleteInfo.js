var classcom_1_1latencybusters_1_1lbm_1_1UMQDeregistrationCompleteInfo =
[
    [ "UMQDeregistrationCompleteInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMQDeregistrationCompleteInfo.html#a689f783507c810d1b2b2a092a4f607b4", null ],
    [ "flags", "classcom_1_1latencybusters_1_1lbm_1_1UMQDeregistrationCompleteInfo.html#aa240073b40f4198272a411d9d0c2cf4c", null ],
    [ "queueId", "classcom_1_1latencybusters_1_1lbm_1_1UMQDeregistrationCompleteInfo.html#a705b18cf452a13f6a716ed55185e8f39", null ],
    [ "queueName", "classcom_1_1latencybusters_1_1lbm_1_1UMQDeregistrationCompleteInfo.html#a37a531aa7cde65ed22debdf3c6238aea", null ]
];