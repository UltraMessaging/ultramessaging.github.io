var classcom_1_1latencybusters_1_1lbm_1_1LBMEWouldBlockException =
[
    [ "LBMEWouldBlockException", "classcom_1_1latencybusters_1_1lbm_1_1LBMEWouldBlockException.html#ac35395a94772b94c77ed4955ed1e9bc4", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMEWouldBlockException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];