var NAVTREE =
[
  [ "UM .NET API", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "Packages", null, [
      [ "Packages", "namespaces.html", "namespaces" ],
      [ "Package Functions", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Properties", "functions_prop.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"classcom_1_1latencybusters_1_1lbm_1_1LBM.html#af09fd689fe9bbf58b1b9e32eebe07f57",
"classcom_1_1latencybusters_1_1lbm_1_1LBMEventQueueStatistics.html#a1c6430031ebb494fb5a09017fec869b2",
"classcom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageReceiverStatisticsObjectFactory.html",
"classcom_1_1latencybusters_1_1lbm_1_1LBMObjectRecycler.html#aa8a1e542bd8699b294e6abe8369722ec",
"classcom_1_1latencybusters_1_1lbm_1_1LBMSourceAttributes.html#a32221119f276894ba8c6e44a7b198480",
"classcom_1_1latencybusters_1_1lbm_1_1UMERecoverySequenceNumberCallbackInfo.html#ac6dff609ac830fce39696099c5553521",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayBlob.html#a66f0a6614f10413a3bd7cbfe8ab34905",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayDouble.html#aad2c20bf28b4d179f219abe8c869df66",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayInt32.html#ad7c52d28405ca869997b7ee49c84b40d",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayMessage.html#afb43cbe9a98a4d7f696ca77c31424845",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayUint32.html#a1d57f99dc7b116414372376df345e24f",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayUnicode.html#a47e759185c748e0c1114da82aa56696a",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldBool.html#a816bb235ac9882256dee4c377ca56a0b",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldInt16.html#a044a5e758de20eeb956207ff099d10c7",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldInt8.html#a9203078d0aaecf5c4d00c7088ee89eca",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldTimestamp.html#adadee445665d484d90980bbd2372dc78",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldUint8.html#a5fe5da3ab408870c244ab9694fba3e6f",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMRawTimestamp.html#a7431435a97cf3415e1c0dadf2e9f4e59",
"classcom_1_1latencybusters_1_1pdm_1_1PDMFieldInfo.html",
"functions_vars_u.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';