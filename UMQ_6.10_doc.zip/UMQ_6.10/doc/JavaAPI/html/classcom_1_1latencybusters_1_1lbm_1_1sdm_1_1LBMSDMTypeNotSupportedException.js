var classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMTypeNotSupportedException =
[
    [ "LBMSDMTypeNotSupportedException", "classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMTypeNotSupportedException.html#a1355a6594bb3aa5880c90f948f8e36af", null ],
    [ "LBMSDMTypeNotSupportedException", "classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMTypeNotSupportedException.html#a67d033531a00f88bbcbe76cc9e319db4", null ]
];