var classcom_1_1latencybusters_1_1lbm_1_1LBMEOPException =
[
    [ "LBMEOPException", "classcom_1_1latencybusters_1_1lbm_1_1LBMEOPException.html#aae42fe4989933e8f8bae91fa33581615", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMEOPException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];