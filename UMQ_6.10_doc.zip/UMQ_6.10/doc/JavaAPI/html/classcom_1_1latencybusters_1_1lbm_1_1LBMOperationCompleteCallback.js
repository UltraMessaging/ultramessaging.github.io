var classcom_1_1latencybusters_1_1lbm_1_1LBMOperationCompleteCallback =
[
    [ "LBMOperationCompleteCallback", "classcom_1_1latencybusters_1_1lbm_1_1LBMOperationCompleteCallback.html#ad437d2949edec2cc1265c4e36c00d6f8", null ],
    [ "onOperationComplete", "classcom_1_1latencybusters_1_1lbm_1_1LBMOperationCompleteCallback.html#ac8425f412d40a6fff02874ee8f582d25", null ]
];