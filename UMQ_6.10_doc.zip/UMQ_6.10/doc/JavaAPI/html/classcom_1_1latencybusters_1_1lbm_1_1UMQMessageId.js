var classcom_1_1latencybusters_1_1lbm_1_1UMQMessageId =
[
    [ "UMQMessageId", "classcom_1_1latencybusters_1_1lbm_1_1UMQMessageId.html#a48afb3803870d746009b31390d6b6229", null ],
    [ "msgStamp", "classcom_1_1latencybusters_1_1lbm_1_1UMQMessageId.html#a7398b135fad469c329b038c04475c541", null ],
    [ "registrationId", "classcom_1_1latencybusters_1_1lbm_1_1UMQMessageId.html#ac6ed808c1cac1e63e11832483e22a7de", null ]
];