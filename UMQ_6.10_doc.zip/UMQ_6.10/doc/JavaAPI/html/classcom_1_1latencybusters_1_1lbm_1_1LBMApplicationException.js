var classcom_1_1latencybusters_1_1lbm_1_1LBMApplicationException =
[
    [ "LBMApplicationException", "classcom_1_1latencybusters_1_1lbm_1_1LBMApplicationException.html#a31e30f15f7968e0e647aad07cfb26950", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMApplicationException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];