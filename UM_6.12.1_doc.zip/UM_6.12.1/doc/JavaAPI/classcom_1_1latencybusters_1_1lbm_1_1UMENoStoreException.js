var classcom_1_1latencybusters_1_1lbm_1_1UMENoStoreException =
[
    [ "UMENoStoreException", "classcom_1_1latencybusters_1_1lbm_1_1UMENoStoreException.html#a19c3fd3a5cbea9fc3cf711ecce8299c7", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1UMENoStoreException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];