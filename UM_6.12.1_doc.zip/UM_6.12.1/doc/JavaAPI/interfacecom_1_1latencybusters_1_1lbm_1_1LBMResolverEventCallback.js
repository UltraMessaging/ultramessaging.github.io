var interfacecom_1_1latencybusters_1_1lbm_1_1LBMResolverEventCallback =
[
    [ "onResolverEvent", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMResolverEventCallback.html#a11e73a3c067d4f082e8b498d4ceab5b9", null ]
];