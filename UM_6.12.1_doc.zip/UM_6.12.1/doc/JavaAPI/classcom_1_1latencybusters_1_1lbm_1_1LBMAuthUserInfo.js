var classcom_1_1latencybusters_1_1lbm_1_1LBMAuthUserInfo =
[
    [ "LBMAuthUserInfo", "classcom_1_1latencybusters_1_1lbm_1_1LBMAuthUserInfo.html#a3c5faa442dda81fe24a9725b90037214", null ],
    [ "password", "classcom_1_1latencybusters_1_1lbm_1_1LBMAuthUserInfo.html#a78024c346e8df55eb49345239013f0e9", null ],
    [ "setPassword", "classcom_1_1latencybusters_1_1lbm_1_1LBMAuthUserInfo.html#acb269b7ff46ccb0eed23f5a81aa45738", null ],
    [ "setUsername", "classcom_1_1latencybusters_1_1lbm_1_1LBMAuthUserInfo.html#ab52a810358036e5b20971ac9da6d5355", null ],
    [ "username", "classcom_1_1latencybusters_1_1lbm_1_1LBMAuthUserInfo.html#a6e06eded35c9308688e0438ec0ab086e", null ]
];