var interfacecom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageCallback =
[
    [ "onReceiveImmediate", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageCallback.html#abc88a7ccbce9a28d930a43d6e4ceaf18", null ]
];