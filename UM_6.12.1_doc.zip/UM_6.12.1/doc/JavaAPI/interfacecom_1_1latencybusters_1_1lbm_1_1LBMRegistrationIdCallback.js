var interfacecom_1_1latencybusters_1_1lbm_1_1LBMRegistrationIdCallback =
[
    [ "setRegistrationId", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMRegistrationIdCallback.html#a47cc681616c283ddc7c0e79c17239f37", null ]
];