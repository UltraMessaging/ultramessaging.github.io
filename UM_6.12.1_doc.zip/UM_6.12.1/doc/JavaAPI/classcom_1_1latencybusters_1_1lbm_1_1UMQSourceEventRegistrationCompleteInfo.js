var classcom_1_1latencybusters_1_1lbm_1_1UMQSourceEventRegistrationCompleteInfo =
[
    [ "UMQSourceEventRegistrationCompleteInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMQSourceEventRegistrationCompleteInfo.html#a73a52a23a4971d5346984c3c4701bb56", null ],
    [ "flags", "classcom_1_1latencybusters_1_1lbm_1_1UMQSourceEventRegistrationCompleteInfo.html#aa240073b40f4198272a411d9d0c2cf4c", null ],
    [ "queueId", "classcom_1_1latencybusters_1_1lbm_1_1UMQSourceEventRegistrationCompleteInfo.html#a705b18cf452a13f6a716ed55185e8f39", null ],
    [ "queueName", "classcom_1_1latencybusters_1_1lbm_1_1UMQSourceEventRegistrationCompleteInfo.html#a37a531aa7cde65ed22debdf3c6238aea", null ]
];