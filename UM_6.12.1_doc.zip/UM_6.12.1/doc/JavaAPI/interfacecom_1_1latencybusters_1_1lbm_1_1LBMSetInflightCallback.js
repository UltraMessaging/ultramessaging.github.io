var interfacecom_1_1latencybusters_1_1lbm_1_1LBMSetInflightCallback =
[
    [ "setInflight", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMSetInflightCallback.html#a348a0d115f5aed2b8a863583d2b885be", null ]
];