var NAVTREE =
[
  [ "UM Java API", "index.html", [
    [ "Introduction", "index.html", [
      [ "Java Native Interface (JNI)", "index.html#javanativeinterfacejni", null ],
      [ "Garbage Collection", "index.html#garbagecollection", null ],
      [ "Zero Object Delivery (ZOD)", "index.html#zeroobjectdeliveryzod", null ],
      [ "Retaining Messages", "index.html#retainingmessages", null ],
      [ "Message Size", "index.html#messagesize", null ],
      [ "Java Performance", "index.html#javaperformance", null ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classcom_1_1latencybusters_1_1lbm_1_1LBMContextThread.html",
"classcom_1_1latencybusters_1_1lbm_1_1LBMHotFailoverSource.html#a9f249320e775c4929e49fd22a19cc0d8",
"classcom_1_1latencybusters_1_1lbm_1_1LBMMessageProperty.html#a85d61dc9d126664dee3cd954b7347aea",
"classcom_1_1latencybusters_1_1lbm_1_1LBMReceiverStatistics.html#a7b6bc668adfac8612ddb8b81c5567f43",
"classcom_1_1latencybusters_1_1lbm_1_1LBMSourceStatistics.html#a0e2b231caa7026220785e9af49a50ead",
"classcom_1_1latencybusters_1_1lbm_1_1UMEStoreEntry.html#a5baa0f4a44c2c0c13d3ce73295525108",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayBool.html#ad7c0886a6591f9823706b42d2ffd8330",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayInt64.html#a6b933833df4ed3a1af75e7a2cf2b966d",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMArrayUint16.html#ad9b2b97218931aca92396a0d21e70461",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldBlob.html#a2169b46261bea6bda97b330c3b83d3d8",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldInt32.html#a82100d3861edd33c15af4df5e990ea69",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMFieldUint16.html#a910760b8ce41a2d754ef4d873d69c827",
"classcom_1_1latencybusters_1_1lbm_1_1sdm_1_1LBMSDMRawDecimal.html#afb2e193cf650f3e5841f24a755a87301",
"classcom_1_1latencybusters_1_1pdm_1_1PDMField.html#a5806f7935e8c6f903732a53ed8832426",
"functions_func_d.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';