var interfacecom_1_1latencybusters_1_1lbm_1_1LBMWildcardReceiverDeleteCallback =
[
    [ "onReceiverDelete", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMWildcardReceiverDeleteCallback.html#abb9a99e90e8cf7b4afad791c240a51c1", null ]
];