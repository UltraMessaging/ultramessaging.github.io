var classcom_1_1latencybusters_1_1lbm_1_1UMEDeregistrationCompleteInfo =
[
    [ "UMEDeregistrationCompleteInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMEDeregistrationCompleteInfo.html#acf02d92090e7cdfa91caa57e347835b6", null ],
    [ "UMEDeregistrationCompleteInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMEDeregistrationCompleteInfo.html#abf37c7c85e4635530d0b40c5367d9cb5", null ],
    [ "flags", "classcom_1_1latencybusters_1_1lbm_1_1UMEDeregistrationCompleteInfo.html#a23e3c6606719c282bffeeb34f391b0a0", null ],
    [ "sequenceNumber", "classcom_1_1latencybusters_1_1lbm_1_1UMEDeregistrationCompleteInfo.html#a363dab0fcef13987a751088ec1e27906", null ]
];