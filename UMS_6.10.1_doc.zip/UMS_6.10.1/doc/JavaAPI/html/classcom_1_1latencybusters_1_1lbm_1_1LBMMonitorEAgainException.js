var classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorEAgainException =
[
    [ "LBMMonitorEAgainException", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorEAgainException.html#a95677dca518ab4a75a4020b065734f11", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorEAgainException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];