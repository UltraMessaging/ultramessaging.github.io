var classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignedInfo =
[
    [ "UMQIndexAssignedInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignedInfo.html#a97fd8b935fd9ed58f32a3ab39168747f", null ],
    [ "flags", "classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignedInfo.html#aa240073b40f4198272a411d9d0c2cf4c", null ],
    [ "indexInfo", "classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignedInfo.html#acaab64a1dd0fd89ebab09b721b6db67c", null ],
    [ "queueId", "classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignedInfo.html#a705b18cf452a13f6a716ed55185e8f39", null ],
    [ "queueName", "classcom_1_1latencybusters_1_1lbm_1_1UMQIndexAssignedInfo.html#a37a531aa7cde65ed22debdf3c6238aea", null ]
];