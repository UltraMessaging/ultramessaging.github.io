var interfacecom_1_1latencybusters_1_1lbm_1_1UMERegistrationIdExCallback =
[
    [ "setRegistrationId", "interfacecom_1_1latencybusters_1_1lbm_1_1UMERegistrationIdExCallback.html#a6733a32c53a153cbac5937e143ecf05b", null ]
];