var interfacecom_1_1latencybusters_1_1lbm_1_1LBMReceiverCallback =
[
    [ "onReceive", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMReceiverCallback.html#a66e0cd0fdb6b277c829fb8e935f877ff", null ]
];