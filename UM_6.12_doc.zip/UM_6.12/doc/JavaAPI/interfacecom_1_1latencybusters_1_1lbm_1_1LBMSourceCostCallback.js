var interfacecom_1_1latencybusters_1_1lbm_1_1LBMSourceCostCallback =
[
    [ "onSourceCost", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMSourceCostCallback.html#a9a95e2eacf4559d523fcc381de20ec32", null ]
];