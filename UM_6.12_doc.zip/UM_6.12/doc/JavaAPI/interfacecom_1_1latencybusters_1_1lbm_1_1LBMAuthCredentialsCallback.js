var interfacecom_1_1latencybusters_1_1lbm_1_1LBMAuthCredentialsCallback =
[
    [ "onAuthRequest", "interfacecom_1_1latencybusters_1_1lbm_1_1LBMAuthCredentialsCallback.html#a54a78936550453f5b393200a9ebdb98f", null ]
];