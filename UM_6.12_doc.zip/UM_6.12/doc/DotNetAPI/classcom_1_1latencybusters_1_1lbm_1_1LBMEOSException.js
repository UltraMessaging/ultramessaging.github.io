var classcom_1_1latencybusters_1_1lbm_1_1LBMEOSException =
[
    [ "LBMEOSException", "classcom_1_1latencybusters_1_1lbm_1_1LBMEOSException.html#aca57016c9f6d11b1f16469e9f9cbfa3f", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMEOSException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];