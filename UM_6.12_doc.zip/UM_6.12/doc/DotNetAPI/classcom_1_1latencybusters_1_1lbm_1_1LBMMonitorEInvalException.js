var classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorEInvalException =
[
    [ "LBMMonitorEInvalException", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorEInvalException.html#a7e188b81c0988f467bf2e45ff3989388", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1LBMMonitorEInvalException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];