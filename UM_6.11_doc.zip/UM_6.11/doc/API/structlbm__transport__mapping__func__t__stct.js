var structlbm__transport__mapping__func__t__stct =
[
    [ "clientd", "structlbm__transport__mapping__func__t__stct.html#a0f67d0ef3770dc1414c7ccbb72752f61", null ],
    [ "mapping_func", "structlbm__transport__mapping__func__t__stct.html#a7b570d25543dd4e60be8b7f5107e6ad6", null ]
];