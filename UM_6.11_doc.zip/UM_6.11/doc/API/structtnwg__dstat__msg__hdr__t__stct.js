var structtnwg__dstat__msg__hdr__t__stct =
[
    [ "length", "structtnwg__dstat__msg__hdr__t__stct.html#adec3cf3b3713954bae1069ead3598850", null ],
    [ "magic", "structtnwg__dstat__msg__hdr__t__stct.html#a8c76f6ab6592bb010865c94719d0a138", null ],
    [ "tv_sec", "structtnwg__dstat__msg__hdr__t__stct.html#ac1b19162a8d0f445dcd4db44d7ddec21", null ],
    [ "tv_usec", "structtnwg__dstat__msg__hdr__t__stct.html#a654e9e6772941f588d39712a238e8a5d", null ],
    [ "type", "structtnwg__dstat__msg__hdr__t__stct.html#a25e3b34d7eaa376ce30cf662d45a0ad3", null ],
    [ "version", "structtnwg__dstat__msg__hdr__t__stct.html#ac25d8d5fa5b4329fe9d60e817edab688", null ]
];