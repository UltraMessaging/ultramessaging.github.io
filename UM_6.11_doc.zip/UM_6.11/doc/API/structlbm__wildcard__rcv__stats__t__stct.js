var structlbm__wildcard__rcv__stats__t__stct =
[
    [ "pattern", "structlbm__wildcard__rcv__stats__t__stct.html#a45dcb7dd7131525d0eaa525d013be336", null ],
    [ "type", "structlbm__wildcard__rcv__stats__t__stct.html#a013c6df622d0fcc55e426242a3fae1f9", null ]
];