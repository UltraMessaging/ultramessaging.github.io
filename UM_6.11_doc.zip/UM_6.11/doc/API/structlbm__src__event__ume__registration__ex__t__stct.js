var structlbm__src__event__ume__registration__ex__t__stct =
[
    [ "flags", "structlbm__src__event__ume__registration__ex__t__stct.html#ae9f5da93dba23287f1a3e21fe900ab37", null ],
    [ "registration_id", "structlbm__src__event__ume__registration__ex__t__stct.html#a2597610653b0c77f9d6fb60e2a04a68e", null ],
    [ "sequence_number", "structlbm__src__event__ume__registration__ex__t__stct.html#ae435ea742defd8af4894b25c9db10cca", null ],
    [ "store", "structlbm__src__event__ume__registration__ex__t__stct.html#af5299bff3739162ccf08da2d4b33cc67", null ],
    [ "store_index", "structlbm__src__event__ume__registration__ex__t__stct.html#a72569bff32bf79a0e1bd5d99d3ab9e6b", null ]
];