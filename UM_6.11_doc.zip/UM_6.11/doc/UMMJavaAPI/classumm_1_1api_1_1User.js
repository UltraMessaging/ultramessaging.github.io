var classumm_1_1api_1_1User =
[
    [ "User", "classumm_1_1api_1_1User.html#a8004f3667358eb07585227f738adef5e", null ],
    [ "User", "classumm_1_1api_1_1User.html#abb6f98a7317ab57ca2b581f648340a02", null ],
    [ "compare", "classumm_1_1api_1_1User.html#a64b4f9cea8258706edb368d9679c8732", null ],
    [ "getActive", "classumm_1_1api_1_1User.html#a6ee04879c2486587def3ea749fa59c3b", null ],
    [ "getId", "classumm_1_1api_1_1User.html#ac738c752f8f6eaa126cda4553b948f95", null ],
    [ "getPassword", "classumm_1_1api_1_1User.html#aaeb21d600769ae99afd859855dc09c9a", null ],
    [ "getTypeStr", "classumm_1_1api_1_1User.html#a482bd8f6561b83d97899ef684083b9c3", null ],
    [ "getUserName", "classumm_1_1api_1_1User.html#a12788fc9b5ddfe6558f1a03f2dc828f4", null ],
    [ "getUserType", "classumm_1_1api_1_1User.html#ae69dfb96ae10767ce7f9b7f57bbd539f", null ],
    [ "isActive", "classumm_1_1api_1_1User.html#a727a70bc9176e8a8eea4c0f2b731b03a", null ],
    [ "setActive", "classumm_1_1api_1_1User.html#a323f485a0f1826b19c483f487880fef1", null ],
    [ "setActive", "classumm_1_1api_1_1User.html#a8846294eb253c4e960ef7d5bc8c7d035", null ],
    [ "setId", "classumm_1_1api_1_1User.html#a0cf6fd75068606c24695de693db0b91a", null ],
    [ "setPassword", "classumm_1_1api_1_1User.html#a38ebf83535686e5212450e7fc61fa13e", null ],
    [ "setUserName", "classumm_1_1api_1_1User.html#ab70e8f3383af285e86a8ff3c259cafa3", null ],
    [ "setUserType", "classumm_1_1api_1_1User.html#ac37ff27546da45b4596a365d4a678562", null ]
];