var NAVTREEINDEX0 =
{
"configuringtheumdsserver.html":[2],
"index.html":[],
"index.html":[0],
"pages.html":[],
"runningumdsexampleapplications.html":[4],
"runningumdsexampleapplications.html#windowsjavaexample":[4,0],
"startingtheumdsserver.html":[3],
"umdsquickoverview.html":[1],
"umdsquickoverview.html#umdsclientinstallation":[1,1],
"umdsquickoverview.html#umdsserverinstallation":[1,0]
};
