var structumdsd__dstat__connection__pertopic__msg__stct =
[
    [ "hdr", "structumdsd__dstat__connection__pertopic__msg__stct.html#ae84b7a0f9bd4f52edc6d50e3228d81d0", null ],
    [ "record", "structumdsd__dstat__connection__pertopic__msg__stct.html#ae08da5d6815a397209510609386025db", null ]
];