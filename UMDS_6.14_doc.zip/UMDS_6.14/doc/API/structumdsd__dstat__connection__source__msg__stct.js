var structumdsd__dstat__connection__source__msg__stct =
[
    [ "hdr", "structumdsd__dstat__connection__source__msg__stct.html#af391cc469b1d3a7a1f94a17aea08b7cd", null ],
    [ "record", "structumdsd__dstat__connection__source__msg__stct.html#af01e949c9aef0a4dfbb25f8157d76098", null ]
];