var classcom_1_1latencybusters_1_1umds_1_1UMDSCertificateValidity =
[
    [ "get", "classcom_1_1latencybusters_1_1umds_1_1UMDSCertificateValidity.html#afb044813d93db04edfd41be171682ea9", null ],
    [ "set", "classcom_1_1latencybusters_1_1umds_1_1UMDSCertificateValidity.html#a8e5011d58a1cde010a1719a428b9fd27", null ]
];