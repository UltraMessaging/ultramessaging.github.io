var classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE =
[
    [ "AUTHENTICATION_FAILURE", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#ab3ed3d74fd5fcaf9d5dd5fe0efac5e34", null ],
    [ "CAPABILITY_MISMATCH", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#ac2d7f7c8a9c22dfeba86bb556b329c44", null ],
    [ "MISSING_CALLBACK", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#ab6c5d92c4dd9c45b46c9f5170d6fb24f", null ],
    [ "NO_ERROR", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#a4cee08a3fe1942a8ed718a2f03ce2709", null ],
    [ "SERVER_OPERATION_FAILED", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#a8ab59c7fce52d92f94f301b3354e6783", null ],
    [ "UNKNOWN_PROPERTY", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1ERRCODE.html#aac18ecbbec76fe5baf0d173d481c6214", null ]
];