var classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection =
[
    [ "COMPR_TYPE", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a4cb243a75576056cc5146181a0a0bf45", [
      [ "NONE", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a4cb243a75576056cc5146181a0a0bf45ab50339a10e1de285ac99d4c3990b8693", null ],
      [ "LZ4", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a4cb243a75576056cc5146181a0a0bf45aca0c64c0de8f56bc573828ea6d764594", null ]
    ] ],
    [ "UMDSServerConnection", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a31f9a4a3709018a77cffcb1c81477f46", null ],
    [ "UMDSServerConnection", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a8baf8173ccdc73bcffd9c2fe97485375", null ],
    [ "addCapability", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a8f573cd5246ad08305cdf75dd92200eb", null ],
    [ "close", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a81477a4a00edcf441b4d3b6479584157", null ],
    [ "compressBuffer", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a261d5ca602837d7f847f1048f9f44099", null ],
    [ "decompressMsg", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#ae621e5018f3876ce4af52d8c516b1de0", null ],
    [ "getProperty", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#afb350223c80712be773d1cfbb143beae", null ],
    [ "getUMDS", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#acc4a817ccdaa4bfd7575afb13fc6f051", null ],
    [ "isAuthenticated", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a607bbf94f9d393c4eebb0aae209f268d", null ],
    [ "isConnected", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a28f391ae5c183f93f97cceefe6e5d560", null ],
    [ "onEvent", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#ab38287131c436134ae2a67de2f244c62", null ],
    [ "onRequest", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a508aa492fbee4f541468df931093429e", null ],
    [ "onResponse", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a0efd2fc82524d7ab2a9f1c1def49f97e", null ],
    [ "send", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#aeae72334aaa55f43bbe3da527596e9e9", null ],
    [ "setCapabilities", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a71e4711dc939d77e3af3a69578c41b18", null ],
    [ "setProperty", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a83af801fb9533b07305e3abcf0e41edb", null ],
    [ "setProperty", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a47fbf2723c0997ff6207be27e685cea0", null ],
    [ "start", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a13d21960a531f3391e6aa634fd57a248", null ],
    [ "CAPABILITIES_REQUEST_RESPONSE", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a338f3966de67e77d213e8f0401830abf", null ],
    [ "compressionType", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a9585fc2ac5e8511f96b08cdcf530aee1", null ],
    [ "Authenticated", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#ac04796d780f108c6d0872b28dadd0333", null ],
    [ "Error", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a4c8c6d75f4b167962636bf46177b6ae5", null ],
    [ "ErrorStr", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a562eb53de09fdb6ce77467529ce6a933", null ],
    [ "ServerConfig", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#a736f741d904218f0dd31e7d70d7bd5ac", null ],
    [ "UMDS", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html#ab5b3b464f10229b13c5e8ed84aaf08db", null ]
];