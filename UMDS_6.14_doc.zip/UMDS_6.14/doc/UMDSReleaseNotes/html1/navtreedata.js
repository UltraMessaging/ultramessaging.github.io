var NAVTREE =
[
  [ "UMDS Release Notes", "index.html", [
    [ "Introduction", "index.html#firstsect", null ],
    [ "UMDS Version 6.14", "index.html#umdsversion6_14", [
      [ "Enhancements for UMDS 6.14", "index.html#enhancementsforumds6_14", null ],
      [ "Fixed Limitations for UMDS 6.14", "index.html#fixedlimitationsforumds6_14", null ],
      [ "Special Upgrade Instructions for 6.14", "index.html#specialupgradeinstructionsfor6_14", [
        [ "Unbounded Log File Growth", "index.html#unboundedlogfilegrowth", null ],
        [ "Server XML Configuration File Version", "index.html#serverxmlconfigurationfileversion", null ]
      ] ]
    ] ],
    [ "UMDS Version 6.13.1", "index.html#umdsversion6_13_1", [
      [ "Enhancements for UMDS 6.13.1", "index.html#enhancementsforumds6_13_1", null ],
      [ "Fixed Limitations for UMDS 6.13.1", "index.html#fixedlimitationsforumds6_13_1", null ]
    ] ],
    [ "UMDS Version 6.12", "index.html#umdsversion6_12", [
      [ "Enhancements for UMDS 6.12", "index.html#enhancementsforumds6_12", null ],
      [ "Fixed Limitations for UMDS 6.12", "index.html#fixedlimitationsforumds6_12", null ]
    ] ],
    [ "UMDS Version 6.0", "index.html#umdsversion6_0", [
      [ "Enhancements for UMDS 6.0", "index.html#enhancementsforumds6_0", null ],
      [ "Fixed Limitations for UMDS 6.0", "index.html#fixedlimitationsforumds6_0", null ]
    ] ],
    [ "UMSD Version 6.0.200", "index.html#umdsversion6_0_200", [
      [ "Enhancements for 6.0.200", "index.html#enhancementsforumds6_0_200", null ],
      [ "Fixed Limitations for 6.0.200", "index.html#fixedlimitationsforumds6_0_200", null ]
    ] ],
    [ "Known Problems and Limitations for UMDS", "index.html#knownlimitationsforumds", null ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';