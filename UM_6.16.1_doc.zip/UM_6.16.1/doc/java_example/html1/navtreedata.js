var NAVTREE =
[
  [ "Java Examples", "index.html", [
    [ "Introduction", "index.html#firstsect", [
      [ "Java Examples Introduction", "index.html#javaexamplesintroduction", null ],
      [ "Configuring Java Examples", "index.html#configuringjavaexamples", null ],
      [ "Unhandled Java Events", "index.html#unhandledjavaevents", null ],
      [ "Java Examples", "index.html#javaexamples", [
        [ "Example MinRcv.java", "index.html#exampleMinRcv_java", null ],
        [ "Example MinSrc.java", "index.html#exampleMinSrc_java", null ],
        [ "Example displayString.java", "index.html#exampledisplayString_java", null ],
        [ "Example lbmExampleUtil.java", "index.html#examplelbmExampleUtil_java", null ],
        [ "Example lbmdump.java", "index.html#examplelbmdump_java", null ],
        [ "Example lbmhfxrcv.java", "index.html#examplelbmhfxrcv_java", null ],
        [ "Example lbmimsg.java", "index.html#examplelbmimsg_java", null ],
        [ "Example lbmlatping.java", "index.html#examplelbmlatping_java", null ],
        [ "Example lbmlatpong.java", "index.html#examplelbmlatpong_java", null ],
        [ "Example lbmmon.java", "index.html#examplelbmmon_java", null ],
        [ "Example lbmmrcv.java", "index.html#examplelbmmrcv_java", null ],
        [ "Example lbmmsrc.java", "index.html#examplelbmmsrc_java", null ],
        [ "Example lbmpong.java", "index.html#examplelbmpong_java", null ],
        [ "Example lbmpong1.java", "index.html#examplelbmpong1_java", null ],
        [ "Example lbmrcv.java", "index.html#examplelbmrcv_java", null ],
        [ "Example lbmrcvxsp.java", "index.html#examplelbmrcvxsp_java", null ],
        [ "Example lbmreq.java", "index.html#examplelbmreq_java", null ],
        [ "Example lbmresp.java", "index.html#examplelbmresp_java", null ],
        [ "Example lbmsrc.java", "index.html#examplelbmsrc_java", null ],
        [ "Example lbmssrc.java", "index.html#examplelbmssrc_java", null ],
        [ "Example lbmstrm.java", "index.html#examplelbmstrm_java", null ],
        [ "Example lbmtrreq.java", "index.html#examplelbmtrreq_java", null ],
        [ "Example lbmwrcv.java", "index.html#examplelbmwrcv_java", null ],
        [ "Example umercv.java", "index.html#exampleumercv_java", null ],
        [ "Example umesrc.java", "index.html#exampleumesrc_java", null ],
        [ "Example umessrc.java", "index.html#exampleumessrc_java", null ],
        [ "Example umqrcv.java", "index.html#exampleumqrcv_java", null ],
        [ "Example umqsrc.java", "index.html#exampleumqsrc_java", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';