var classcom_1_1latencybusters_1_1lbm_1_1UMENoStoreException =
[
    [ "UMENoStoreException", "classcom_1_1latencybusters_1_1lbm_1_1UMENoStoreException.html#afd82cf6e1d9247de4db40d37a08e4878", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1UMENoStoreException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];