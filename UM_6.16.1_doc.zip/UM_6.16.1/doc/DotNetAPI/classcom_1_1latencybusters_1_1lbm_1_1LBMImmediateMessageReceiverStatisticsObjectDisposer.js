var classcom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageReceiverStatisticsObjectDisposer =
[
    [ "dispose", "classcom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageReceiverStatisticsObjectDisposer.html#a20c38bcdb477baa91c213dca8d2c7a66", null ],
    [ "dispose", "classcom_1_1latencybusters_1_1lbm_1_1LBMImmediateMessageReceiverStatisticsObjectDisposer.html#a2237e24f2015cd1f7a724db958f5e9b0", null ]
];