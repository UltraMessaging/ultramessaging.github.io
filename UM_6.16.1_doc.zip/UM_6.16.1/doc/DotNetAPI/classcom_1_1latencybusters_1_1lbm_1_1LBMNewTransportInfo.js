var classcom_1_1latencybusters_1_1lbm_1_1LBMNewTransportInfo =
[
    [ "LBMNewTransportInfo", "classcom_1_1latencybusters_1_1lbm_1_1LBMNewTransportInfo.html#a0be5fe76933b16d81037600dc57b810b", null ],
    [ "flags", "classcom_1_1latencybusters_1_1lbm_1_1LBMNewTransportInfo.html#a5d5b726bc1023836795882e226b7846c", null ],
    [ "getSourceString", "classcom_1_1latencybusters_1_1lbm_1_1LBMNewTransportInfo.html#a995d6c0bfecc8915f1a4761e6f7e9b93", null ],
    [ "getTransportSourceInfo", "classcom_1_1latencybusters_1_1lbm_1_1LBMNewTransportInfo.html#a000feeba889ff632dcf7c5e94237690f", null ],
    [ "setFlags", "classcom_1_1latencybusters_1_1lbm_1_1LBMNewTransportInfo.html#af98e8dfd81915cc7494213be9b5fe8f3", null ],
    [ "setSourceString", "classcom_1_1latencybusters_1_1lbm_1_1LBMNewTransportInfo.html#a30195fd02359e6bf507e972ef7ab8561", null ],
    [ "setTransportSourceInfo", "classcom_1_1latencybusters_1_1lbm_1_1LBMNewTransportInfo.html#a3b78c29bee77014c3e41aed255eebf9e", null ]
];