var classcom_1_1latencybusters_1_1lbm_1_1UMENoRegException =
[
    [ "UMENoRegException", "classcom_1_1latencybusters_1_1lbm_1_1UMENoRegException.html#a51d9e1a4cef26d91cb44adc34e7d118c", null ],
    [ "errorNumber", "classcom_1_1latencybusters_1_1lbm_1_1UMENoRegException.html#a22e39af68ca3dfe71de5225772c4379e", null ]
];