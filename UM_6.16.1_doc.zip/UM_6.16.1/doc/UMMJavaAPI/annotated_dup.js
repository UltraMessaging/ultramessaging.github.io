var annotated_dup =
[
    [ "umm", null, [
      [ "api", null, [
        [ "AuditLogData", "classumm_1_1api_1_1AuditLogData.html", "classumm_1_1api_1_1AuditLogData" ],
        [ "NameValue", "classumm_1_1api_1_1NameValue.html", "classumm_1_1api_1_1NameValue" ],
        [ "UMMAPI", "classumm_1_1api_1_1UMMAPI.html", "classumm_1_1api_1_1UMMAPI" ],
        [ "User", "classumm_1_1api_1_1User.html", "classumm_1_1api_1_1User" ]
      ] ]
    ] ]
];