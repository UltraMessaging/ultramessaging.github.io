var structumdsd__dstat__connection__source__record__stct =
[
    [ "topic", "structumdsd__dstat__connection__source__record__stct.html#ad05485d297e8d740eae8a02315eaebef", null ],
    [ "topicQ_id", "structumdsd__dstat__connection__source__record__stct.html#a46842eccb0244eaf2935736e07109b82", null ]
];