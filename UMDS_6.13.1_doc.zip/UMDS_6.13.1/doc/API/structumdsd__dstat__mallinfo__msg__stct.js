var structumdsd__dstat__mallinfo__msg__stct =
[
    [ "hdr", "structumdsd__dstat__mallinfo__msg__stct.html#aac1ef6fad5d2763684a6f8bf553840bb", null ],
    [ "record", "structumdsd__dstat__mallinfo__msg__stct.html#a7920bfc459a298ed42747467caaa9532", null ]
];