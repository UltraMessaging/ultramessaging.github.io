var structumdsd__dstat__config__msg__stct =
[
    [ "hdr", "structumdsd__dstat__config__msg__stct.html#a44c25d7416aab7030092712e0fb7bf3e", null ],
    [ "record", "structumdsd__dstat__config__msg__stct.html#a7f38eff28b500395874fc0e67a04103d", null ]
];