var structumdsd__dstat__connection__permission__msg__stct =
[
    [ "hdr", "structumdsd__dstat__connection__permission__msg__stct.html#a278dda6953972fca32644f8c1fa21645", null ],
    [ "perms", "structumdsd__dstat__connection__permission__msg__stct.html#a739534cb5362f999b50e20dd480ffee9", null ]
];