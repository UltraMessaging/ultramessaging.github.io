var classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL =
[
    [ "APPLICATION_ERROR", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL.html#a9a3e373c65e155687759aad49f8caf1a", null ],
    [ "CRITICAL", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL.html#a3151aa1bac4ac210f14a1b37c7dc0541", null ],
    [ "INFO", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL.html#ab680192714f5b785b1200435fb7b8002", null ],
    [ "WARN", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL.html#a84e0fb46c7ecf721d332e8b6991b4a57", null ]
];