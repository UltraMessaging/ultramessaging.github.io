var NAVTREE =
[
  [ "UMDS Quick Start", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "UMDS Quick Overview", "umdsquickoverview.html", [
      [ "UMDS Server Installation", "umdsquickoverview.html#umdsserverinstallation", null ],
      [ "UMDS Client Installation", "umdsquickoverview.html#umdsclientinstallation", null ]
    ] ],
    [ "Configuring the UMDS Server", "configuringtheumdsserver.html", null ],
    [ "Starting the UMDS Server", "startingtheumdsserver.html", null ],
    [ "Running UMDS Example Applications", "runningumdsexampleapplications.html", [
      [ "Windows Java Example", "runningumdsexampleapplications.html#windowsjavaexample", null ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"configuringtheumdsserver.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';