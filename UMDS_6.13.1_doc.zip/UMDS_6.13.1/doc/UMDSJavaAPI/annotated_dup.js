var annotated_dup =
[
    [ "com", null, [
      [ "latencybusters", null, [
        [ "umds", null, [
          [ "UMDS", "classcom_1_1latencybusters_1_1umds_1_1UMDS.html", "classcom_1_1latencybusters_1_1umds_1_1UMDS" ],
          [ "UMDSCertificateValidity", "classcom_1_1latencybusters_1_1umds_1_1UMDSCertificateValidity.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSCertificateValidity" ],
          [ "UMDSIOStream", "classcom_1_1latencybusters_1_1umds_1_1UMDSIOStream.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSIOStream" ],
          [ "UMDSMessage", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage" ],
          [ "UMDSMessageOptions", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessageOptions.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessageOptions" ],
          [ "UMDSNioTlsClient", "classcom_1_1latencybusters_1_1umds_1_1UMDSNioTlsClient.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSNioTlsClient" ],
          [ "UMDSPersistentReceiver", "classcom_1_1latencybusters_1_1umds_1_1UMDSPersistentReceiver.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSPersistentReceiver" ],
          [ "UMDSReceiver", "classcom_1_1latencybusters_1_1umds_1_1UMDSReceiver.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSReceiver" ],
          [ "UMDSReceiverRecoveryInfo", "classcom_1_1latencybusters_1_1umds_1_1UMDSReceiverRecoveryInfo.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSReceiverRecoveryInfo" ],
          [ "UMDSReceiverRecoveryInfoCallback", "interfacecom_1_1latencybusters_1_1umds_1_1UMDSReceiverRecoveryInfoCallback.html", "interfacecom_1_1latencybusters_1_1umds_1_1UMDSReceiverRecoveryInfoCallback" ],
          [ "UMDSServerConnection", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSServerConnection" ],
          [ "UMDSSource", "classcom_1_1latencybusters_1_1umds_1_1UMDSSource.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSSource" ],
          [ "UMDSSslIOStream", "classcom_1_1latencybusters_1_1umds_1_1UMDSSslIOStream.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSSslIOStream" ],
          [ "UMDSStream", "classcom_1_1latencybusters_1_1umds_1_1UMDSStream.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSStream" ],
          [ "UMDSTlsBuffer", "classcom_1_1latencybusters_1_1umds_1_1UMDSTlsBuffer.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSTlsBuffer" ],
          [ "UMDSTlsBufferException", "classcom_1_1latencybusters_1_1umds_1_1UMDSTlsBufferException.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSTlsBufferException" ],
          [ "UMDSTrustStoreManager", "classcom_1_1latencybusters_1_1umds_1_1UMDSTrustStoreManager.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSTrustStoreManager" ],
          [ "UMDSWildcardReceiver", "classcom_1_1latencybusters_1_1umds_1_1UMDSWildcardReceiver.html", "classcom_1_1latencybusters_1_1umds_1_1UMDSWildcardReceiver" ]
        ] ]
      ] ]
    ] ]
];