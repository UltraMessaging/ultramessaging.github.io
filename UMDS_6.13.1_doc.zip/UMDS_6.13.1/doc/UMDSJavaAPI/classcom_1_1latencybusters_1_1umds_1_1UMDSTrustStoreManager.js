var classcom_1_1latencybusters_1_1umds_1_1UMDSTrustStoreManager =
[
    [ "getTrustedStore", "classcom_1_1latencybusters_1_1umds_1_1UMDSTrustStoreManager.html#a16ffc252e5d8639afa649bc9d9c43955", null ],
    [ "getTrustedStoreManger", "classcom_1_1latencybusters_1_1umds_1_1UMDSTrustStoreManager.html#ad50b5ae0c7f75126b88b69e11bf883d0", null ]
];