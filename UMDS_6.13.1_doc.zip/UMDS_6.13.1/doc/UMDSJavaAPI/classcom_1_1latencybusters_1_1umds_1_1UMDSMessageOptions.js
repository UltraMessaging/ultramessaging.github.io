var classcom_1_1latencybusters_1_1umds_1_1UMDSMessageOptions =
[
    [ "UMDSMessageOptions", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessageOptions.html#a043a33a4d8fa6116f574162b10a8099a", null ],
    [ "app_meta_data", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessageOptions.html#a059399f1bda8e2b2b4597b3344adc04d", null ]
];