var classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE =
[
    [ "CONFIGURATION_ERROR", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a6a4043983b67c35bb57f430bd60a288b", null ],
    [ "CONNECT", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a03c36662faca446adff9cce58d085f94", null ],
    [ "DATA", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a7430fc37970c0b65148cce490a8190fe", null ],
    [ "DISCONNECT", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#ae9d0d7501f767b953c9939461c00be75", null ],
    [ "LOGIN_COMPLETE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#abf64b7c047c98cb6d82a198943c3f174", null ],
    [ "LOGIN_DENIED", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#ae0f1ed4a54ca6d1c4372d5756e7ae497", null ],
    [ "LOGOUT_COMPLETE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a1f8403eb89064e40f38e57b2dd1c1187", null ],
    [ "LOSS", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a3464fa752b7773cebe4996d9083f2deb", null ],
    [ "RECEIVER_CREATE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a0b8066f8aa1e467d3cce8cb18a4e333b", null ],
    [ "RECEIVER_DELETE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#aa8028a4ee3fe19191a2392977f7566fb", null ],
    [ "REQUEST", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a5e40973aae647b93e4e1b8c102caea32", null ],
    [ "REQUEST_CANCELED", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#ae302167048fa80111736845730ddc8dc", null ],
    [ "RESPONSE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#abd6763905b923014ca8e092c0c619e17", null ],
    [ "SERVER_DENIED", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#ad9c88323d95f8c711006957c18a5beaa", null ],
    [ "SERVER_STOPPED", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#ac6c7997e4f4e32cdf09813dfee894a79", null ],
    [ "SOURCE_CREATE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a8f6d417897b91765a02d7c8bb6c71d81", null ],
    [ "SOURCE_DELETE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#a48900dca05d0e96e2b117aa0261f8785", null ],
    [ "STABLE", "classcom_1_1latencybusters_1_1umds_1_1UMDSMessage_1_1MSG__TYPE.html#aebd5219ac098c337f4eb9ca8d20b925d", null ]
];