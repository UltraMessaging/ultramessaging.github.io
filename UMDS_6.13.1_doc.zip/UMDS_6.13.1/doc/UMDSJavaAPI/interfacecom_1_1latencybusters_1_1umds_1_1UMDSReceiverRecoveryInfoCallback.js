var interfacecom_1_1latencybusters_1_1umds_1_1UMDSReceiverRecoveryInfoCallback =
[
    [ "setReceiverRecoverySequenceNumber", "interfacecom_1_1latencybusters_1_1umds_1_1UMDSReceiverRecoveryInfoCallback.html#ae78c0139a7462244d7042a0f82f80fc1", null ]
];