var classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL =
[
    [ "APPLICATION_ERROR", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL.html#a8eb51ae017123d2a88db5e181e6529d1", null ],
    [ "CRITICAL", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL.html#a6ff827443dd9461f36b8960bc8c5a82d", null ],
    [ "INFO", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL.html#a7449663dcfe9955d9b87ac4ecf817537", null ],
    [ "WARN", "classcom_1_1latencybusters_1_1umds_1_1UMDS_1_1LOG__LEVEL.html#aaded58e853ef52406e7a0ff8ecdd5de0", null ]
];