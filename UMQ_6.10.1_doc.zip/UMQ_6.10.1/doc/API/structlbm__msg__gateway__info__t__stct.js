var structlbm__msg__gateway__info__t__stct =
[
    [ "sequence_number", "structlbm__msg__gateway__info__t__stct.html#a2289e4e9ed637a79ca66ca879ad1a960", null ],
    [ "source", "structlbm__msg__gateway__info__t__stct.html#a4063e8efd5a51438c3f538cb4716b391", null ]
];