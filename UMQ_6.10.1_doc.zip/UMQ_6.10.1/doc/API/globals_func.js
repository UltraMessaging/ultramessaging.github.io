var globals_func =
[
    [ "l", "globals_func.html", null ]
];