var structlbm__src__event__umq__message__id__info__t__stct =
[
    [ "flags", "structlbm__src__event__umq__message__id__info__t__stct.html#ab183e0edf004d922b6ea2630d515f8ad", null ],
    [ "msg_clientd", "structlbm__src__event__umq__message__id__info__t__stct.html#a57f31dcd6e415623b975a99042542cb3", null ],
    [ "msg_id", "structlbm__src__event__umq__message__id__info__t__stct.html#ad7bf89b639abe6042744204be2417f34", null ]
];