var structlbm__src__event__wakeup__t__stct =
[
    [ "flags", "structlbm__src__event__wakeup__t__stct.html#acb8fe53ff49e0813bb4837b6131afc45", null ]
];