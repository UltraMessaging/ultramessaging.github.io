var structlbm__msg__umq__deregistration__complete__ex__t__stct =
[
    [ "flags", "structlbm__msg__umq__deregistration__complete__ex__t__stct.html#affcbf302d2b3265148363d6304a17440", null ],
    [ "queue", "structlbm__msg__umq__deregistration__complete__ex__t__stct.html#a1386b0beec73bd02613ea19fd2ba975a", null ],
    [ "queue_id", "structlbm__msg__umq__deregistration__complete__ex__t__stct.html#a596b0bfdfa26f7f686393eb98e53c4e7", null ]
];