var structlbmpdm__decimal__t =
[
    [ "exp", "structlbmpdm__decimal__t.html#aa495671a8c0604575091afafda56cb9c", null ],
    [ "mant", "structlbmpdm__decimal__t.html#aa30802e106436a6c56f5a883b98d84df", null ]
];