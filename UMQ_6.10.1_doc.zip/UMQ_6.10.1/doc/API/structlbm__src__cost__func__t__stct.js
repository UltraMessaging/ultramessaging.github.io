var structlbm__src__cost__func__t__stct =
[
    [ "clientd", "structlbm__src__cost__func__t__stct.html#abdce81150084584ff5c32149014a648e", null ],
    [ "cost_cb", "structlbm__src__cost__func__t__stct.html#a60c503bd1b649070fad27dd4df8e58c7", null ]
];