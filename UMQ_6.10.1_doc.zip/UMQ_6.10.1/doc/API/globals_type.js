var globals_type =
[
    [ "l", "globals_type.html", null ],
    [ "u", "globals_type_u.html", null ]
];