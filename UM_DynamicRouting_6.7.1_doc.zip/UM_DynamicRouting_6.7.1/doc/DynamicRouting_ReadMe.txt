
	Ultra Messaging(R) Dynamic Routing Option Documentation
     --------------------------------------------------------------

     --------------------------------------------------------------

        Welcome to the UM Dynamic Routing Option Version 6.7.1
	documentation package.

	The documentation package is available as a zip or tar file,
        with a single top-level directory. You can unpack and install
	this package in any desired directory.

